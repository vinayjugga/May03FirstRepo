package com.diversey.dm.model;

import java.io.Serializable;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.common.base.MoreObjects;
import com.google.common.base.Objects;

import io.swagger.annotations.ApiModelProperty;

@Component
@JsonIgnoreProperties(ignoreUnknown=true)
public class DeviceRegistration implements Serializable {

	private static final long serialVersionUID = 1L;

	@ApiModelProperty(notes = "Service Line name")
	private String serviceLine;
	
	@ApiModelProperty(notes = "Manufacturer name")
	private String manufacturer;
	
	@ApiModelProperty(notes = "Reference Id")
	private String refId;

	@ApiModelProperty(notes = "Device serial number")
	public String serialNumber;

	@ApiModelProperty(notes = "Device type")
	private String deviceType;

	@ApiModelProperty(notes = "Device manufacture date")
	private String manufactureDate;
	
	@ApiModelProperty(notes = "Firmware version")
	private String firmwareVersion;
	
	@ApiModelProperty(notes = "DeviceMac")
	private String deviceMac;
	
	@ApiModelProperty(notes = "Device phone number")
	private String devicePhoneNumber;
	
	@ApiModelProperty(notes = "The Reader firmware version of device")
	private String readerFirmwareVersion;
	
	@JsonIgnore
	@ApiModelProperty(notes = "The firmware file name")
    private String firmwareFileName;
	
	@ApiModelProperty(notes = "The Sim Type")
    private String simType;
	
	@ApiModelProperty(notes=" Add description of device")
	private String description;

	//@JsonIgnore
	@ApiModelProperty(notes = "Config version")
    private int configVersion;   //It will be an auto-increment field in database 
	
	@JsonIgnore
    @ApiModelProperty(notes = "Raw Config")
    private String  rawConfig;
    
    @JsonIgnore
    @ApiModelProperty(notes = "Ini Config")
    private String  iniConfig;
    
    @JsonIgnore
    @ApiModelProperty(notes = "Encoded Config")
    private byte[]  encodedConfig;
    
	@ApiModelProperty(notes = "Key value")
	private Map<String, String>  keyValue = new HashMap<>();
	
    @ApiModelProperty(notes = "created by  user")
    private String  user;
    
    @ApiModelProperty(notes = "SIM Number")
    private String  simNumber;


	public DeviceRegistration() {
	}

	public DeviceRegistration(String serialNumber) {
		super();
		this.serialNumber = serialNumber;
	}

	
//	public String getManufacturerName() {
//		return manufacturerName;
//	}
//
//	public void setManufacturerName(String manufacturerName) {
//		this.manufacturerName = manufacturerName;
//	}

	public String getServiceLine() {
		return serviceLine;
	}

	public void setServiceLine(String serviceLine) {
		this.serviceLine = serviceLine;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getFirmwareVersion() {
		return firmwareVersion;
	}

	public void setFirmwareVersion(String firmwareVersion) {
		this.firmwareVersion = firmwareVersion;
	}

	public int getConfigVersion() {
		return configVersion;
	}

	public void setConfigVersion(int version) {
		this.configVersion = version;
	}


	public String getDeviceMac() {
		return deviceMac;
	}

	public void setDeviceMac(String deviceMac) {
		this.deviceMac = deviceMac;
	}

	public String getDevicePhoneNumber() {
		return devicePhoneNumber;
	}

	public void setDevicePhoneNumber(String devicePhoneNumber) {
		this.devicePhoneNumber = devicePhoneNumber;
	}

	public String getManufactureDate() {
		return manufactureDate;
	}

	public void setManufactureDate(String manufactureDate) {
		this.manufactureDate = manufactureDate;
	}
	
	public String getRefId() {
		return refId;
	}

	public void setRefId(String refId) {
		this.refId = refId;
	}

	public Map<String, String> getKeyValue() {
		return keyValue;
	}

	public String getReaderFirmwareVersion() {
    return readerFirmwareVersion;
  }

  public void setReaderFirmwareVersion(String readerFirmwareVersion) {
    this.readerFirmwareVersion = readerFirmwareVersion;
  }

  public void setKeyValue(Map<String, String> keyValue) {
		this.keyValue = keyValue;
	}
	
  public String getRawConfig() {
    return rawConfig;
  }

  public void setRawConfig(String rawConfig) {
    this.rawConfig = rawConfig;
  }
  
  public String getIniConfig() {
    return iniConfig;
  }

  public void setIniConfig(String iniConfig) {
    this.iniConfig = iniConfig;
  }
  
  public byte[] getEncodedConfig() {
    return encodedConfig;
  }

  public void setEncodedConfig(byte[] encodedConfig) {
    this.encodedConfig = encodedConfig;
  }
  
  public String getFirmwareFileName() {
    return firmwareFileName;
  }

  public void setFirmwareFileName(String firmwareFileName) {
    this.firmwareFileName = firmwareFileName;
  }

  @JsonIgnore
	public void addKeyValue(String key, String value) {
		ensureNotNull();
		keyValue.put(key, value);
	}
	
	private void ensureNotNull() {
		if(keyValue==null) {
			keyValue = new HashMap<>();
		}
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}
	
	public String getSimNumber() {
		return simNumber;
	}

	public void setSimNumber(String simNumber) {
		this.simNumber = simNumber;
	}

	
	public String getSimType() {
		return simType;
	}

	public void setSimType(String simType) {
		this.simType = simType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof DeviceRegistration)) {
			return false;
		}
		DeviceRegistration other = (DeviceRegistration) obj;
		return configVersion == other.configVersion && java.util.Objects.equals(description, other.description)
				&& java.util.Objects.equals(deviceMac, other.deviceMac)
				&& java.util.Objects.equals(devicePhoneNumber, other.devicePhoneNumber)
				&& java.util.Objects.equals(deviceType, other.deviceType)
				&& Arrays.equals(encodedConfig, other.encodedConfig)
				&& java.util.Objects.equals(firmwareFileName, other.firmwareFileName)
				&& java.util.Objects.equals(firmwareVersion, other.firmwareVersion)
				&& java.util.Objects.equals(iniConfig, other.iniConfig)
				&& java.util.Objects.equals(keyValue, other.keyValue)
				&& java.util.Objects.equals(manufactureDate, other.manufactureDate)
				&& java.util.Objects.equals(manufacturer, other.manufacturer)
				&& java.util.Objects.equals(rawConfig, other.rawConfig)
				&& java.util.Objects.equals(readerFirmwareVersion, other.readerFirmwareVersion)
				&& java.util.Objects.equals(refId, other.refId)
				&& java.util.Objects.equals(serialNumber, other.serialNumber)
				&& java.util.Objects.equals(serviceLine, other.serviceLine)
				&& java.util.Objects.equals(simNumber, other.simNumber)
				&& java.util.Objects.equals(simType, other.simType) && java.util.Objects.equals(user, other.user);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + java.util.Objects.hash(configVersion, description, deviceMac, devicePhoneNumber,
				deviceType, firmwareFileName, firmwareVersion, iniConfig, keyValue, manufactureDate, manufacturer,
				rawConfig, readerFirmwareVersion, refId, serialNumber, serviceLine, simNumber, simType, user);
		result = prime * result + Arrays.hashCode(encodedConfig);
		return result;
	}

	@Override
	public String toString() {
		return "DeviceRegistration [serviceLine=" + serviceLine + ", manufacturer=" + manufacturer + ", refId=" + refId
				+ ", serialNumber=" + serialNumber + ", deviceType=" + deviceType + ", manufactureDate="
				+ manufactureDate + ", firmwareVersion=" + firmwareVersion + ", deviceMac=" + deviceMac
				+ ", devicePhoneNumber=" + devicePhoneNumber + ", readerFirmwareVersion=" + readerFirmwareVersion
				+ ", firmwareFileName=" + firmwareFileName + ", simType=" + simType + ", description=" + description
				+ ", configVersion=" + configVersion + ", rawConfig=" + rawConfig + ", iniConfig=" + iniConfig
				+ ", encodedConfig=" + Arrays.toString(encodedConfig) + ", keyValue=" + keyValue + ", user=" + user
				+ ", simNumber=" + simNumber + "]";
	}
}
