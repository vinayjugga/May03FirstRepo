package com.diversey.dm.model;

import io.swagger.annotations.ApiModelProperty;

public class Site {

	private int id;
	private String name;
	private String address_line_1;
	private String address_line_2;
	private String postal_code;
	private String city;
	private String createdAt;
	private int isActive;
	private String nodeId;
	private String country;
	private int countryId;
	private String erp_number;
	private int migratedOldId;
	private int orgId;
	private double latitude;
	private double longitude;
	private double radius;
	private String solutionAtSite;
	private String timezone;

	public Site(int id, String name, String address_line_1, String address_line_2, String postal_code, String city,
			String createdAt, int isActive, String nodeId, String country, double latitude, double longitude,
			double radius) {
		super();
		this.id = id;
		this.name = name;
		this.address_line_1 = address_line_1;
		this.address_line_2 = address_line_2;
		this.postal_code = postal_code;
		this.city = city;
		this.createdAt = createdAt;
		this.isActive = isActive;
		this.nodeId = nodeId;
		this.country = country;
		this.latitude = latitude;
		this.longitude = longitude;
		this.radius = radius;
	}

	/**
	 * @param id
	 * @param name
	 * @param address_line_1
	 * @param address_line_2
	 * @param postal_code
	 * @param city
	 * @param createdAt
	 * @param isActive
	 * @param nodeId
	 * @param country
	 * @param countryId
	 * @param erp_number
	 * @param migratedOldId
	 * @param orgId
	 * @param latitude
	 * @param longitude
	 * @param radius
	 * @param solutionAtSite
	 * @param timezone
	 */
	public Site(int id, String name, String address_line_1, String address_line_2, String postal_code, String city,
			String createdAt, int isActive, String nodeId, String country, int countryId, String erp_number,
			int migratedOldId, int orgId, double latitude, double longitude, double radius, String solutionAtSite,
			String timezone) {
		super();
		this.id = id;
		this.name = name;
		this.address_line_1 = address_line_1;
		this.address_line_2 = address_line_2;
		this.postal_code = postal_code;
		this.city = city;
		this.createdAt = createdAt;
		this.isActive = isActive;
		this.nodeId = nodeId;
		this.country = country;
		this.countryId = countryId;
		this.erp_number = erp_number;
		this.migratedOldId = migratedOldId;
		this.orgId = orgId;
		this.latitude = latitude;
		this.longitude = longitude;
		this.radius = radius;
		this.solutionAtSite = solutionAtSite;
		this.timezone = timezone;
	}

	public int getOrgId() {
		return orgId;
	}

	public void setOrgId(int orgId) {
		this.orgId = orgId;
	}

	public String getSolutionAtSite() {
		return solutionAtSite;
	}

	public void setSolutionAtSite(String solutionAtSite) {
		this.solutionAtSite = solutionAtSite;
	}

	public String getTimezone() {
		return timezone;
	}

	public void setTimezone(String timezone) {
		this.timezone = timezone;
	}

	public int getMigratedOldId() {
		return migratedOldId;
	}

	public void setMigratedOldId(int migratedOldId) {
		this.migratedOldId = migratedOldId;
	}

	public String getErp_number() {
		return erp_number;
	}

	public void setErp_number(String erp_number) {
		this.erp_number = erp_number;
	}

	public int getCountryId() {
		return countryId;
	}

	public void setCountryId(int countryId) {
		this.countryId = countryId;
	}

	public Site() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress_line_1() {
		return address_line_1;
	}

	public void setAddress_line_1(String address_line_1) {
		this.address_line_1 = address_line_1;
	}

	public String getAddress_line_2() {
		return address_line_2;
	}

	public void setAddress_line_2(String address_line_2) {
		this.address_line_2 = address_line_2;
	}

	public String getPostal_code() {
		return postal_code;
	}

	public void setPostal_code(String postal_code) {
		this.postal_code = postal_code;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	public int getIsActive() {
		return isActive;
	}

	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}

	public String getNodeId() {
		return nodeId;
	}

	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public double getRadius() {
		return radius;
	}

	public void setRadius(double radius) {
		this.radius = radius;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address_line_1 == null) ? 0 : address_line_1.hashCode());
		result = prime * result + ((address_line_2 == null) ? 0 : address_line_2.hashCode());
		result = prime * result + ((city == null) ? 0 : city.hashCode());
		result = prime * result + ((country == null) ? 0 : country.hashCode());
		result = prime * result + ((createdAt == null) ? 0 : createdAt.hashCode());
		result = prime * result + id;
		result = prime * result + isActive;
		long temp;
		temp = Double.doubleToLongBits(latitude);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(longitude);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((postal_code == null) ? 0 : postal_code.hashCode());
		temp = Double.doubleToLongBits(radius);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Site other = (Site) obj;
		if (address_line_1 == null) {
			if (other.address_line_1 != null)
				return false;
		} else if (!address_line_1.equals(other.address_line_1))
			return false;
		if (address_line_2 == null) {
			if (other.address_line_2 != null)
				return false;
		} else if (!address_line_2.equals(other.address_line_2))
			return false;
		if (city == null) {
			if (other.city != null)
				return false;
		} else if (!city.equals(other.city))
			return false;
		if (country == null) {
			if (other.country != null)
				return false;
		} else if (!country.equals(other.country))
			return false;
		if (createdAt == null) {
			if (other.createdAt != null)
				return false;
		} else if (!createdAt.equals(other.createdAt))
			return false;
		if (id != other.id)
			return false;
		if (isActive != other.isActive)
			return false;
		if (Double.doubleToLongBits(latitude) != Double.doubleToLongBits(other.latitude))
			return false;
		if (Double.doubleToLongBits(longitude) != Double.doubleToLongBits(other.longitude))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (nodeId != other.nodeId)
			return false;
		if (postal_code == null) {
			if (other.postal_code != null)
				return false;
		} else if (!postal_code.equals(other.postal_code))
			return false;
		if (Double.doubleToLongBits(radius) != Double.doubleToLongBits(other.radius))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Site [id=" + id + ", name=" + name + ", address_line_1=" + address_line_1 + ", address_line_2="
				+ address_line_2 + ", postal_code=" + postal_code + ", city=" + city + ", createdAt=" + createdAt
				+ ", isActive=" + isActive + ", nodeId=" + nodeId + ", country=" + country + ", migratedOldId="
				+ migratedOldId + ", orgId=" + orgId + ", latitude=" + latitude + ", longitude=" + longitude
				+ ", radius=" + radius + "]";
	}
	
	

}
