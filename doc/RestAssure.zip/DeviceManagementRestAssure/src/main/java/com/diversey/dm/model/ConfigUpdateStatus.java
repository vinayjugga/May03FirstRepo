package com.diversey.dm.model;

import java.io.Serializable;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.base.MoreObjects;

import io.swagger.annotations.ApiModelProperty;

public class ConfigUpdateStatus implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	@ApiModelProperty(notes = "Processing Id")
	private String processingId;

	@ApiModelProperty(notes = "Processing Started Date")
	private String processingStartedSate;

	@ApiModelProperty(notes = "Processing Finished Date")
	private String processingFinishedDate;

	@ApiModelProperty(notes = "Serial Number")
	private String serialNumber;
	
	@JsonIgnore
	@ApiModelProperty(notes = "Request Payload")
	private String requestPayload;

	@ApiModelProperty(notes = "Status")
	private String status;

	
	@ApiModelProperty(notes = "Error Stack")
	private String errorStack;

	public String getProcessingId() {
		return processingId;
	}

	public void setProcessingId(String processingId) {
		this.processingId = processingId;
	}

	public String getProcessingStartedSate() {
		return processingStartedSate;
	}

	public void setProcessingStartedSate(String processingStartedSate) {
		this.processingStartedSate = processingStartedSate;
	}

	public String getProcessingFinishedDate() {
		return processingFinishedDate;
	}

	public void setProcessingFinishedDate(String processingFinishedDate) {
		this.processingFinishedDate = processingFinishedDate;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getRequestPayload() {
		return requestPayload;
	}

	public void setRequestPayload(String requestPayload) {
		this.requestPayload = requestPayload;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getErrorStack() {
		return errorStack;
	}

	public void setErrorStack(String errorStack) {
		this.errorStack = errorStack;
	}

	@Override
	public int hashCode() {
		return Objects.hash(this.errorStack, this.processingFinishedDate, this.processingId, this.processingStartedSate, this.requestPayload,
				this.serialNumber, this.status);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof ConfigUpdateStatus)) {
			return false;
		}
		ConfigUpdateStatus other = (ConfigUpdateStatus) obj;
		return Objects.equals(errorStack, other.errorStack)
				&& Objects.equals(processingFinishedDate, other.processingFinishedDate)
				&& Objects.equals(processingId, other.processingId)
				&& Objects.equals(processingStartedSate, other.processingStartedSate)
				&& Objects.equals(requestPayload, other.requestPayload)
				&& Objects.equals(serialNumber, other.serialNumber) && Objects.equals(status, other.status);
	}

	@Override
	public String toString() {
		return MoreObjects.toStringHelper(this).add("errorStack", errorStack)
				.add("processingFinishedDate", processingFinishedDate).add("processingId", processingId)
				.add("processingStartedSate", processingStartedSate).add("requestPayload", requestPayload)
				.add("serialNumber", serialNumber).add("status", status).toString();

	}

}
