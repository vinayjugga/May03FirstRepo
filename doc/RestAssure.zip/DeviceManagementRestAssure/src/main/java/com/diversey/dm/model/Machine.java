package com.diversey.dm.model;

import io.swagger.annotations.ApiModelProperty;

public class Machine {
	
	@ApiModelProperty(notes = "DeviceNumber of the registered device")
	private String deviceNumber;
	
	@ApiModelProperty(notes = "Machinemake  for the MachineModel")
	private String machineMake;
	
	@ApiModelProperty(notes = "MachineModel associated to DeviceNumber")
	private String machineModel;
	
	@ApiModelProperty(notes = "Machine Battery type")
	private String machineBatteryType;	
	
	@ApiModelProperty(notes = "Device Site")
	private Site site;

	public Machine() {
		super();
	}

	public Machine(String deviceNumber, String machineMake, String machineModel, String machineBatteryType,
			Site site, String latitude, String longitude, String radius) {
		super();
		this.deviceNumber = deviceNumber;
		this.machineMake = machineMake;
		this.machineModel = machineModel;
		this.machineBatteryType = machineBatteryType;
		this.site = site;
	}

	public String getDeviceNumber() {
		return deviceNumber;
	}

	public void setDeviceNumber(String deviceNumber) {
		this.deviceNumber = deviceNumber;
	}

	public String getMachineMake() {
		return machineMake;
	}

	public void setMachineMake(String machineMake) {
		this.machineMake = machineMake;
	}

	public String getMachineModel() {
		return machineModel;
	}

	public void setMachineModel(String machineModel) {
		this.machineModel = machineModel;
	}

	public String getMachineBatteryType() {
		return machineBatteryType;
	}

	public void setMachineBatteryType(String machineBatteryType) {
		this.machineBatteryType = machineBatteryType;
	}

	public Site getSite() {
		return site;
	}

	public void setSite(Site site) {
		this.site = site;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((deviceNumber == null) ? 0 : deviceNumber.hashCode());
		result = prime * result + ((machineBatteryType == null) ? 0 : machineBatteryType.hashCode());
		result = prime * result + ((machineMake == null) ? 0 : machineMake.hashCode());
		result = prime * result + ((machineModel == null) ? 0 : machineModel.hashCode());
		result = prime * result + ((site == null) ? 0 : site.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Machine other = (Machine) obj;
		if (deviceNumber == null) {
			if (other.deviceNumber != null)
				return false;
		} else if (!deviceNumber.equals(other.deviceNumber))
			return false;
		if (machineBatteryType == null) {
			if (other.machineBatteryType != null)
				return false;
		} else if (!machineBatteryType.equals(other.machineBatteryType))
			return false;
		if (machineMake == null) {
			if (other.machineMake != null)
				return false;
		} else if (!machineMake.equals(other.machineMake))
			return false;
		if (machineModel == null) {
			if (other.machineModel != null)
				return false;
		} else if (!machineModel.equals(other.machineModel))
			return false;
		if (site == null) {
			if (other.site != null)
				return false;
		} else if (!site.equals(other.site))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "MachineAssignment [deviceNumber=" + deviceNumber + ", machineMake=" + machineMake + ", machineModel="
				+ machineModel + ", machineBatteryType=" + machineBatteryType + ", site=" + site + "]";
	}
	
}
