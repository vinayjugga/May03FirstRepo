package com.diversey.dm.model;

import java.util.List;
import com.google.common.base.Objects;
import io.swagger.annotations.ApiModelProperty;

public class SiteCell {

	@ApiModelProperty(notes = "site_id associated with the Machine Type") 
	private String siteId;
	
	@ApiModelProperty(notes = "cellIds")
	private List<String> cellIds;
	
	@ApiModelProperty(notes="user")
	private String user;
	
	public String getSiteId() {
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public List<String> getCellIds() {
		return cellIds;
	}

	public void setCellIds(List<String> cellIds) {
		this.cellIds = cellIds;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof SiteCell)) {
			return false;
		}
		SiteCell other = (SiteCell) obj;
		return java.util.Objects.equals(cellIds, other.cellIds) && java.util.Objects.equals(siteId, other.siteId)
				&& java.util.Objects.equals(user, other.user);
	}

	@Override
	public int hashCode() {
		return java.util.Objects.hash(cellIds, siteId, user);
	}

	@Override
	public String toString() {
		return "CellInfo [siteId=" + siteId + ", cellIds=" + cellIds + ", user=" + user + "]";
	}

	/*@Override
	public String toString() {
		return MoreObjects.toStringHelper(this).add("assetId", device_number).add("apn", apn).add("cellId", cell_ids)
				.add("preferedOperatorName", preferedOperatorName).toString();
	}*/
	
	

}
