package com.diversey.dm.utility;

import java.util.UUID;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import com.diversey.dm.utility.*;
import com.google.common.base.Verify;

import ch.qos.logback.core.net.SyslogOutputStream;

public class MQTTUtility implements MqttCallback, MqttCallbackExtended{

	EnvParams envParams = new EnvParams();
	private MqttClient client;
	private MqttConnectOptions connOpts;
	
	
	public void MQTTSubscriber(String serialNumber, String configVersion, boolean versionText ) 
	{
		String topic;
		if(versionText == true)
			topic="+/config/"+serialNumber+"/version";
		else
			topic="+/config/"+serialNumber+"/"+configVersion;
		try {
			String mqttAddress = envParams.getMqttAddress();
			String mqttUser = envParams.getMqttUser();
			String mqttPassword = envParams.getMqttPassword();
			System.out.println("MQTT Broker IP Address:"+ mqttAddress);
			connOpts = setConnectionOptions(mqttAddress);
			System.out.println("Connecting to mqtt client..");
			client.connect(connOpts);
			System.out.println("Connected to mqtt client");
			client.setCallback(this);
			// subscribe to the topics
			System.out.println("Subscribing to the topic {}"+ topic);
			client.subscribe(topic);
			System.out.println("Subscribed to Topic {} "+ topic);
			System.out.println("Subscriber is listening to the above topic ....");
	
		}
		catch(Exception ex)
		{
			System.out.println("Catching exception while connecting to MQTT Broker: " + ex.getMessage());
			ex.printStackTrace();
		}
	}
		@Override
		public void messageArrived(String topic, MqttMessage message) throws Exception {
		
		System.out.println("Message Arrived on Topic:"+ topic);
		System.out.println("Message Id: {} | Payload: {}"+ message.getId());
		System.out.println(new String(message.getPayload()));
		Verify.verify(true);
		client.unsubscribe(topic);
	
	}
	
	public MqttConnectOptions setConnectionOptions(String mqttAddress) throws MqttException
	{
		String clientId = UUID.randomUUID().toString();
		connOpts = new MqttConnectOptions();
		connOpts.setCleanSession(Boolean.TRUE);
		connOpts.setAutomaticReconnect(true);
		connOpts.setKeepAliveInterval(30);
		System.out.println("inside connopts:"+ mqttAddress);
		client = new MqttClient(mqttAddress, clientId, new MemoryPersistence());	

		if (envParams.getMqttUser()!= null)
			connOpts.setUserName(envParams.getMqttUser());
		if (envParams.getMqttPassword()!= null)
			connOpts.setPassword(envParams.getMqttPassword().toCharArray());
		return connOpts;
	}

	@Override
	public void connectComplete(boolean reconnect, String serverURI) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void connectionLost(Throwable cause) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deliveryComplete(IMqttDeliveryToken token) {
		// TODO Auto-generated method stub
		
	}


}
