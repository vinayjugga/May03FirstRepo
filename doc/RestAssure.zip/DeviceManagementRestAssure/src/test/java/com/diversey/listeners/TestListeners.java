package com.diversey.listeners;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.json.simple.parser.JSONParser;

import org.testng.IResultMap;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;
import org.testng.Reporter;

import com.wipro.wdb.SLog;


public class TestListeners implements ITestListener{

	
	//protected static ExtentReports reports;
	//public static ExtentTest logger;
	public static  int count = 0;
	List<ITestNGMethod> passedtests = new ArrayList<ITestNGMethod>();
	List<ITestNGMethod> failedtests = new ArrayList<ITestNGMethod>();
	List<ITestNGMethod> skippedtests = new ArrayList<ITestNGMethod>();
	
	String currnetlocation = System.getProperty("user.dir");
	//String filePath = currnetlocation + "\\ScreenShots\\";

//	private static String fileSeperator = System.getProperty("file.separator");
	
	
	public String timeStamp = new SimpleDateFormat("yyyy-MM-dd-HH:mm:ss").format(new Date());
	 
	JSONParser parser = new JSONParser();
		
	
	public void onTestStart(ITestResult result) {
		String methodName = result.getName().toString().trim();
		String classNAme = result.getInstanceName().toString();
		System.out.println("Started Test Method--->"+classNAme +"-->"+methodName);
		//logger = reports.startTest(result.getMethod().getMethodName());
	//	logger.log(LogStatus.INFO, result.getMethod().getMethodName() + "test is started");
		count++;
		System.out.println("Number of Test Method --->" +count);
	}
	public void onTestSuccess(ITestResult result) {
		Reporter.log("Test case PAssed "+result.getTestName());
	
		passedtests.add(result.getMethod());
	}

	public void onTestFailure(ITestResult result) {
		System.out.println("***** Error " + result.getName() + " test has failed *****");
		failedtests.add(result.getMethod());
	}



	public void onTestSkipped(ITestResult result) {
	//	logger.log(LogStatus.SKIP, result.getMethod().getMethodName() + "test is skipped");
		skippedtests.add(result.getMethod());
	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	public void onStart(ITestContext context) {
		String fileName =System.getProperty("user.dir") + "\\test-output\\"+ new SimpleDateFormat("yyyy-MM-dd-hh-mm-ss-ms").format(new Date()) + "Reports.html";
	//	reports = new ExtentReports(fileName);
	//	System.out.println("$Reports file name : "+fileName);
		context.setAttribute("fileName", fileName);
	}
	
	public void onFinish(ITestContext context) {
		int testcount = TestListeners.count;
		System.out.println("Number of Test Method from TL  =" + testcount);
		SLog sl = new SLog();
		sl.createWDBLog(0, testcount);
		 }

}
