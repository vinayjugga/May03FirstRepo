package com.diversey.dm.api.testcases;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


import org.testng.Assert;
import org.testng.annotations.Test;

import com.diversey.dm.model.DeviceRegistration;
import com.diversey.dm.utility.CreateURLByEndpoint;
import com.diversey.dm.utility.DataBaseConnector;
import com.diversey.dm.utility.MQTTUtility;
import com.diversey.dm.utility.RandomString;
import com.diversey.dm.utility.TestDataExcelUtility;
import com.google.common.base.Verify;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class DeviceRegistrationTest {

	TestDataExcelUtility testData =new TestDataExcelUtility();
	CreateURLByEndpoint endPoint = new CreateURLByEndpoint();
	DataBaseConnector dbConnector = new DataBaseConnector();
	DeviceRegistration postDevice ;
	static DeviceRegistration respPostDevice;

	// 1. To POST a device registration
	@Test(priority=1)
	public void deviceReg_POST() throws IOException
	{

		RequestSpecification request = RestAssured.given();
		String url = endPoint.getDeviceURL();	
		System.out.println("POST URL:" + url);
		List<Header> headerList = new ArrayList<>();
		Header header1 = new Header("Content-Type", testData.readExcel("Header", "Content-Type"));
		Header header2 = new Header("Authorization", testData.readExcel("Header", "Authorization"));
		Header header3 = new Header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_POST"));

		headerList.add(header1);
		headerList.add(header2);
		headerList.add(header3);
		Headers headers = new Headers(headerList);
		request.headers(headers);

		postDevice= new DeviceRegistration();
		postDevice.setDeviceMac(RandomString.randomMACAddress());
		postDevice.setDevicePhoneNumber(RandomString.getAlphaNumericString(15));
		postDevice.setDeviceType(testData.readExcel("Device", "DeviceType"));
		postDevice.setFirmwareVersion(testData.readExcel("Device", "FirmwareVersion"));
		postDevice.setManufactureDate(testData.readExcel("Device", "ManufactureDate"));
		postDevice.setManufacturer(testData.readExcel("Device", "Manufacturer"));
		postDevice.setSerialNumber(RandomString.getAlphaNumericString(15));
		postDevice.setServiceLine(testData.readExcel("Device", "ServiceLine"));
		postDevice.setUser(testData.readExcel("Device", "UserId"));
		postDevice.setReaderFirmwareVersion(testData.readExcel("Device", "RdrFirmwareVersion"));
		postDevice.setSimNumber(RandomString.getAlphaNumericString(15));
		postDevice.setSimType(testData.readExcel("Device", "SimType"));
		postDevice.addKeyValue("Scripttest11","Value4");
		Gson gson = new Gson();
		String jsonInString = gson.toJson(postDevice);
		request.body(jsonInString);

		Response Resp =request.post(url);
		ResponseBody body = Resp.getBody();
		System.out.println("response status code is :" + Resp.getStatusCode());
		System.out.println("response body :" + Resp.getBody());
		respPostDevice = new DeviceRegistration();
		respPostDevice  = body.as(DeviceRegistration.class);
		Assert.assertEquals(Resp.getStatusCode(), 201);
		Assert.assertEquals(respPostDevice.getSerialNumber(),postDevice.getSerialNumber());

		String sqlQuery = "Select count(*) from device where serial_number='"+respPostDevice.getSerialNumber()+"';";
		String result = dbConnector.executeSQLQuery(sqlQuery);
		System.out.println(result);
		Assert.assertNotNull(result);

	}
/*
	// 2. To verify for error status code when mandatory parameters are null in request payload
	@Test(priority=2)
	public void deviceReg_POST_mandatory() throws IOException
	{

		RequestSpecification request = RestAssured.given();
		String url = endPoint.getDeviceURL();	
		System.out.println("POST URL:" + url);
		List<Header> headerList = new ArrayList<>();
		Header header1 = new Header("Content-Type", testData.readExcel("Header", "Content-Type"));
		Header header2 = new Header("Authorization", testData.readExcel("Header", "Authorization"));
		Header header3 = new Header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_POST"));

		headerList.add(header1);
		headerList.add(header2);
		headerList.add(header3);
		Headers headers = new Headers(headerList);
		request.headers(headers);
		//verify if error is thrown if serial number is null in request payload
		DeviceRegistration postDevice1 = new DeviceRegistration();
		postDevice1.setDeviceType(testData.readExcel("Device", "DeviceType"));
		postDevice1.setFirmwareVersion(testData.readExcel("Device", "FirmwareVersion"));
		postDevice1.setManufactureDate(testData.readExcel("Device", "ManufactureDate"));
		postDevice1.setManufacturer(testData.readExcel("Device", "Manufacturer"));
		postDevice1.setServiceLine(testData.readExcel("Device", "ServiceLine"));
		postDevice1.setUser(testData.readExcel("Device", "UserId"));
		Gson gson = new Gson();
		String jsonInString = gson.toJson(postDevice1);
		request.body(jsonInString);
		Response Resp =request.post(url);
		ResponseBody body = Resp.getBody();
		Assert.assertEquals(Resp.getStatusCode(), 404);
		postDevice1 = new DeviceRegistration();

		//verify if error is thrown if service line is null in request payload

		postDevice1.setDeviceType(testData.readExcel("Device", "DeviceType"));
		postDevice1.setFirmwareVersion(testData.readExcel("Device", "FirmwareVersion"));
		postDevice1.setManufactureDate(testData.readExcel("Device", "ManufactureDate"));
		postDevice1.setManufacturer(testData.readExcel("Device", "Manufacturer"));
		postDevice1.setSerialNumber(RandomString.getAlphaNumericString(15));
		postDevice1.setUser(testData.readExcel("Device", "UserId"));
		jsonInString = gson.toJson(postDevice1);
		request.body(jsonInString);
		Resp =request.post(url);
		body = Resp.getBody();
		Assert.assertEquals(Resp.getStatusCode(), 400);
		postDevice1 = new DeviceRegistration();

		//verify if error is thrown if device type is null in request payload
		postDevice1.setServiceLine(testData.readExcel("Device", "ServiceLine"));
		postDevice1.setFirmwareVersion(testData.readExcel("Device", "FirmwareVersion"));
		postDevice1.setManufactureDate(testData.readExcel("Device", "ManufactureDate"));
		postDevice1.setManufacturer(testData.readExcel("Device", "Manufacturer"));
		postDevice1.setSerialNumber(RandomString.getAlphaNumericString(15));
		postDevice1.setUser(testData.readExcel("Device", "UserId"));
		jsonInString = gson.toJson(postDevice1);
		request.body(jsonInString);
		Resp =request.post(url);
		body = Resp.getBody();
		Assert.assertEquals(Resp.getStatusCode(), 400);
		postDevice1 = new DeviceRegistration();

		//verify if error is thrown if manufacture date is null in request payload
		postDevice1.setServiceLine(testData.readExcel("Device", "ServiceLine"));
		postDevice1.setFirmwareVersion(testData.readExcel("Device", "FirmwareVersion"));
		postDevice1.setDeviceType(testData.readExcel("Device", "DeviceType"));
		postDevice1.setManufacturer(testData.readExcel("Device", "Manufacturer"));
		postDevice1.setSerialNumber(RandomString.getAlphaNumericString(15));
		postDevice1.setUser(testData.readExcel("Device", "UserId"));
		jsonInString = gson.toJson(postDevice1);
		request.body(jsonInString);
		Resp =request.post(url);
		body = Resp.getBody();
		Assert.assertEquals(Resp.getStatusCode(), 400);
		postDevice1 = new DeviceRegistration();

		//verify if error is thrown if manufacturer is null in request payload
		postDevice1.setServiceLine(testData.readExcel("Device", "ServiceLine"));
		postDevice1.setFirmwareVersion(testData.readExcel("Device", "FirmwareVersion"));
		postDevice1.setManufactureDate(testData.readExcel("Device", "ManufactureDate"));
		postDevice1.setDeviceType(testData.readExcel("Device", "DeviceType"));
		postDevice1.setSerialNumber(RandomString.getAlphaNumericString(15));
		postDevice1.setUser(testData.readExcel("Device", "UserId"));
		jsonInString = gson.toJson(postDevice1);
		request.body(jsonInString);
		Resp =request.post(url);
		body = Resp.getBody();
		Assert.assertEquals(Resp.getStatusCode(), 400);

	}

	// 3. To verify for error status code when parameters are not as per format in request payload
	@Test(priority=3)
	public void deviceReg_POST_format() throws IOException
	{

		RequestSpecification request = RestAssured.given();
		String url = endPoint.getDeviceURL();	
		System.out.println("POST URL:" + url);
		List<Header> headerList = new ArrayList<>();
		Header header1 = new Header("Content-Type", testData.readExcel("Header", "Content-Type"));
		Header header2 = new Header("Authorization", testData.readExcel("Header", "Authorization"));
		Header header3 = new Header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_POST"));

		headerList.add(header1);
		headerList.add(header2);
		headerList.add(header3);
		Headers headers = new Headers(headerList);
		request.headers(headers);
		//verify if error is thrown if MAC Address is not as per format in request payload
		DeviceRegistration postDevice1 = new DeviceRegistration();
		postDevice1.setDeviceType(testData.readExcel("Device", "DeviceType"));
		postDevice1.setFirmwareVersion(testData.readExcel("Device", "FirmwareVersion"));
		postDevice1.setManufactureDate(testData.readExcel("Device", "ManufactureDate"));
		postDevice1.setManufacturer(testData.readExcel("Device", "Manufacturer"));
		postDevice1.setServiceLine(testData.readExcel("Device", "ServiceLine"));
		postDevice1.setUser(testData.readExcel("Device", "UserId"));
		postDevice1.setSerialNumber(RandomString.getAlphaNumericString(15));
		postDevice1.setDeviceMac("deviceMAC");
		Gson gson = new Gson();
		String jsonInString = gson.toJson(postDevice1);
		request.body(jsonInString);
		Response Resp =request.post(url);
		ResponseBody body = Resp.getBody();
		System.out.println("response status is :" + Resp.getStatusCode());
		//Assert.assertEquals(Resp.getStatusCode(), 404);
		postDevice1 = new DeviceRegistration();

		//verify if error is thrown if ManufactureDate is not as per format in request payload
		postDevice1.setDeviceType(testData.readExcel("Device", "DeviceType"));
		postDevice1.setFirmwareVersion(testData.readExcel("Device", "FirmwareVersion"));
		postDevice1.setManufactureDate("2019-02-04");
		postDevice1.setManufacturer(testData.readExcel("Device", "Manufacturer"));
		postDevice1.setServiceLine(testData.readExcel("Device", "ServiceLine"));
		postDevice1.setUser(testData.readExcel("Device", "UserId"));
		postDevice1.setSerialNumber(RandomString.getAlphaNumericString(15));


		jsonInString = gson.toJson(postDevice1);
		request.body(jsonInString);
		Resp =request.post(url);
		body = Resp.getBody();
		System.out.println("response status is :" + Resp.getStatusCode());
		Assert.assertEquals(Resp.getStatusCode(), 404);
		postDevice1 = new DeviceRegistration();
	}

	// 4. To verify for error status code when parameters are not unique in request payload
	@Test(priority=4)
	public void deviceReg_POST_unique() throws IOException
	{

		RequestSpecification request = RestAssured.given();
		String url = endPoint.getDeviceURL();	
		System.out.println("POST URL:" + url);
		List<Header> headerList = new ArrayList<>();
		Header header1 = new Header("Content-Type", testData.readExcel("Header", "Content-Type"));
		Header header2 = new Header("Authorization", testData.readExcel("Header", "Authorization"));
		Header header3 = new Header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_POST"));

		headerList.add(header1);
		headerList.add(header2);
		headerList.add(header3);
		Headers headers = new Headers(headerList);
		request.headers(headers);
		//verify if error is thrown if MAC Address is not unique in request payload
		DeviceRegistration postDevice1 = new DeviceRegistration();
		postDevice1.setDeviceType(testData.readExcel("Device", "DeviceType"));
		postDevice1.setFirmwareVersion(testData.readExcel("Device", "FirmwareVersion"));
		postDevice1.setManufactureDate(testData.readExcel("Device", "ManufactureDate"));
		postDevice1.setManufacturer(testData.readExcel("Device", "Manufacturer"));
		postDevice1.setServiceLine(testData.readExcel("Device", "ServiceLine"));
		postDevice1.setUser(testData.readExcel("Device", "UserId"));
		postDevice1.setSerialNumber(RandomString.getAlphaNumericString(15));
		postDevice1.setDeviceMac(respPostDevice.getDeviceMac());
		Gson gson = new Gson();
		String jsonInString = gson.toJson(postDevice1);
		request.body(jsonInString);
		Response Resp =request.post(url);
		ResponseBody body = Resp.getBody();
		//System.out.println("response status is :" + Resp.getStatusCode());
		//Assert.assertEquals(Resp.getStatusCode(), 404);
		postDevice1 = new DeviceRegistration();

		//verify if error is thrown if serialNumber is not unique in request payload
		postDevice1.setDeviceType(testData.readExcel("Device", "DeviceType"));
		postDevice1.setFirmwareVersion(testData.readExcel("Device", "FirmwareVersion"));
		postDevice1.setManufactureDate(testData.readExcel("Device", "ManufactureDate"));
		postDevice1.setManufacturer(testData.readExcel("Device", "Manufacturer"));
		postDevice1.setServiceLine(testData.readExcel("Device", "ServiceLine"));
		postDevice1.setUser(testData.readExcel("Device", "UserId"));
		postDevice1.setSerialNumber(postDevice.getSerialNumber());

		jsonInString = gson.toJson(postDevice1);
		request.body(jsonInString);
		Resp =request.post(url);
		body = Resp.getBody();
		//System.out.println("response status is :" + Resp.getStatusCode());
		Assert.assertEquals(Resp.getStatusCode(), 404);
		postDevice1 = new DeviceRegistration();
	}
	// 5. To verify for error status code when some parameters in request payload are not available in db
	@Test(priority=5)
	public void deviceReg_POST_UnavailableInDB() throws IOException
	{

		RequestSpecification request = RestAssured.given();
		String url = endPoint.getDeviceURL();	
		System.out.println("POST URL:" + url);
		List<Header> headerList = new ArrayList<>();
		Header header1 = new Header("Content-Type", testData.readExcel("Header", "Content-Type"));
		Header header2 = new Header("Authorization", testData.readExcel("Header", "Authorization"));
		Header header3 = new Header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_POST"));

		headerList.add(header1);
		headerList.add(header2);
		headerList.add(header3);
		Headers headers = new Headers(headerList);
		request.headers(headers);
		//verify if error is thrown if device type in request payload is not present in db.
		DeviceRegistration postDevice1 = new DeviceRegistration();
		postDevice1.setDeviceType("devicetype");
		postDevice1.setFirmwareVersion(testData.readExcel("Device", "FirmwareVersion"));
		postDevice1.setManufactureDate(testData.readExcel("Device", "ManufactureDate"));
		postDevice1.setManufacturer(testData.readExcel("Device", "Manufacturer"));
		postDevice1.setServiceLine(testData.readExcel("Device", "ServiceLine"));
		postDevice1.setUser(testData.readExcel("Device", "UserId"));
		postDevice1.setSerialNumber(RandomString.getAlphaNumericString(15));
		postDevice1.setDeviceMac(RandomString.randomMACAddress());
		Gson gson = new Gson();
		String jsonInString = gson.toJson(postDevice1);
		request.body(jsonInString);
		Response Resp =request.post(url);
		ResponseBody body = Resp.getBody();
		System.out.println("unavailable in db: response status is :" + Resp.getStatusCode());
		//Assert.assertEquals(Resp.getStatusCode(), 404);
		postDevice1 = new DeviceRegistration();

		//verify if error is thrown if serviceLine in request payload is not in DB.
		postDevice1.setDeviceType(testData.readExcel("Device", "DeviceType"));
		postDevice1.setFirmwareVersion(testData.readExcel("Device", "FirmwareVersion"));
		postDevice1.setManufactureDate(testData.readExcel("Device", "ManufactureDate"));
		postDevice1.setManufacturer(testData.readExcel("Device", "Manufacturer"));
		postDevice1.setServiceLine("serviceline");
		postDevice1.setUser(testData.readExcel("Device", "UserId"));
		postDevice1.setSerialNumber(RandomString.getAlphaNumericString(15));

		jsonInString = gson.toJson(postDevice1);
		request.body(jsonInString);
		Resp =request.post(url);
		body = Resp.getBody();
		//System.out.println("response status is :" + Resp.getStatusCode());
		Assert.assertEquals(Resp.getStatusCode(), 404);
		postDevice1 = new DeviceRegistration();

		//verify if error is thrown if manufacturer in request payload is not in DB.
		postDevice1.setDeviceType(testData.readExcel("Device", "DeviceType"));
		postDevice1.setFirmwareVersion(testData.readExcel("Device", "FirmwareVersion"));
		postDevice1.setManufactureDate(testData.readExcel("Device", "ManufactureDate"));
		postDevice1.setManufacturer("manufacturer");
		postDevice1.setServiceLine(testData.readExcel("Device", "ServiceLine"));
		postDevice1.setUser(testData.readExcel("Device", "UserId"));
		postDevice1.setSerialNumber(RandomString.getAlphaNumericString(15));
		jsonInString = gson.toJson(postDevice1);
		request.body(jsonInString);
		Resp =request.post(url);
		body = Resp.getBody();
		//System.out.println("response status is :" + Resp.getStatusCode());
		Assert.assertEquals(Resp.getStatusCode(), 404);	
	}

	// 6. To verify for error status code when unauthorised header is sent 
	@Test(priority=6)
	public void deviceReg_POST_UnauthorizedHeader() throws IOException
	{

		RequestSpecification request = RestAssured.given();
		String url = endPoint.getDeviceURL();	
		System.out.println("POST URL:" + url);
		List<Header> headerList = new ArrayList<>();
		Header header1 = new Header("Content-Type", testData.readExcel("Header", "Content-Type"));
		Header header2 = new Header("Authorization", testData.readExcel("Header", "Authorization"));
		Header header3 = new Header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_GET"));

		headerList.add(header1);
		headerList.add(header2);
		headerList.add(header3);
		Headers headers = new Headers(headerList);
		request.headers(headers);
		//verify if error is thrown if error is thrown if unauthorised header is sent.
		DeviceRegistration postDevice1 = new DeviceRegistration();
		postDevice1.setDeviceType(testData.readExcel("Device", "DeviceType"));
		postDevice1.setFirmwareVersion(testData.readExcel("Device", "FirmwareVersion"));
		postDevice1.setManufactureDate(testData.readExcel("Device", "ManufactureDate"));
		postDevice1.setManufacturer(testData.readExcel("Device", "Manufacturer"));
		postDevice1.setServiceLine(testData.readExcel("Device", "ServiceLine"));
		postDevice1.setUser(testData.readExcel("Device", "UserId"));
		postDevice1.setSerialNumber(RandomString.getAlphaNumericString(15));
		postDevice1.setDeviceMac(RandomString.randomMACAddress());
		Gson gson = new Gson();
		String jsonInString = gson.toJson(postDevice1);
		request.body(jsonInString);
		Response Resp =request.post(url);
		ResponseBody body = Resp.getBody();
		System.out.println("unauthorised header: response status is :" + Resp.getStatusCode());
		Assert.assertEquals(Resp.getStatusCode(), 401);
		postDevice1 = new DeviceRegistration();

	}

	// 7. To verify for error status code when Incorrect Url is sent 
	@Test(priority=7)
	public void deviceReg_POST_IncorrectURL() throws IOException
	{

		RequestSpecification request = RestAssured.given();
		String url = endPoint.getDeviceURL()+"incorrect";	
		System.out.println("POST URL:" + url);
		List<Header> headerList = new ArrayList<>();
		Header header1 = new Header("Content-Type", testData.readExcel("Header", "Content-Type"));
		Header header2 = new Header("Authorization", testData.readExcel("Header", "Authorization"));
		Header header3 = new Header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_POST"));

		headerList.add(header1);
		headerList.add(header2);
		headerList.add(header3);
		Headers headers = new Headers(headerList);
		request.headers(headers);
		//verify if error is thrown if error is thrown if incorrect is sent.
		DeviceRegistration postDevice1 = new DeviceRegistration();
		postDevice1.setDeviceType(testData.readExcel("Device", "DeviceType"));
		postDevice1.setFirmwareVersion(testData.readExcel("Device", "FirmwareVersion"));
		postDevice1.setManufactureDate(testData.readExcel("Device", "ManufactureDate"));
		postDevice1.setManufacturer(testData.readExcel("Device", "Manufacturer"));
		postDevice1.setServiceLine(testData.readExcel("Device", "ServiceLine"));
		postDevice1.setUser(testData.readExcel("Device", "UserId"));
		postDevice1.setSerialNumber(RandomString.getAlphaNumericString(15));
		postDevice1.setDeviceMac(RandomString.randomMACAddress());
		Gson gson = new Gson();
		String jsonInString = gson.toJson(postDevice1);
		request.body(jsonInString);
		Response Resp =request.post(url);
		ResponseBody body = Resp.getBody();
		Verify.verify(Resp.getStatusCode()==404);			
	}
	// 8. To  verify if the configuration is as per device type, firmware and sim type 
	@Test(priority=8)
	public void deviceReg_POST_Configuration() throws IOException
	{
		//System.out.println("device in configuration test case:"+respPostDevice.getSerialNumber());
		String query = "Select json_config_payload from device where serial_number='"+respPostDevice.getSerialNumber()+"'";
		String jsonResult = dbConnector.executeSQLQuery(query);
		//System.out.println("reslt of configuration:"+ result);
		JsonObject deviceConfigJson = new JsonParser().parse(jsonResult).getAsJsonObject();
		Verify.verify(deviceConfigJson.get("fw").toString().contains(respPostDevice.getFirmwareVersion()));
		String simTypeQuery = "Select apn from sim_type where name='"+respPostDevice.getSimType()+"'";
		String simTyperesult = dbConnector.executeSQLQuery(simTypeQuery);
		Verify.verify(deviceConfigJson.get("apn").toString().contains(simTyperesult));
		String paramGroupQuery = "Select param_group from initial_params where device_type='"+respPostDevice.getDeviceType()+"'";
		ArrayList<String> result = dbConnector.executeSQLQuery_List(paramGroupQuery);
		Iterator i = result.iterator();
		while(i.hasNext())
		{
			String paramGroup = i.next().toString();
			//System.out.println("paramgroup from initial_params table:"+paramGroup);
			if(!paramGroup.equals("default"))
			{
				//System.out.println("inside if paramgroup is not default");
				JsonArray array = deviceConfigJson.get(paramGroup).getAsJsonArray();
				//System.out.println("json value of paramgroup::"+array);
				JsonObject paramValue = array.get(0).getAsJsonObject();
				//System.out.println("json value of paramgroup::"+paramValue);
				String paramValueQuery = "Select udf.param_name, udf.param_value from initial_params_udf udf, initial_params params "
						+ "where udf.id= params.id and params.device_type='" + respPostDevice.getDeviceType()
						+ "' and params.param_group='" + paramGroup+ "'";
				//System.out.println(paramValueQuery);
				Map<String,String>  paramValueresult = dbConnector.executeSQLQuery_List_Map(paramValueQuery);
				//System.out.println("after getting param values from db");
				Iterator<Map.Entry<String, String>> itr = paramValueresult.entrySet().iterator();
				while(itr.hasNext())
				{
					Map.Entry<String, String> paramNameValue =itr.next();
					//System.out.println(paramNameValue.getKey()+":::"+paramNameValue.getValue());
					//System.out.println("from device config value::"+ paramValue.get(paramNameValue.getKey()));
					//System.out.println("from db map::" + "\""+ paramNameValue.getValue() +"\"");
					Verify.verify((paramValue.get(paramNameValue.getKey()).toString()).equals("\""+ paramNameValue.getValue() +"\""));

				}
			}
		}
	}

	// 9. To  verify if the configuration is 1 and the configuration is published to MQTT. 
	@Test(priority=9)
	public void deviceReg_POST_ConfigtoMQTT() throws IOException
	{
		//System.out.println("device in configuration test case:"+respPostDevice.getSerialNumber());
		String query = "Select config_version from device where serial_number='"+respPostDevice.getSerialNumber()+"'";
		String configVersion = dbConnector.executeSQLQuery(query);
		//System.out.println("reslt of configuration:"+ result);
		Verify.verify(configVersion.equals("1"));
		//Connect to MQTT Broker and subscribe to the topic if configuration is published.
		MQTTUtility mqttUtility = new MQTTUtility();
		mqttUtility.MQTTSubscriber(respPostDevice.getSerialNumber(),configVersion, true);
		mqttUtility.MQTTSubscriber(respPostDevice.getSerialNumber(),configVersion, false);

	}

	// 10. To  verify if the configuration is 0 and the configuration is taken as backup in DB. 
	@Test(priority=10)
	public void deviceReg_POST_ConfigBackup() throws IOException
	{
		//System.out.println("device in configuration test case:"+respPostDevice.getSerialNumber());
		String query = "Select count(*) from device_config_hist where serial_number='"+respPostDevice.getSerialNumber()+"' and version='0'" ;
		String result = dbConnector.executeSQLQuery(query);
		//System.out.println("reslt of configuration:"+ result);
		Verify.verify(Integer.parseInt(result)==1);
	}

	// 11. To Verify GET request with one Device id
	@Test(priority=11)
	public void deviceReg_GETByID() throws IOException{
		RequestSpecification request = RestAssured.given();
		System.out.println("inside get:"+ respPostDevice.getSerialNumber());
		String url = endPoint.getDeviceURL() +"/"+ respPostDevice.getSerialNumber();
		System.out.println("Get By Id URL:" + url);
		request.header("Content-Type", testData.readExcel("Header", "Content-Type"));
		request.header("Authorization",testData.readExcel("Header", "Authorization"));
		request.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_GET"));
		Response response =request.get(url);

		DeviceRegistration[] device = response.getBody().as(DeviceRegistration[].class);
		System.out.println("serial number in response:" + device[0].getSerialNumber());
		Assert.assertEquals(device[0].getSerialNumber(), respPostDevice.getSerialNumber());

		Assert.assertEquals(response.getStatusCode(), 200);

		String sqlQuery = "Select count(*) from device where serial_number='"+respPostDevice.getSerialNumber()+"';";
		String result = dbConnector.executeSQLQuery(sqlQuery);
		System.out.println(result);
		Assert.assertNotNull(result);
	}

	// 12. To Verify GET request with one Device id with unauthorized header
	@Test(priority=12)
	public void deviceReg_GETByID_unauthorized() throws IOException{
		RequestSpecification request = RestAssured.given();
		System.out.println("inside get:"+ respPostDevice.getSerialNumber());
		String url = endPoint.getDeviceURL() +"/"+ respPostDevice.getSerialNumber();
		System.out.println("Get By Id URL:" + url);
		request.header("Content-Type", testData.readExcel("Header", "Content-Type"));
		request.header("Authorization",testData.readExcel("Header", "Authorization"));
		request.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_POST"));
		Response response =request.get(url);

		Assert.assertEquals(response.getStatusCode(), 401);
	}

	// 13. To Verify if proper error is thrown with GET request when device id is not present in db.
	@Test(priority=13)
	public void deviceReg_GETByID_NotFoundinDB() throws IOException{
		RequestSpecification request = RestAssured.given();
		System.out.println("inside get:"+ respPostDevice.getSerialNumber());
		String url = endPoint.getDeviceURL() +"/"+ RandomString.getAlphaNumericString(15) ;
		System.out.println("Get By Id URL:" + url);
		request.header("Content-Type", testData.readExcel("Header", "Content-Type"));
		request.header("Authorization",testData.readExcel("Header", "Authorization"));
		request.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_GET"));
		Response response =request.get(url);
		System.out.println("get by id body is::" + response.asString());
		Assert.assertEquals(response.getStatusCode(), 404);
	}

	// 14. To verify GET ALL request for Device_Registration
	@Test(priority=14)
	public void Device_Registration_GETALL() throws IOException
	{
		RequestSpecification request = RestAssured.given();
		String url = endPoint.getDevicesURL(); 

		request.header("Content-Type", testData.readExcel("Header", "Content-Type"));
		request.header("Authorization",testData.readExcel("Header", "Authorization"));
		request.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_GET"));
		Response response =request.get(url);
		DeviceRegistration[] device = response.getBody().as(DeviceRegistration[].class);

		int respLength = device.length;
		String sqlQuery = "Select count(*) from device where delete_status='1';";
		String result = dbConnector.executeSQLQuery(sqlQuery);
		Assert.assertEquals(respLength, Integer.parseInt(result));

		Assert.assertEquals(response.getStatusCode(), 200);
	}
	// 15. To verify Error of GET request for Device_Registration incorrect url
	@Test(priority=15)
	public void Device_Registration_GET_IncorrectURL() throws IOException
	{
		RequestSpecification request = RestAssured.given();
		String url = endPoint.getDevicesURL()+"es"; 

		request.header("Content-Type", testData.readExcel("Header", "Content-Type"));
		request.header("Authorization",testData.readExcel("Header", "Authorization"));
		request.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_GET"));
		Response response =request.get(url);
		Assert.assertEquals(response.getStatusCode(), 404);
	}
	// 16. To verify Error of GET request for unauthorized header
	@Test(priority=16)
	public void Device_Registration_GET_UnauthorizedHeader() throws IOException
	{
		RequestSpecification request = RestAssured.given();
		String url = endPoint.getDevicesURL(); 

		request.header("Content-Type", testData.readExcel("Header", "Content-Type"));
		request.header("Authorization",testData.readExcel("Header", "Authorization"));
		request.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_POST"));
		Response response =request.get(url);
		Assert.assertEquals(response.getStatusCode(), 401);
	}
	//17. To verify PUT request
	@Test(priority=17)
	public void Device_Registration_Put() throws IOException
	{
		RequestSpecification request = RestAssured.given();
		RequestSpecification putRequest = RestAssured.given();
		String url = endPoint.getDeviceURL() +"/"+ respPostDevice.getSerialNumber();
		System.out.println("Get By Id URL:" + url);
		request.header("Content-Type", testData.readExcel("Header", "Content-Type"));
		request.header("Authorization",testData.readExcel("Header", "Authorization"));
		request.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_GET"));
		Response response =request.get(url);
		DeviceRegistration[] device = response.getBody().as(DeviceRegistration[].class);

		putRequest.header("Content-Type", testData.readExcel("Header", "Content-Type"));
		putRequest.header("Authorization",testData.readExcel("Header", "Authorization"));
		putRequest.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_PUT"));
		//device[0].setDevicePhoneNumber(testData.readExcel("Device", "DevicePhoneNumber_Update"));
		device[0].setManufactureDate(testData.readExcel("Device", "ManufactureDate"));
		device[0].addKeyValue("Scripttest11","Value4");
		DeviceRegistration requestDevice = device[0];
		Gson gson = new Gson();
		String jsonInString = gson.toJson(requestDevice);
		putRequest.body(jsonInString);
		Response putResponse =putRequest.put(url);
		DeviceRegistration putrespPostDevice = putResponse.as(DeviceRegistration.class);
		Assert.assertEquals(putResponse.getStatusCode(), 200);
		Assert.assertEquals(putrespPostDevice.getSerialNumber(), requestDevice.getSerialNumber());
		//Assert.assertEquals(putrespPostDevice.getDevicePhoneNumber(), testData.readExcel("Device", "DevicePhoneNumber_Update"));
		Assert.assertEquals(putrespPostDevice.getManufactureDate(),testData.readExcel("Device", "ManufactureDate"));
	}

	//18. To verify PUT request with change in fw, rdr fw, sim type
	@Test(priority=18)
	public void Device_Registration_Put_ConfigChange() throws IOException
	{
		RequestSpecification request = RestAssured.given();
		RequestSpecification putRequest = RestAssured.given();
		String url = endPoint.getDeviceURL() +"/"+ respPostDevice.getSerialNumber();
		System.out.println("Get By Id URL:" + url);
		request.header("Content-Type", testData.readExcel("Header", "Content-Type"));
		request.header("Authorization",testData.readExcel("Header", "Authorization"));
		request.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_GET"));
		Response response =request.get(url);
		DeviceRegistration[] device = response.getBody().as(DeviceRegistration[].class);

		putRequest.header("Content-Type", testData.readExcel("Header", "Content-Type"));
		putRequest.header("Authorization",testData.readExcel("Header", "Authorization"));
		putRequest.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_PUT"));
		device[0].setFirmwareVersion(testData.readExcel("Device", "FirmwareVersion_Update"));
		device[0].setReaderFirmwareVersion(testData.readExcel("Device", "RdrFirmwareVersion_Update"));
		device[0].setSimType(testData.readExcel("Device", "SimType_Update"));
		DeviceRegistration requestDevice = device[0];

		// get config version from device table before PUT request.
		String sqlQuery = "select config_version from device where serial_number='"+device[0].getSerialNumber()+"'";
		String configVersion = dbConnector.executeSQLQuery(sqlQuery);
		int configVersionInt = Integer.parseInt(configVersion);

		//verify if details are updated in response object.
		Gson gson = new Gson();
		String jsonInString = gson.toJson(requestDevice);
		putRequest.body(jsonInString);
		Response putResponse =putRequest.put(url);
		DeviceRegistration putrespPostDevice = putResponse.as(DeviceRegistration.class);
		Assert.assertEquals(putResponse.getStatusCode(), 200);
		Assert.assertEquals(putrespPostDevice.getSerialNumber(), requestDevice.getSerialNumber());
		Assert.assertEquals(putrespPostDevice.getSimType(), testData.readExcel("Device", "SimType_Update"));
		Assert.assertEquals(putrespPostDevice.getFirmwareVersion(),testData.readExcel("Device", "FirmwareVersion_Update"));
		Assert.assertEquals(putrespPostDevice.getReaderFirmwareVersion(),testData.readExcel("Device", "RdrFirmwareVersion_Update"));

		//verify if config version is incremented.
		sqlQuery = "select config_version from device where serial_number='"+device[0].getSerialNumber()+"'";
		configVersion = dbConnector.executeSQLQuery(sqlQuery);
		int versionAfterEdit = Integer.parseInt(configVersion);
		Assert.assertEquals(versionAfterEdit, configVersionInt+1);

		//Verify if configuration is updated with fw, rdr fw and simtype values
		String query = "Select json_config_payload from device where serial_number='"+device[0].getSerialNumber()+"'";
		String jsonResult = dbConnector.executeSQLQuery(query);
		//System.out.println("reslt of configuration:"+ result);
		JsonObject deviceConfigJson = new JsonParser().parse(jsonResult).getAsJsonObject();
		Verify.verify(deviceConfigJson.get("fw").toString().contains(device[0].getFirmwareVersion()));
		Verify.verify(deviceConfigJson.get("rdr fw").toString().contains(device[0].getReaderFirmwareVersion()));
		String simTypeQuery = "Select apn from sim_type where name='"+device[0].getSimType()+"'";
		String simTyperesult = dbConnector.executeSQLQuery(simTypeQuery);
		Verify.verify(deviceConfigJson.get("apn").toString().contains(simTyperesult));

		//Verify if the configuration is taken backup
		//System.out.println("device in configuration test case:"+respPostDevice.getSerialNumber());
		query = "Select count(*) from device_config_hist where serial_number='"+device[0].getSerialNumber()+"' and version='" + configVersionInt + "'" ;
		String result = dbConnector.executeSQLQuery(query);
		//System.out.println("reslt of configuration:"+ result);
		Verify.verify(Integer.parseInt(result)==1);

		//Verify if configuration is published
		MQTTUtility mqttUtility = new MQTTUtility();
		mqttUtility.MQTTSubscriber(device[0].getSerialNumber(),configVersion, true);
		mqttUtility.MQTTSubscriber(device[0].getSerialNumber(),configVersion, false);

	}
	//19. To verify PUT request throws error if unauthorised header is sent
	@Test(priority=19)
	public void Device_Registration_Put_unauthorised() throws IOException
	{
		RequestSpecification request = RestAssured.given();
		RequestSpecification putRequest = RestAssured.given();
		String url = endPoint.getDeviceURL() +"/"+ respPostDevice.getSerialNumber();
		System.out.println("Get By Id URL:" + url);
		request.header("Content-Type", testData.readExcel("Header", "Content-Type"));
		request.header("Authorization",testData.readExcel("Header", "Authorization"));
		request.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_GET"));
		Response response =request.get(url);
		DeviceRegistration[] device = response.getBody().as(DeviceRegistration[].class);


		System.out.println("Get By Id URL:" + url);
		putRequest.header("Content-Type", testData.readExcel("Header", "Content-Type"));
		putRequest.header("Authorization",testData.readExcel("Header", "Authorization"));
		putRequest.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_GET"));
		device[0].setDevicePhoneNumber(testData.readExcel("Device", "DevicePhoneNumber_Update"));
		device[0].addKeyValue("Scripttest11","Value4");
		DeviceRegistration requestDevice = device[0];
		Gson gson = new Gson();
		String jsonInString = gson.toJson(requestDevice);
		putRequest.body(jsonInString);
		Response putResponse =putRequest.put(url);
		Assert.assertEquals(putResponse.getStatusCode(), 401);
	}
	//20. To verify PUT request throws error if incorrect url is sent
	@Test(priority=20)
	public void Device_Registration_Put_IncorrectURL() throws IOException
	{
		RequestSpecification request = RestAssured.given();
		RequestSpecification putRequest = RestAssured.given();
		String url = endPoint.getDeviceURL() +"/"+ respPostDevice.getSerialNumber();
		System.out.println("Get By Id URL:" + url);
		request.header("Content-Type", testData.readExcel("Header", "Content-Type"));
		request.header("Authorization",testData.readExcel("Header", "Authorization"));
		request.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_GET"));
		Response response =request.get(url);
		DeviceRegistration[] device = response.getBody().as(DeviceRegistration[].class);


		System.out.println("Get By Id URL:" + url);
		putRequest.header("Content-Type", testData.readExcel("Header", "Content-Type"));
		putRequest.header("Authorization",testData.readExcel("Header", "Authorization"));
		putRequest.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_PUT"));
		device[0].setDevicePhoneNumber(testData.readExcel("Device", "DevicePhoneNumber_Update"));
		device[0].addKeyValue("Scripttest11","Value4");
		DeviceRegistration requestDevice = device[0];
		Gson gson = new Gson();
		String jsonInString = gson.toJson(requestDevice);
		putRequest.body(jsonInString);
		Response putResponse =putRequest.put(endPoint.getDevicesURL()+"/"+requestDevice.getSerialNumber());
		Assert.assertEquals(putResponse.getStatusCode(), 404);
	}

	//21. To verify PUT request throws error if serial number is not present in db
	@Test(priority=21)
	public void Device_Registration_Put_SNoNotFound() throws IOException
	{
		//RequestSpecification request = RestAssured.given();
		RequestSpecification putRequest = RestAssured.given();
		String serialNumber =RandomString.getAlphaNumericString(15);
		String url = endPoint.getDeviceURL() +"/"+serialNumber ;
		System.out.println("Get By Id URL:" + url);
		putRequest.header("Content-Type", testData.readExcel("Header", "Content-Type"));
		putRequest.header("Authorization",testData.readExcel("Header", "Authorization"));
		putRequest.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_PUT"));
		postDevice.setSerialNumber(serialNumber);
		Gson gson = new Gson();
		String jsonInString = gson.toJson(postDevice);
		putRequest.body(jsonInString);
		Response response =putRequest.put(url);
		Assert.assertEquals(response.getStatusCode(), 404);
	}
	// 22. To verify search a record with phone number
	@Test(priority=22)
	public void Device_Registration_Search_Phone() throws IOException
	{
		RequestSpecification request = RestAssured.given();
		String url = endPoint.getDeviceSearchURL()+"?devicePhoneNumber="+ testData.readExcel("Device", "DevicePhoneNumber_Update"); 

		request.header("Content-Type", testData.readExcel("Header", "Content-Type"));
		request.header("Authorization",testData.readExcel("Header", "Authorization"));
		request.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_GET"));

		Response response =request.get(url);
		ResponseBody body = response.getBody();

		Assert.assertEquals(response.getStatusCode(), 200);

		DeviceRegistration[] device = response.getBody().as(DeviceRegistration[].class);
		String sqlQuery = "Select count(*) from device where device_phone_number='"+testData.readExcel("Device", "DevicePhoneNumber_Update")+"' and delete_status='1'";
		String result = dbConnector.executeSQLQuery(sqlQuery);
		int expected = Integer.parseInt(result);
		Assert.assertEquals(device.length, expected);
		for(int i=0; i< device.length; i++)
		{
			Assert.assertEquals(device[i].getDevicePhoneNumber(), testData.readExcel("Device", "DevicePhoneNumber_Update"));
		}
	}     

	// 23. To verify search a record with device type
	@Test(priority=23)
	public void Device_Registration_Search_DeviceType() throws IOException
	{
		RequestSpecification request = RestAssured.given();

		String url = endPoint.getDeviceSearchURL()+"?deviceType="+ testData.readExcel("Device", "DeviceType"); 

		request.header("Content-Type", testData.readExcel("Header", "Content-Type"));
		request.header("Authorization",testData.readExcel("Header", "Authorization"));
		request.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_GET"));
		Response response =request.get(url);
		Assert.assertEquals(response.getStatusCode(), 200);

		DeviceRegistration[] device = response.getBody().as(DeviceRegistration[].class);
		String sqlQuery = "Select count(*) from device where device_type='"+ testData.readExcel("Device", "DeviceType")+"' and delete_status='1'";
		String result = dbConnector.executeSQLQuery(sqlQuery);
		Assert.assertEquals(device.length, Integer.parseInt(result));

		for(int i=0; i< device.length; i++)
		{
			Assert.assertEquals(device[i].getDeviceType(), testData.readExcel("Device", "DeviceType"));
		}
	}

	// 24. To verify search a record with sim type
	@Test(priority=24)
	public void Device_Registration_Search_SimType() throws IOException
	{
		RequestSpecification request = RestAssured.given();

		String url = endPoint.getDeviceSearchURL()+"?deviceSimType="+ testData.readExcel("Device", "SimType"); 

		request.header("Content-Type", testData.readExcel("Header", "Content-Type"));
		request.header("Authorization",testData.readExcel("Header", "Authorization"));
		request.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_GET"));
		Response response =request.get(url);
		Assert.assertEquals(response.getStatusCode(), 200);

		DeviceRegistration[] device = response.getBody().as(DeviceRegistration[].class);
		String sqlQuery = "Select count(*) from device where sim_type='"+ testData.readExcel("Device", "SimType")+"' and delete_status='1'";
		String result = dbConnector.executeSQLQuery(sqlQuery);
		Assert.assertEquals(device.length, Integer.parseInt(result));

		for(int i=0; i< device.length; i++)
		{
			Assert.assertEquals(device[i].getSimType(), testData.readExcel("Device", "SimType"));
		}
	}

	// 25. To verify search a record with manufacturer
	@Test(priority=25)
	public void Device_Registration_Search_Manufacturer() throws IOException
	{
		RequestSpecification request = RestAssured.given();

		String url = endPoint.getDeviceSearchURL()+"?manufactureName="+ testData.readExcel("Device", "Manufacturer"); 

		request.header("Content-Type", testData.readExcel("Header", "Content-Type"));
		request.header("Authorization",testData.readExcel("Header", "Authorization"));
		request.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_GET"));
		Response response =request.get(url);
		Assert.assertEquals(response.getStatusCode(), 200);

		DeviceRegistration[] device = response.getBody().as(DeviceRegistration[].class);
		String sqlQuery = "Select count(*) from device where manufacturer='"+ testData.readExcel("Device", "Manufacturer")+"' and delete_status='1'";
		String result = dbConnector.executeSQLQuery(sqlQuery);
		Assert.assertEquals(device.length, Integer.parseInt(result));

		for(int i=0; i< device.length; i++)
		{
			Assert.assertTrue(device[i].getManufacturer().equalsIgnoreCase(testData.readExcel("Device", "Manufacturer")));
		}
	}
	// 26. To verify search a record with serial number
	@Test(priority=26)
	public void Device_Registration_Search_serialNumber() throws IOException
	{
		RequestSpecification request = RestAssured.given();
		String url = endPoint.getDeviceSearchURL()+"?serialNumber="+ respPostDevice.getSerialNumber(); 

		request.header("Content-Type", testData.readExcel("Header", "Content-Type"));
		request.header("Authorization",testData.readExcel("Header", "Authorization"));
		request.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_GET"));
		Response response =request.get(url);
		ResponseBody body = response.getBody();
		Assert.assertEquals(response.getStatusCode(), 200);

		DeviceRegistration[] device = response.getBody().as(DeviceRegistration[].class);
		String sqlQuery = "Select count(*) from device where serial_number='"+ respPostDevice.getSerialNumber()+"' and delete_status='1'";
		String result = dbConnector.executeSQLQuery(sqlQuery);
		Assert.assertEquals(device.length, Integer.parseInt(result));

		for(int i=0; i< device.length; i++)
		{
			Assert.assertEquals(device[i].getSerialNumber(), respPostDevice.getSerialNumber());
		}
	}

	// 27. To verify search a record with device type and manufacturer
	@Test(priority=27)
	public void Device_Registration_Search_DeviceType_Manufacturer() throws IOException
	{
		RequestSpecification request = RestAssured.given();

		String url = endPoint.getDeviceSearchURL()+"?deviceType="+ testData.readExcel("Device", "DeviceType")+ "&manufactureName="+ testData.readExcel("Device", "Manufacturer"); 

		request.header("Content-Type", testData.readExcel("Header", "Content-Type"));
		request.header("Authorization",testData.readExcel("Header", "Authorization"));
		request.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_GET"));
		Response response =request.get(url);
		Assert.assertEquals(response.getStatusCode(), 200);

		DeviceRegistration[] device = response.getBody().as(DeviceRegistration[].class);
		String sqlQuery = "Select count(*) from device where device_type='"+ testData.readExcel("Device", "DeviceType")+ "' and manufacturer='" + testData.readExcel("Device", "Manufacturer")+"' and delete_status='1'";
		System.out.println("before query execution:"+ sqlQuery);
		String result = dbConnector.executeSQLQuery(sqlQuery);
		System.out.println("after query execution:"+ result);
		System.out.println("from api:"+ device.length);
		System.out.println("from db:"+ result);
		int expected = Integer.parseInt(result);
		Assert.assertEquals(device.length, expected);

		for(int i=0; i< device.length; i++)
		{
			//System.out.println("INSIDE FOR LOOP::" + i + device[i].getDeviceType() + device[i].getManufacturer());
			
			Assert.assertEquals(device[i].getDeviceType(), testData.readExcel("Device", "DeviceType"));
			Assert.assertTrue(device[i].getManufacturer().equalsIgnoreCase(testData.readExcel("Device", "Manufacturer")));
		}
	}

	// 28. To verify search a record with simType and serialNumber
	@Test(priority=28)
	public void Device_Registration_Search_simType_serialNumber() throws IOException
	{
		RequestSpecification request = RestAssured.given();

		String url = endPoint.getDeviceSearchURL()+"?deviceSimType="+ testData.readExcel("Device", "SimType_Update") + "&serialNumber="+ respPostDevice.getSerialNumber(); 

		request.header("Content-Type", testData.readExcel("Header", "Content-Type"));
		request.header("Authorization",testData.readExcel("Header", "Authorization"));
		request.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_GET"));
		Response response =request.get(url);
		Assert.assertEquals(response.getStatusCode(), 200);

		DeviceRegistration[] device = response.getBody().as(DeviceRegistration[].class);
		String sqlQuery = "Select count(*) from device where sim_type='"+ testData.readExcel("Device", "SimType_Update") + "'and serial_number='" + respPostDevice.getSerialNumber()+"' and delete_status='1'";
		System.out.println("before query execution:"+ sqlQuery);
		String result = dbConnector.executeSQLQuery(sqlQuery);
		System.out.println("after query execution:"+ result);
		System.out.println("from api:"+ device.length);
		System.out.println("from db:"+ result);
		int expected = Integer.parseInt(result);
		Assert.assertEquals(device.length, expected);

		for(int i=0; i< device.length; i++)
		{
			Assert.assertEquals(device[i].getSimType(), testData.readExcel("Device", "SimType_Update"));
			Assert.assertEquals(device[i].getSerialNumber(), respPostDevice.getSerialNumber());
		}
	}
	
	// 29. To verify delete a device throws error when unauthorised header is passed
	@Test(priority=29)
	public void Device_Registration_delete_unauthorised() throws IOException
	{
		RequestSpecification request = RestAssured.given();

		String url = endPoint.getDeviceURL()+"/"+ respPostDevice.getSerialNumber()+"/user"; 

		request.header("Content-Type", testData.readExcel("Header", "Content-Type"));
		request.header("Authorization",testData.readExcel("Header", "Authorization"));
		request.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_GET"));
		Response response =request.delete(url);
		Assert.assertEquals(response.getStatusCode(), 401);

	}
	
	// 30. To verify delete a device 
		@Test(priority=30)
		public void Device_Registration_delete() throws IOException
		{
			RequestSpecification request = RestAssured.given();

			String url = endPoint.getDeviceURL()+"/"+ respPostDevice.getSerialNumber()+"/user"; 

			request.header("Content-Type", testData.readExcel("Header", "Content-Type"));
			request.header("Authorization",testData.readExcel("Header", "Authorization"));
			request.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_DELETE"));
			Response response =request.delete(url);
			Assert.assertEquals(response.getStatusCode(), 200);
			
			String sqlQuery = "Select Count(*) from device where serial_number='"+respPostDevice.getSerialNumber()+"' and delete_status='1'";
			String result = dbConnector.executeSQLQuery(sqlQuery);
			int resultInt = Integer.parseInt(result);
			Assert.assertTrue(resultInt==0);

		}
		
		// 31. To verify delete a device throws error when SerialNumber is not present in db
				@Test(priority=31)
				public void Device_Registration_delete_SNoNotFound() throws IOException
				{
					RequestSpecification request = RestAssured.given();

					String url = endPoint.getDeviceURL()+"/"+ respPostDevice.getSerialNumber()+"/user"; 

					request.header("Content-Type", testData.readExcel("Header", "Content-Type"));
					request.header("Authorization",testData.readExcel("Header", "Authorization"));
					request.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_DELETE"));
					Response response =request.delete(url);
					Assert.assertEquals(response.getStatusCode(), 404);
				}
				
				// 32. To verify delete a device throws error when incorrect url is sent
				@Test(priority=32)
				public void Device_Registration_delete_incorrectURL() throws IOException
				{
					RequestSpecification request = RestAssured.given();

					String url = endPoint.getDeviceURL()+"es/"+ respPostDevice.getSerialNumber()+"/user"; 

					request.header("Content-Type", testData.readExcel("Header", "Content-Type"));
					request.header("Authorization",testData.readExcel("Header", "Authorization"));
					request.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_DELETE"));
					Response response =request.delete(url);
					Assert.assertEquals(response.getStatusCode(), 404);
				}
				
				// 33. To verify device details for multiple MAC Addresses 
				@Test(priority=33)
				public void Device_details_MACAddresses() throws IOException
				{
					RequestSpecification request = RestAssured.given();
					String url = endPoint.getDevicesByMACAddressesURL()+"/"+ respPostDevice.getDeviceMac()+","+ RandomString.randomMACAddress(); 

					request.header("Content-Type", testData.readExcel("Header", "Content-Type"));
					request.header("Authorization",testData.readExcel("Header", "Authorization"));
					request.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_GET"));
					Response response =request.get(url);
					Assert.assertEquals(response.getStatusCode(), 200);
					
					DeviceRegistration[] device = response.getBody().as(DeviceRegistration[].class);
					Assert.assertEquals(device[0].getDeviceMac(),respPostDevice.getDeviceMac());
				}
				
				// 34. To verify error is thrown for multiple MAC Addresses when unauthorized header is sent
				@Test(priority=34)
				public void Device_details_MACAddresses_UnauthorizedHeader() throws IOException
				{
					RequestSpecification request = RestAssured.given();
					String url = endPoint.getDevicesByMACAddressesURL()+"/"+ respPostDevice.getDeviceMac()+","+ RandomString.randomMACAddress(); 

					request.header("Content-Type", testData.readExcel("Header", "Content-Type"));
					request.header("Authorization",testData.readExcel("Header", "Authorization"));
					request.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_POST"));
					Response response =request.get(url);
					Assert.assertEquals(response.getStatusCode(), 401);
					
				}
				
				// 35. To verify device details for multiple serial numbers 
				@Test(priority=35)
				public void Device_details_SerialNumbers() throws IOException
				{
					RequestSpecification request = RestAssured.given();
					String url = endPoint.getDevicesBySerialNumbersURL()+"/"+ respPostDevice.getSerialNumber()+","+ RandomString.getAlphaNumericString(10); 

					request.header("Content-Type", testData.readExcel("Header", "Content-Type"));
					request.header("Authorization",testData.readExcel("Header", "Authorization"));
					request.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_GET"));
					Response response =request.get(url);
					Assert.assertEquals(response.getStatusCode(), 200);
					
					DeviceRegistration[] device = response.getBody().as(DeviceRegistration[].class);
					Assert.assertEquals(device[0].getSerialNumber(),respPostDevice.getSerialNumber());
					
					
				}
				
				// 36. To verify if error is thrown for multiple serial numbers with unauthorized header
				@Test(priority=36)
				public void Device_details_SerialNumbers_UnauthorizedHeader() throws IOException
				{
					RequestSpecification request = RestAssured.given();
					String url = endPoint.getDevicesBySerialNumbersURL()+"/"+ respPostDevice.getSerialNumber()+","+ RandomString.getAlphaNumericString(10); 

					request.header("Content-Type", testData.readExcel("Header", "Content-Type"));
					request.header("Authorization",testData.readExcel("Header", "Authorization"));
					request.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_POST"));
					Response response =request.get(url);
					Assert.assertEquals(response.getStatusCode(), 401);
					
				}
				
				*/
}