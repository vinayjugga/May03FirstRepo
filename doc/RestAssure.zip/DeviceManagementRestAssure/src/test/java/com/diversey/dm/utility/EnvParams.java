package  com.diversey.dm.utility;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Provide access to JVM parameters passed into the runtime using -D options.
 */
public final class EnvParams {
	
    private String environment;
    private String dbUrl;
    private String dbUsername;
    private String dbPassword;
    private String mqttAddress;
    private String mqttUser;
    private String mqttPassword;
    
    Properties prop = new Properties();
    InputStream input = null;
    public EnvParams()  
    {
    	try {
    	String currentlocation =System.getProperty("user.dir");
		System.out.println("Current Location is:" + currentlocation);
		input = new FileInputStream(currentlocation+"/src/test/resources/application.properties");
		
		prop.load(input);
    	environment = prop.getProperty("testUrl");
    	dbUrl = prop.getProperty("DbUrl");
    	dbUsername = prop.getProperty("DbUsername");
    	dbPassword = prop.getProperty("DbPassword");
    	mqttAddress = prop.getProperty("MqttAddress");
    	mqttUser = prop.getProperty("MqttUser");
    	mqttPassword = prop.getProperty("MqttPassword");
    	
    	}
    	catch(IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    public String getEnvironment() 
    { 
    	return environment; 
    }

	public String getDbUrl() {
		return dbUrl;
	}

	public String getDbUsername() {
		return dbUsername;
	}

	public String getDbPassword() {
		return dbPassword;
	}

	public String getMqttAddress() {
		return mqttAddress;
	}

	public String getMqttUser() {
		return mqttUser;
	}

	public String getMqttPassword() {
		return mqttPassword;
	}

}
