package com.diversey.dm.api.testcases;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpStatus;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.diversey.dm.model.ConfigUpdateStatus;
import com.diversey.dm.model.DeviceRegistration;
import com.diversey.dm.model.Machine;
import com.diversey.dm.model.Site;
import com.diversey.dm.model.SiteCell;
import com.diversey.dm.utility.CreateURLByEndpoint;
import com.diversey.dm.utility.DataBaseConnector;
import com.diversey.dm.utility.MQTTPublish;
import com.diversey.dm.utility.MQTTUtility;
import com.diversey.dm.utility.RandomString;
import com.diversey.dm.utility.TestDataExcelUtility;
import com.google.common.base.Verify;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonParser;

import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class MachineAssignmentTest {

	TestDataExcelUtility testData =new TestDataExcelUtility();
	CreateURLByEndpoint endPoint = new CreateURLByEndpoint();
	DataBaseConnector dbConnector = new DataBaseConnector();
	DeviceRegistration postDevice;
	DeviceRegistration respPostDevice;	
	String serialNumber ;
	String processingId;
	int preConfigVersion;
	int postConfigVersion;
	List<String> cellIds;

	//1. To register a new device to test machine assignment
	@Test(priority=1)
	public void deviceReg_POST() throws IOException
	{

		RequestSpecification request = RestAssured.given();
		String url = endPoint.getDeviceURL();	
		System.out.println("POST URL:" + url);
		List<Header> headerList = new ArrayList<>();
		Header header1 = new Header("Content-Type", testData.readExcel("Header", "Content-Type"));
		Header header2 = new Header("Authorization", testData.readExcel("Header", "Authorization"));
		Header header3 = new Header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_POST"));

		headerList.add(header1);
		headerList.add(header2);
		headerList.add(header3);
		Headers headers = new Headers(headerList);
		request.headers(headers);

		postDevice= new DeviceRegistration();
		postDevice.setDeviceMac(RandomString.randomMACAddress());
		postDevice.setDevicePhoneNumber(RandomString.getAlphaNumericString(15));
		postDevice.setDeviceType(testData.readExcel("Device", "DeviceType"));
		postDevice.setFirmwareVersion(testData.readExcel("Device", "FirmwareVersion"));
		postDevice.setManufactureDate(testData.readExcel("Device", "ManufactureDate"));
		postDevice.setManufacturer(testData.readExcel("Device", "Manufacturer"));
		postDevice.setSerialNumber(RandomString.getAlphaNumericString(15));
		postDevice.setServiceLine(testData.readExcel("Device", "ServiceLine"));
		postDevice.setUser(testData.readExcel("Device", "UserId"));
		postDevice.setReaderFirmwareVersion(testData.readExcel("Device", "RdrFirmwareVersion"));
		postDevice.setSimNumber(RandomString.getAlphaNumericString(15));
		postDevice.setSimType(testData.readExcel("Device", "SimType"));
		postDevice.addKeyValue("Scripttest11","Value4");
		Gson gson = new Gson();
		String jsonInString = gson.toJson(postDevice);
		request.body(jsonInString);

		Response Resp =request.post(url);
		ResponseBody body = Resp.getBody();
		respPostDevice = new DeviceRegistration();
		respPostDevice  = body.as(DeviceRegistration.class);
	}


	// 2. To POST a NEW MACHINE ASSIGNMENT REQUEST WITHOUT CHANGE IN GEOFENCE
	@Test(priority=2)
	public void machineAssignment_New() throws IOException
	{

		RequestSpecification request = RestAssured.given();
		String url = endPoint.getMachineAssignmentURL();	
		System.out.println("MachineAssignment URL:" + url);
		List<Header> headerList = new ArrayList<>();
		Header header1 = new Header("Content-Type", testData.readExcel("Header", "Content-Type"));
		Header header2 = new Header("Authorization", testData.readExcel("Header", "Authorization"));
		Header header3 = new Header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_POST"));

		headerList.add(header1);
		headerList.add(header2);
		headerList.add(header3);
		Headers headers = new Headers(headerList);
		request.headers(headers); 
		String serialNumber = respPostDevice.getSerialNumber();

		//get the config_version from device table before machine assignment API
		String configVersionQuery = "Select config_version from device where serial_number='"+serialNumber+"'";
		String configVerion = dbConnector.executeSQLQuery(configVersionQuery);
		System.out.println("After db::" + configVerion);
		int preConfigVersion = Integer.parseInt(configVerion);

		//set the machineAssignment object for API request payload
		Machine machine = new Machine();
		machine.setDeviceNumber(serialNumber);
		machine.setMachineMake(testData.readExcel("MachineAssignment", "New_MachineMake"));
		machine.setMachineModel(testData.readExcel("MachineAssignment", "New_MachineModel"));
		machine.setMachineBatteryType(testData.readExcel("MachineAssignment", "New_BatteryType"));
		System.out.println("after setting machine object");
		Site site = new Site();
		site.setId(Integer.parseInt(testData.readExcel("MachineAssignment", "New_SiteId")));
		//System.out.println("after setting siteId");
		site.setNodeId(testData.readExcel("MachineAssignment", "New_NodeId"));
		//System.out.println("after setting nodeid");
		site.setLatitude(Double.parseDouble(testData.readExcel("MachineAssignment", "New_Lattitude")));
		//System.out.println("after setting Lattitude");
		site.setLongitude(Double.parseDouble(testData.readExcel("MachineAssignment", "New_Longitude")));
		//System.out.println("after setting Longitude");
		site.setRadius(Double.parseDouble(testData.readExcel("MachineAssignment", "New_Radius")));
		//System.out.println("after setting site object");
		machine.setSite(site);
		System.out.println("After setting site in machine");
		Gson gson = new Gson();
		List<Machine> machines = new ArrayList<Machine>();
		machines.add(machine);
		String jsonInString = gson.toJson(machines);
		request.body(jsonInString);
		System.out.println("After setting body in request");
		Response response =request.post(url);
		ResponseBody body = response.getBody();
		System.out.println("response status code is :" + response.getStatusCode());
		System.out.println("response body :" + response.getBody());
		Assert.assertEquals(response.getStatusCode(), HttpStatus.SC_CREATED);

		JsonObject jsonObject = new JsonParser().parse(body.asString()).getAsJsonObject();
		System.out.println(jsonObject);
		//get processing id from response
		String processingId =jsonObject.get("ProcessingId").getAsString();
		System.out.println("ProcessingId is ::" + processingId);

		//Verify in database if the status is success.
		String query="Select status from config_update_status where processing_id='"+processingId+"'";
		String status = dbConnector.executeSQLQuery(query);
		Verify.verify(status.equalsIgnoreCase("success"));

		//Verify in device table if config version is incremented.
		configVerion = dbConnector.executeSQLQuery(configVersionQuery);
		int postConfigVersion = Integer.parseInt(configVerion);
		Verify.verify(postConfigVersion == preConfigVersion+1);

		//Verify in database if machine parameters are updated in json configuration of device
		String deviceQuery = "Select json_config_payload from device where serial_number='"+serialNumber+"'";
		String result = dbConnector.executeSQLQuery(deviceQuery);
		System.out.println(result);
		jsonObject = new JsonParser().parse(result).getAsJsonObject();

		JsonArray array = jsonObject.get("mtr rtos +crash").getAsJsonArray();
		System.out.println("json value of paramgroup- mtr rtos+ crash::"+array);
		JsonObject paramValue = array.get(0).getAsJsonObject();
		System.out.println("json value of paramgroup::"+paramValue);
		String paramValueQuery = "SELECT name as param_name, value as param_value FROM machine_params_udf "
				+ "where machine_make='" + machine.getMachineMake()+ "' and machine_model='" + machine.getMachineModel()+"'";
		System.out.println(paramValueQuery);
		Map<String,String>  paramValueresult = dbConnector.executeSQLQuery_List_Map(paramValueQuery);
		System.out.println("after getting param values from db");
		Iterator<Map.Entry<String, String>> itr = paramValueresult.entrySet().iterator();
		while(itr.hasNext())
		{
			Map.Entry<String, String> paramNameValue =itr.next();
			System.out.println("from machine params udf table::"+paramNameValue.getKey()+":::"+paramNameValue.getValue());
			System.out.println("from device config value::"+ paramValue.get(paramNameValue.getKey()));
			System.out.println("from db map::" + "\""+ paramNameValue.getValue() +"\"");
			Verify.verify((paramValue.get(paramNameValue.getKey()).toString()).equals("\""+ paramNameValue.getValue() +"\""));

		}

		//Verify if battery related params are updated in json configuration of device
		String batteryQuery = "Select backup_power_low_level from machine_battery where machine_make='" 
				+ machine.getMachineMake()+"' and machine_model='" + machine.getMachineModel()+ "' and battery_type='"
				+ machine.getMachineBatteryType()+ "'";
		System.out.println(batteryQuery);
		String backupPowerLowLevel = dbConnector.executeSQLQuery(batteryQuery);
		Verify.verify(jsonObject.get("backup power low level").getAsInt() == Integer.parseInt(backupPowerLowLevel));


		batteryQuery = "Select backup_power_ready_level from machine_battery where machine_make='" 
				+ machine.getMachineMake()+"' and machine_model='" + machine.getMachineModel()+ "' and battery_type='"
				+ machine.getMachineBatteryType()+ "'";
		System.out.println(batteryQuery);
		String backupPowerReadyLevel = dbConnector.executeSQLQuery(batteryQuery);
		Verify.verify(jsonObject.get("backup power ready level").getAsInt() == Integer.parseInt(backupPowerReadyLevel));


		//Verify if record is inserted in machine_assignment table
		String machineAssignmentQuery = "Select count(*) from machine_assignment where delete_status='1' and machine_make='"
				+ machine.getMachineMake()+"' and machine_model='" + machine.getMachineModel()+ "' and machine_battery_type='"
				+ machine.getMachineBatteryType()+ "' and site_id='"+machine.getSite().getNodeId()+"' and device_serial_number='"
				+ machine.getDeviceNumber() + "'";
		System.out.println(machineAssignmentQuery);
		String resultCount = dbConnector.executeSQLQuery(machineAssignmentQuery);
		Verify.verify(Integer.parseInt(resultCount) == 1);

		//Verify if site table has the data of site as per request.
		String siteQuery = "Select Count(*) from site where id='"+ machine.getSite().getId()+"' and node_id='"
				+ machine.getSite().getNodeId()+ "' and latitude='" + machine.getSite().getLatitude() + "' and longitude='"
				+ machine.getSite().getLongitude() + "' and radius='" + machine.getSite().getRadius()+ "' and delete_status ='1' ";
		System.out.println(siteQuery);
		String countSite = dbConnector.executeSQLQuery(siteQuery);
		Verify.verify(Integer.parseInt(countSite) == 1);

		//Verify if Geofence center is updated in device configuration.
		String geofenceCenter = jsonObject.get("geofence center").getAsString();
		if(geofenceCenter.contains(Double.toString(machine.getSite().getLatitude())))
			if(geofenceCenter.contains(Double.toString(machine.getSite().getLongitude())))
				Verify.verify(true);

		// verify if geofence radius is updated in json configuration of device
		JsonArray radiusArray= jsonObject.get("geofence radius").getAsJsonArray();
		String radius = radiusArray.get(0).getAsString();
		Verify.verify(Double.parseDouble(radius) == machine.getSite().getRadius());

		//Verify if the previous configuration is taken as backup
		String configBackupQuery = "Select count(*) from device_config_hist where serial_number='"+serialNumber+"' and version ='"+preConfigVersion+"'";
		String configBackupResult = dbConnector.executeSQLQuery(configBackupQuery);
		Verify.verify(Integer.parseInt(configBackupResult)==1);

		//Connect to MQTT Broker and subscribe to the topic if configuration is published.
		MQTTUtility mqttUtility = new MQTTUtility();
		mqttUtility.MQTTSubscriber(serialNumber,Integer.toString(postConfigVersion), true);
		mqttUtility.MQTTSubscriber(serialNumber,Integer.toString(postConfigVersion), false);

	}

	// 3. To POST a machine assignment with CHANGE IN GEOFENCE - single
	@Test(priority=3)
	public void geoChange_Single() throws IOException
	{

		RequestSpecification request = RestAssured.given();
		String url = endPoint.getMachineAssignmentURL();	
		System.out.println("MachineAssignment URL:" + url);
		List<Header> headerList = new ArrayList<>();
		Header header1 = new Header("Content-Type", testData.readExcel("Header", "Content-Type"));
		Header header2 = new Header("Authorization", testData.readExcel("Header", "Authorization"));
		Header header3 = new Header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_POST"));

		headerList.add(header1);
		headerList.add(header2);
		headerList.add(header3);
		Headers headers = new Headers(headerList);
		request.headers(headers); 
		String serialNumber = respPostDevice.getSerialNumber();

		//get the config_version from device table before machine assignment API
		String configVersionQuery = "Select config_version from device where serial_number='"+serialNumber+"'";
		String configVerion = dbConnector.executeSQLQuery(configVersionQuery);
		System.out.println("After db::" + configVerion);
		int preConfigVersion = Integer.parseInt(configVerion);

		//set the machineAssignment object for API request payload
		Machine machine = new Machine();
		machine.setDeviceNumber(serialNumber);
		Site site = new Site();
		site.setId(Integer.parseInt(testData.readExcel("MachineAssignment", "New_SiteId")));
		//System.out.println("after setting siteId");
		site.setNodeId(testData.readExcel("MachineAssignment", "New_NodeId"));
		//System.out.println("after setting nodeid");
		site.setLatitude(Double.parseDouble(testData.readExcel("MachineAssignment", "GeoUpdate_Lattitude")));
		//System.out.println("after setting Lattitude");
		site.setLongitude(Double.parseDouble(testData.readExcel("MachineAssignment", "GeoUpdate_Longitude")));
		//System.out.println("after setting Longitude");
		site.setRadius(Double.parseDouble(testData.readExcel("MachineAssignment", "GeoUpdate_Radius")));
		//System.out.println("after setting site object");
		machine.setSite(site);
		System.out.println("After setting site in machine");
		Gson gson = new Gson();
		List<Machine> machines = new ArrayList<Machine>();
		machines.add(machine);
		String jsonInString = gson.toJson(machines);
		request.body(jsonInString);
		System.out.println("After setting body in request");
		Response response =request.post(url);
		ResponseBody body = response.getBody();
		System.out.println("response status code is :" + response.getStatusCode());
		System.out.println("response body :" + response.getBody());
		Assert.assertEquals(response.getStatusCode(), HttpStatus.SC_CREATED);

		JsonObject jsonObject = new JsonParser().parse(body.asString()).getAsJsonObject();
		System.out.println(jsonObject);
		//get processing id from response
		String processingId =jsonObject.get("ProcessingId").getAsString();
		System.out.println("ProcessingId is ::" + processingId);

		//Verify in database if the status is success.
		String query="Select status from config_update_status where processing_id='"+processingId+"'";
		String status = dbConnector.executeSQLQuery(query);
		Verify.verify(status.equalsIgnoreCase("success"));

		//Verify in device table if config version is incremented.
		configVerion = dbConnector.executeSQLQuery(configVersionQuery);
		int postConfigVersion = Integer.parseInt(configVerion);
		Verify.verify(postConfigVersion == preConfigVersion+1);

		//Verify if record is inserted in machine_assignment table
		String machineAssignmentQuery = "Select count(*) from machine_assignment where delete_status='1' and device_serial_number='"
				+ machine.getDeviceNumber() + "'";
		System.out.println(machineAssignmentQuery);
		String resultCount = dbConnector.executeSQLQuery(machineAssignmentQuery);
		Verify.verify(Integer.parseInt(resultCount) == 1);

		//Verify if site table has the data of site as per request.
		String siteQuery = "Select Count(*) from site where id='"+ machine.getSite().getId()+"' and node_id='"
				+ machine.getSite().getNodeId()+ "' and latitude='" + machine.getSite().getLatitude() + "' and longitude='"
				+ machine.getSite().getLongitude() + "' and radius='" + machine.getSite().getRadius()+ "' and delete_status ='1' ";
		System.out.println(siteQuery);
		String countSite = dbConnector.executeSQLQuery(siteQuery);
		Verify.verify(Integer.parseInt(countSite) == 1);

		//Verify if Geofence center is updated in device configuration.
		String deviceQuery = "Select json_config_payload from device where serial_number='"+serialNumber+"'";
		String result = dbConnector.executeSQLQuery(deviceQuery);
		System.out.println(result);
		jsonObject = new JsonParser().parse(result).getAsJsonObject();

		String geofenceCenter = jsonObject.get("geofence center").getAsString();
		if(geofenceCenter.contains(Double.toString(machine.getSite().getLatitude())))
			if(geofenceCenter.contains(Double.toString(machine.getSite().getLongitude())))
				Verify.verify(true);

		// verify if geofence radius is updated in json configuration of device
		JsonArray radiusArray= jsonObject.get("geofence radius").getAsJsonArray();
		String radius = radiusArray.get(0).getAsString();
		Verify.verify(Double.parseDouble(radius) == machine.getSite().getRadius());

		//Verify if the previous configuration is taken as backup
		String configBackupQuery = "Select count(*) from device_config_hist where serial_number='"+serialNumber+"' and version ='"+preConfigVersion+"'";
		String configBackupResult = dbConnector.executeSQLQuery(configBackupQuery);
		Verify.verify(Integer.parseInt(configBackupResult)==1);

		//Connect to MQTT Broker and subscribe to the topic if configuration is published.
		MQTTUtility mqttUtility = new MQTTUtility();
		mqttUtility.MQTTSubscriber(serialNumber,Integer.toString(postConfigVersion), true);
		mqttUtility.MQTTSubscriber(serialNumber,Integer.toString(postConfigVersion), false);

	}


	// 4. To POST a machine assignment with CHANGE IN SITE
	@Test(priority=4)
	public void siteChange() throws IOException
	{

		RequestSpecification request = RestAssured.given();
		String url = endPoint.getMachineAssignmentURL();	
		System.out.println("MachineAssignment URL:" + url);
		List<Header> headerList = new ArrayList<>();
		Header header1 = new Header("Content-Type", testData.readExcel("Header", "Content-Type"));
		Header header2 = new Header("Authorization", testData.readExcel("Header", "Authorization"));
		Header header3 = new Header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_POST"));

		headerList.add(header1);
		headerList.add(header2);
		headerList.add(header3);
		Headers headers = new Headers(headerList);
		request.headers(headers); 
		String serialNumber = respPostDevice.getSerialNumber();

		//get the config_version from device table before machine assignment API
		String configVersionQuery = "Select config_version from device where serial_number='"+serialNumber+"'";
		String configVerion = dbConnector.executeSQLQuery(configVersionQuery);
		System.out.println("After db::" + configVerion);
		int preConfigVersion = Integer.parseInt(configVerion);

		//set the machineAssignment object for API request payload
		Machine machine = new Machine();
		machine.setDeviceNumber(serialNumber);
		Site site = new Site();
		site.setId(Integer.parseInt(testData.readExcel("MachineAssignment", "SiteChange_SiteId")));
		//System.out.println("after setting siteId");
		site.setNodeId(testData.readExcel("MachineAssignment", "SiteChange_NodeId"));
		//System.out.println("after setting nodeid");
		site.setLatitude(Double.parseDouble(testData.readExcel("MachineAssignment", "SiteChange_Lattitude")));
		//System.out.println("after setting Lattitude");
		site.setLongitude(Double.parseDouble(testData.readExcel("MachineAssignment", "SiteChange_Longitude")));
		//System.out.println("after setting Longitude");
		site.setRadius(Double.parseDouble(testData.readExcel("MachineAssignment", "SiteChange_Radius")));
		//System.out.println("after setting site object");
		machine.setSite(site);
		System.out.println("After setting site in machine");
		Gson gson = new Gson();
		List<Machine> machines = new ArrayList<Machine>();
		machines.add(machine);
		String jsonInString = gson.toJson(machines);
		request.body(jsonInString);
		System.out.println("After setting body in request");
		Response response =request.post(url);
		ResponseBody body = response.getBody();
		System.out.println("response status code is :" + response.getStatusCode());
		System.out.println("response body :" + response.getBody());
		Assert.assertEquals(response.getStatusCode(), HttpStatus.SC_CREATED);

		JsonObject jsonObject = new JsonParser().parse(body.asString()).getAsJsonObject();
		System.out.println(jsonObject);
		//get processing id from response
		String processingId =jsonObject.get("ProcessingId").getAsString();
		System.out.println("ProcessingId is ::" + processingId);

		//Verify in database if the status is success.
		String query="Select status from config_update_status where processing_id='"+processingId+"'";
		String status = dbConnector.executeSQLQuery(query);
		Verify.verify(status.equalsIgnoreCase("success"));

		//Verify in device table if config version is incremented.
		configVerion = dbConnector.executeSQLQuery(configVersionQuery);
		int postConfigVersion = Integer.parseInt(configVerion);
		Verify.verify(postConfigVersion == preConfigVersion+1);

		//Verify if record is inserted in machine_assignment table
		String machineAssignmentQuery = "Select count(*) from machine_assignment where delete_status='1' and device_serial_number='"
				+ machine.getDeviceNumber() + "' and site_id='" + machine.getSite().getNodeId()+ "'";
		System.out.println(machineAssignmentQuery);
		String resultCount = dbConnector.executeSQLQuery(machineAssignmentQuery);
		Verify.verify(Integer.parseInt(resultCount) == 1);

		//Verify if site table has the data of site as per request.
		String siteQuery = "Select Count(*) from site where id='"+ machine.getSite().getId()+"' and node_id='"
				+ machine.getSite().getNodeId()+ "' and latitude='" + machine.getSite().getLatitude() + "' and longitude='"
				+ machine.getSite().getLongitude() + "' and radius='" + machine.getSite().getRadius()+ "' and delete_status ='1' ";
		System.out.println(siteQuery);
		String countSite = dbConnector.executeSQLQuery(siteQuery);
		Verify.verify(Integer.parseInt(countSite) == 1);

		//Verify if Geofence center is updated in device configuration.
		String deviceQuery = "Select json_config_payload from device where serial_number='"+serialNumber+"'";
		String result = dbConnector.executeSQLQuery(deviceQuery);
		System.out.println(result);
		jsonObject = new JsonParser().parse(result).getAsJsonObject();

		String geofenceCenter = jsonObject.get("geofence center").getAsString();
		if(geofenceCenter.contains(Double.toString(machine.getSite().getLatitude())))
			if(geofenceCenter.contains(Double.toString(machine.getSite().getLongitude())))
				Verify.verify(true);

		// verify if geofence radius is updated in json configuration of device
		JsonArray radiusArray= jsonObject.get("geofence radius").getAsJsonArray();
		String radius = radiusArray.get(0).getAsString();
		Verify.verify(Double.parseDouble(radius) == machine.getSite().getRadius());

		//Verify if the previous configuration is taken as backup
		String configBackupQuery = "Select count(*) from device_config_hist where serial_number='"+serialNumber+"' and version ='"+preConfigVersion+"'";
		String configBackupResult = dbConnector.executeSQLQuery(configBackupQuery);
		Verify.verify(Integer.parseInt(configBackupResult)==1);

		//Connect to MQTT Broker and subscribe to the topic if configuration is published.
		MQTTUtility mqttUtility = new MQTTUtility();
		mqttUtility.MQTTSubscriber(serialNumber,Integer.toString(postConfigVersion), true);
		mqttUtility.MQTTSubscriber(serialNumber,Integer.toString(postConfigVersion), false);

	}

	// 5. To POST a machine assignment with CHANGE IN battery type
	@Test(priority=5)
	public void batteryTypeChange() throws IOException
	{

		RequestSpecification request = RestAssured.given();
		String url = endPoint.getMachineAssignmentURL();	
		System.out.println("MachineAssignment URL:" + url);
		List<Header> headerList = new ArrayList<>();
		Header header1 = new Header("Content-Type", testData.readExcel("Header", "Content-Type"));
		Header header2 = new Header("Authorization", testData.readExcel("Header", "Authorization"));
		Header header3 = new Header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_POST"));

		headerList.add(header1);
		headerList.add(header2);
		headerList.add(header3);
		Headers headers = new Headers(headerList);
		request.headers(headers); 
		String serialNumber = respPostDevice.getSerialNumber();

		//get the config_version from device table before machine assignment API
		String configVersionQuery = "Select config_version from device where serial_number='"+serialNumber+"'";
		String configVerion = dbConnector.executeSQLQuery(configVersionQuery);
		System.out.println("After db::" + configVerion);
		int preConfigVersion = Integer.parseInt(configVerion);

		//set the machineAssignment object for API request payload
		Machine machine = new Machine();
		machine.setDeviceNumber(serialNumber);
		machine.setMachineBatteryType(testData.readExcel("MachineAssignment", "BTChange_BatteryType"));
		Gson gson = new Gson();
		List<Machine> machines = new ArrayList<Machine>();
		machines.add(machine);
		String jsonInString = gson.toJson(machines);
		request.body(jsonInString);
		System.out.println("After setting body in request");
		Response response =request.post(url);
		ResponseBody body = response.getBody();
		System.out.println("response status code is :" + response.getStatusCode());
		System.out.println("response body :" + response.getBody());
		Assert.assertEquals(response.getStatusCode(), HttpStatus.SC_CREATED);

		JsonObject jsonObject = new JsonParser().parse(body.asString()).getAsJsonObject();
		System.out.println(jsonObject);
		//get processing id from response
		String processingId =jsonObject.get("ProcessingId").getAsString();
		System.out.println("ProcessingId is ::" + processingId);

		//Verify in database if the status is success.
		String query="Select status from config_update_status where processing_id='"+processingId+"'";
		String status = dbConnector.executeSQLQuery(query);
		Verify.verify(status.equalsIgnoreCase("success"));

		//Verify in device table if config version is incremented.
		configVerion = dbConnector.executeSQLQuery(configVersionQuery);
		int postConfigVersion = Integer.parseInt(configVerion);
		Verify.verify(postConfigVersion == preConfigVersion+1);

		//Verify if record is inserted in machine_assignment table
		String machineAssignmentQuery = "Select count(*) from machine_assignment where delete_status='1' and device_serial_number='"
				+ machine.getDeviceNumber() + "' and machine_battery_type='" + machine.getMachineBatteryType()+ "'";
		System.out.println(machineAssignmentQuery);
		String resultCount = dbConnector.executeSQLQuery(machineAssignmentQuery);
		Verify.verify(Integer.parseInt(resultCount) == 1);

		//Get the json configuration from device table.
		String deviceQuery = "Select json_config_payload from device where serial_number='"+serialNumber+"'";
		String result = dbConnector.executeSQLQuery(deviceQuery);
		System.out.println(result);
		jsonObject = new JsonParser().parse(result).getAsJsonObject();


		//Verify if battery related params are updated in json configuration of device
		String batteryQuery = "Select backup_power_low_level from machine_battery where machine_make='" 
				+ testData.readExcel("MachineAssignment", "New_MachineMake") +"' and machine_model='" 
				+ testData.readExcel("MachineAssignment", "New_MachineModel")+ "' and battery_type='"
				+ machine.getMachineBatteryType()+ "'";
		System.out.println(batteryQuery);
		String backupPowerLowLevel = dbConnector.executeSQLQuery(batteryQuery);
		Verify.verify(jsonObject.get("backup power low level").getAsInt() == Integer.parseInt(backupPowerLowLevel));


		batteryQuery = "Select backup_power_ready_level from machine_battery where machine_make='" 
				+ testData.readExcel("MachineAssignment", "New_MachineMake") +"' and machine_model='" 
				+ testData.readExcel("MachineAssignment", "New_MachineModel")+ "' and battery_type='"
				+ machine.getMachineBatteryType()+ "'";
		System.out.println(batteryQuery);
		String backupPowerReadyLevel = dbConnector.executeSQLQuery(batteryQuery);
		Verify.verify(jsonObject.get("backup power ready level").getAsInt() == Integer.parseInt(backupPowerReadyLevel));


		//Verify if the previous configuration is taken as backup
		String configBackupQuery = "Select count(*) from device_config_hist where serial_number='"+serialNumber+"' and version ='"+preConfigVersion+"'";
		String configBackupResult = dbConnector.executeSQLQuery(configBackupQuery);
		Verify.verify(Integer.parseInt(configBackupResult)==1);

		//Connect to MQTT Broker and subscribe to the topic if configuration is published.
		MQTTUtility mqttUtility = new MQTTUtility();
		mqttUtility.MQTTSubscriber(serialNumber,Integer.toString(postConfigVersion), true);
		mqttUtility.MQTTSubscriber(serialNumber,Integer.toString(postConfigVersion), false);

	}


	// 6. To POST a machine reassignment with same make  
	@Test(priority=6)
	public void machineReassign_SameMake() throws IOException
	{

		RequestSpecification request = RestAssured.given();
		String url = endPoint.getMachineAssignmentURL();	
		System.out.println("MachineAssignment URL:" + url);
		List<Header> headerList = new ArrayList<>();
		Header header1 = new Header("Content-Type", testData.readExcel("Header", "Content-Type"));
		Header header2 = new Header("Authorization", testData.readExcel("Header", "Authorization"));
		Header header3 = new Header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_POST"));

		headerList.add(header1);
		headerList.add(header2);
		headerList.add(header3);
		Headers headers = new Headers(headerList);
		request.headers(headers); 
		String serialNumber = respPostDevice.getSerialNumber();

		//get the config_version from device table before machine assignment API
		String configVersionQuery = "Select config_version from device where serial_number='"+serialNumber+"'";
		String configVerion = dbConnector.executeSQLQuery(configVersionQuery);
		System.out.println("After db::" + configVerion);
		int preConfigVersion = Integer.parseInt(configVerion);

		//set the machineAssignment object for API request payload
		Machine machine = new Machine();
		machine.setDeviceNumber(serialNumber);
		machine.setMachineModel(testData.readExcel("MachineAssignment", "ModelChange_Model"));
		Gson gson = new Gson();
		List<Machine> machines = new ArrayList<Machine>();
		machines.add(machine);
		String jsonInString = gson.toJson(machines);
		request.body(jsonInString);
		System.out.println("After setting body in request");
		Response response =request.post(url);
		ResponseBody body = response.getBody();
		System.out.println("response status code is :" + response.getStatusCode());
		System.out.println("response body :" + response.getBody());
		Assert.assertEquals(response.getStatusCode(), HttpStatus.SC_CREATED);

		JsonObject jsonObject = new JsonParser().parse(body.asString()).getAsJsonObject();
		System.out.println(jsonObject);
		//get processing id from response
		String processingId =jsonObject.get("ProcessingId").getAsString();
		System.out.println("ProcessingId is ::" + processingId);

		//Verify in database if the status is success.
		String query="Select status from config_update_status where processing_id='"+processingId+"'";
		String status = dbConnector.executeSQLQuery(query);
		Verify.verify(status.equalsIgnoreCase("success"));

		//Verify in device table if config version is incremented.
		configVerion = dbConnector.executeSQLQuery(configVersionQuery);
		int postConfigVersion = Integer.parseInt(configVerion);
		Verify.verify(postConfigVersion == preConfigVersion+1);

		//Verify if record is inserted in machine_assignment table
		String machineAssignmentQuery = "Select count(*) from machine_assignment where delete_status='1' and device_serial_number='"
				+ machine.getDeviceNumber() + "' and machine_model='" + machine.getMachineModel()+ "'";
		System.out.println(machineAssignmentQuery);
		String resultCount = dbConnector.executeSQLQuery(machineAssignmentQuery);
		Verify.verify(Integer.parseInt(resultCount) == 1);

		//Get the json configuration from device table.
		String deviceQuery = "Select json_config_payload from device where serial_number='"+serialNumber+"'";
		String result = dbConnector.executeSQLQuery(deviceQuery);
		System.out.println(result);
		jsonObject = new JsonParser().parse(result).getAsJsonObject();

		//Verify if machine related parameters are updated in device configuration

		JsonArray array = jsonObject.get("mtr rtos +crash").getAsJsonArray();
		System.out.println("json value of paramgroup- mtr rtos+ crash::"+array);
		JsonObject paramValue = array.get(0).getAsJsonObject();
		System.out.println("json value of paramgroup::"+paramValue);
		String paramValueQuery = "SELECT name as param_name, value as param_value FROM machine_params_udf "
				+ "where machine_make='" + testData.readExcel("MachineAssignment", "New_MachineMake")
				+ "' and machine_model='" + machine.getMachineModel()+"'";
		System.out.println(paramValueQuery);
		Map<String,String>  paramValueresult = dbConnector.executeSQLQuery_List_Map(paramValueQuery);
		System.out.println("after getting param values from db");
		Iterator<Map.Entry<String, String>> itr = paramValueresult.entrySet().iterator();
		while(itr.hasNext())
		{
			Map.Entry<String, String> paramNameValue =itr.next();
			System.out.println("from machine params udf table::"+paramNameValue.getKey()+":::"+paramNameValue.getValue());
			System.out.println("from device config value::"+ paramValue.get(paramNameValue.getKey()));
			System.out.println("from db map::" + "\""+ paramNameValue.getValue() +"\"");
			Verify.verify((paramValue.get(paramNameValue.getKey()).toString()).equals("\""+ paramNameValue.getValue() +"\""));

		}

		//Verify if battery related params are updated in json configuration of device
		String batteryQuery = "Select backup_power_low_level from machine_battery where machine_make='" 
				+ testData.readExcel("MachineAssignment", "New_MachineMake") +"' and machine_model='" 
				+ machine.getMachineModel()+ "' and battery_type='"
				+ testData.readExcel("MachineAssignment", "BTChange_BatteryType")+ "'";
		System.out.println(batteryQuery);
		String backupPowerLowLevel = dbConnector.executeSQLQuery(batteryQuery);
		Verify.verify(jsonObject.get("backup power low level").getAsInt() == Integer.parseInt(backupPowerLowLevel));


		batteryQuery = "Select backup_power_ready_level from machine_battery where machine_make='" 
				+ testData.readExcel("MachineAssignment", "New_MachineMake") +"' and machine_model='" 
				+ machine.getMachineModel()+ "' and battery_type='"
				+ testData.readExcel("MachineAssignment", "BTChange_BatteryType")+ "'";
		System.out.println(batteryQuery);
		String backupPowerReadyLevel = dbConnector.executeSQLQuery(batteryQuery);
		Verify.verify(jsonObject.get("backup power ready level").getAsInt() == Integer.parseInt(backupPowerReadyLevel));


		//Verify if the previous configuration is taken as backup
		String configBackupQuery = "Select count(*) from device_config_hist where serial_number='"+serialNumber+"' and version ='"+preConfigVersion+"'";
		String configBackupResult = dbConnector.executeSQLQuery(configBackupQuery);
		Verify.verify(Integer.parseInt(configBackupResult)==1);

		//Connect to MQTT Broker and subscribe to the topic if configuration is published.
		MQTTUtility mqttUtility = new MQTTUtility();
		mqttUtility.MQTTSubscriber(serialNumber,Integer.toString(postConfigVersion), true);
		mqttUtility.MQTTSubscriber(serialNumber,Integer.toString(postConfigVersion), false);

	}


	// 7. To POST a machine reassignment with different make  
	@Test(priority=7)
	public void machineReassign_DiffMake() throws IOException
	{

		RequestSpecification request = RestAssured.given();
		String url = endPoint.getMachineAssignmentURL();	
		System.out.println("MachineAssignment URL:" + url);
		List<Header> headerList = new ArrayList<>();
		Header header1 = new Header("Content-Type", testData.readExcel("Header", "Content-Type"));
		Header header2 = new Header("Authorization", testData.readExcel("Header", "Authorization"));
		Header header3 = new Header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_POST"));

		headerList.add(header1);
		headerList.add(header2);
		headerList.add(header3);
		Headers headers = new Headers(headerList);
		request.headers(headers); 
		String serialNumber = respPostDevice.getSerialNumber();

		//get the config_version from device table before machine assignment API
		String configVersionQuery = "Select config_version from device where serial_number='"+serialNumber+"'";
		String configVerion = dbConnector.executeSQLQuery(configVersionQuery);
		System.out.println("After db::" + configVerion);
		int preConfigVersion = Integer.parseInt(configVerion);

		//set the machineAssignment object for API request payload
		Machine machine = new Machine();
		machine.setDeviceNumber(serialNumber);
		machine.setMachineMake(testData.readExcel("MachineAssignment", "MakeChange_Make"));
		machine.setMachineModel(testData.readExcel("MachineAssignment", "MakeChange_Model"));
		Gson gson = new Gson();
		List<Machine> machines = new ArrayList<Machine>();
		machines.add(machine);
		String jsonInString = gson.toJson(machines);
		request.body(jsonInString);
		System.out.println("After setting body in request");
		Response response =request.post(url);
		ResponseBody body = response.getBody();
		System.out.println("response status code is :" + response.getStatusCode());
		System.out.println("response body :" + response.getBody());
		Assert.assertEquals(response.getStatusCode(), HttpStatus.SC_CREATED);

		JsonObject jsonObject = new JsonParser().parse(body.asString()).getAsJsonObject();
		System.out.println(jsonObject);
		//get processing id from response
		String processingId =jsonObject.get("ProcessingId").getAsString();
		System.out.println("ProcessingId is ::" + processingId);

		//Verify in database if the status is success.
		String query="Select status from config_update_status where processing_id='"+processingId+"'";
		String status = dbConnector.executeSQLQuery(query);
		Verify.verify(status.equalsIgnoreCase("success"));

		//Verify in device table if config version is incremented.
		configVerion = dbConnector.executeSQLQuery(configVersionQuery);
		int postConfigVersion = Integer.parseInt(configVerion);
		Verify.verify(postConfigVersion == preConfigVersion+1);

		//Verify if record is inserted in machine_assignment table
		String machineAssignmentQuery = "Select count(*) from machine_assignment where delete_status='1' and device_serial_number='"
				+ machine.getDeviceNumber() + "' and machine_make='"+ machine.getMachineMake()+
				"' and machine_model='" + machine.getMachineModel()+ "'";
		System.out.println(machineAssignmentQuery);
		String resultCount = dbConnector.executeSQLQuery(machineAssignmentQuery);
		Verify.verify(Integer.parseInt(resultCount) == 1);

		//Get the json configuration from device table.
		String deviceQuery = "Select json_config_payload from device where serial_number='"+serialNumber+"'";
		String result = dbConnector.executeSQLQuery(deviceQuery);
		System.out.println(result);
		jsonObject = new JsonParser().parse(result).getAsJsonObject();

		//Verify if machine related parameters are updated in device configuration

		JsonArray array = jsonObject.get("mtr rtos +crash").getAsJsonArray();
		System.out.println("json value of paramgroup- mtr rtos+ crash::"+array);
		JsonObject paramValue = array.get(0).getAsJsonObject();
		System.out.println("json value of paramgroup::"+paramValue);
		String paramValueQuery = "SELECT name as param_name, value as param_value FROM machine_params_udf "
				+ "where machine_make='" + machine.getMachineMake()
				+ "' and machine_model='" + machine.getMachineModel()+"'";
		System.out.println(paramValueQuery);
		Map<String,String>  paramValueresult = dbConnector.executeSQLQuery_List_Map(paramValueQuery);
		System.out.println("after getting param values from db");
		Iterator<Map.Entry<String, String>> itr = paramValueresult.entrySet().iterator();
		while(itr.hasNext())
		{
			Map.Entry<String, String> paramNameValue =itr.next();
			System.out.println("from machine params udf table::"+paramNameValue.getKey()+":::"+paramNameValue.getValue());
			System.out.println("from device config value::"+ paramValue.get(paramNameValue.getKey()));
			System.out.println("from db map::" + "\""+ paramNameValue.getValue() +"\"");
			Verify.verify((paramValue.get(paramNameValue.getKey()).toString()).equals("\""+ paramNameValue.getValue() +"\""));

		}

		//Verify if battery related params are updated in json configuration of device
		String batteryQuery = "Select backup_power_low_level from machine_battery where machine_make='" 
				+ machine.getMachineMake() +"' and machine_model='" 
				+ machine.getMachineModel()+ "' and battery_type='"
				+ testData.readExcel("MachineAssignment", "BTChange_BatteryType")+ "'";
		System.out.println(batteryQuery);
		String backupPowerLowLevel = dbConnector.executeSQLQuery(batteryQuery);
		Verify.verify(jsonObject.get("backup power low level").getAsInt() == Integer.parseInt(backupPowerLowLevel));


		batteryQuery = "Select backup_power_ready_level from machine_battery where machine_make='" 
				+ machine.getMachineMake() +"' and machine_model='" 
				+ machine.getMachineModel()+ "' and battery_type='"
				+ testData.readExcel("MachineAssignment", "BTChange_BatteryType")+ "'";
		System.out.println(batteryQuery);
		String backupPowerReadyLevel = dbConnector.executeSQLQuery(batteryQuery);
		Verify.verify(jsonObject.get("backup power ready level").getAsInt() == Integer.parseInt(backupPowerReadyLevel));


		//Verify if the previous configuration is taken as backup
		String configBackupQuery = "Select count(*) from device_config_hist where serial_number='"+serialNumber+"' and version ='"+preConfigVersion+"'";
		String configBackupResult = dbConnector.executeSQLQuery(configBackupQuery);
		Verify.verify(Integer.parseInt(configBackupResult)==1);

		//Connect to MQTT Broker and subscribe to the topic if configuration is published.
		MQTTUtility mqttUtility = new MQTTUtility();
		mqttUtility.MQTTSubscriber(serialNumber,Integer.toString(postConfigVersion), true);
		mqttUtility.MQTTSubscriber(serialNumber,Integer.toString(postConfigVersion), false);

	}

	// 1. To POST a cell info request with incorrect authorisation
	@Test(priority=8)
	public void cellInfo_IncorrectAuthorisation() throws IOException
	{
		serialNumber = respPostDevice.getSerialNumber();
		System.out.println("serial number inside cellinfo::"+serialNumber);

		RequestSpecification request = RestAssured.given();
		String url = endPoint.getCellInfoURL();	
		System.out.println("CellInfo URL:" + url);
		List<Header> headerList = new ArrayList<>();
		Header header1 = new Header("Content-Type", testData.readExcel("Header", "Content-Type"));
		Header header2 = new Header("Authorization", testData.readExcel("Header", "Authorization"));
		Header header3 = new Header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_GET"));

		headerList.add(header1);
		headerList.add(header2);
		headerList.add(header3);
		Headers headers = new Headers(headerList);
		request.headers(headers); 

		//set the cellInfo object for API request payload
		SiteCell cellInfo = new SiteCell();
		cellIds =new ArrayList();
		cellIds.add("test");
		cellInfo.setCellIds(cellIds);
		cellInfo.setSiteId("8099");
		System.out.println("after setting cellInfo object");
		Gson gson = new Gson();
		List<SiteCell> cellInfos = new ArrayList<SiteCell>();
		cellInfos.add(cellInfo);
		String jsonInString = gson.toJson(cellInfos);
		request.body(jsonInString);
		System.out.println("After setting body in request");
		Response response =request.post(url);
		ResponseBody body = response.getBody();
		System.out.println("response status code is :" + response.getStatusCode());
		System.out.println("response body :" + response.getBody());
		Assert.assertEquals(response.getStatusCode(), HttpStatus.SC_UNAUTHORIZED);


	}
	// 2. To POST a cell info request with cell Id as null
	@Test(priority=9)
	public void cellInfo_cellIdIsNull() throws IOException
	{

		RequestSpecification request = RestAssured.given();
		String url = endPoint.getCellInfoURL();	
		System.out.println("CellInfo URL:" + url);
		List<Header> headerList = new ArrayList<>();
		Header header1 = new Header("Content-Type", testData.readExcel("Header", "Content-Type"));
		Header header2 = new Header("Authorization", testData.readExcel("Header", "Authorization"));
		Header header3 = new Header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_POST"));

		headerList.add(header1);
		headerList.add(header2);
		headerList.add(header3);
		Headers headers = new Headers(headerList);
		request.headers(headers); 

		//set the cellInfo object for API request payload
		SiteCell cellInfo = new SiteCell();
		cellInfo.setSiteId("8099");
		System.out.println("after setting cellInfo object");
		Gson gson = new Gson();
		List<SiteCell> cellInfos = new ArrayList<SiteCell>();
		cellInfos.add(cellInfo);
		String jsonInString = gson.toJson(cellInfos);
		request.body(jsonInString);
		System.out.println("After setting body in request");
		Response response =request.post(url);
		ResponseBody body = response.getBody();
		System.out.println("response status code is :" + response.getStatusCode());
		System.out.println("response body :" + response.getBody());
		Assert.assertEquals(response.getStatusCode(), HttpStatus.SC_BAD_REQUEST);


	}
	// 3. To POST a cell info request with siteId as null
	@Test(priority=10)
	public void cellInfo_siteIdIsNull() throws IOException
	{

		RequestSpecification request = RestAssured.given();
		String url = endPoint.getCellInfoURL();	
		System.out.println("CellInfo URL:" + url);
		List<Header> headerList = new ArrayList<>();
		Header header1 = new Header("Content-Type", testData.readExcel("Header", "Content-Type"));
		Header header2 = new Header("Authorization", testData.readExcel("Header", "Authorization"));
		Header header3 = new Header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_POST"));

		headerList.add(header1);
		headerList.add(header2);
		headerList.add(header3);
		Headers headers = new Headers(headerList);
		request.headers(headers); 

		//set the cellInfo object for API request payload
		SiteCell cellInfo = new SiteCell();
		cellIds =new ArrayList();
		cellIds.add("test");
		cellInfo.setCellIds(cellIds);
		cellInfo.setSiteId("");
		System.out.println("after setting cellInfo object");
		Gson gson = new Gson();
		List<SiteCell> cellInfos = new ArrayList<SiteCell>();
		cellInfos.add(cellInfo);
		String jsonInString = gson.toJson(cellInfos);
		request.body(jsonInString);
		System.out.println("After setting body in request");
		Response response =request.post(url);
		ResponseBody body = response.getBody();
		System.out.println("response status code is :" + response.getStatusCode());
		System.out.println("response body :" + response.getBody());
		Assert.assertEquals(response.getStatusCode(), HttpStatus.SC_CREATED);

		//verify in config status site the error is invalid site
	}
	// 4. To POST a cell info request with proper data and also store config version of all devices before API request.
	@Test(priority=11)
	public void cellInfo_proper() throws IOException
	{

		//Get the config version of the device before cellInfo API

		String query = "select d.config_version,d.serial_number from device d, machine_assignment m "
				+ "where m.device_serial_number=d.serial_number and m.delete_status='1' and "
				+ "d.delete_status='1' and m.site_id='"+testData.readExcel("MachineAssignment", "SiteChange_NodeId")
				+"' and m.device_serial_number='"+serialNumber+"'";
		String configVersion = dbConnector.executeSQLQuery(query);
		preConfigVersion = Integer.parseInt(configVersion);

		//CellInfo API
		RequestSpecification request = RestAssured.given();
		String url = endPoint.getCellInfoURL();	
		System.out.println("CellInfo URL:" + url);
		List<Header> headerList = new ArrayList<>();
		Header header1 = new Header("Content-Type", testData.readExcel("Header", "Content-Type"));
		Header header2 = new Header("Authorization", testData.readExcel("Header", "Authorization"));
		Header header3 = new Header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_POST"));

		headerList.add(header1);
		headerList.add(header2);
		headerList.add(header3);
		Headers headers = new Headers(headerList);
		request.headers(headers); 

		//set the cellInfo object for API request payload
		SiteCell cellInfo = new SiteCell();

		String cellId = RandomString.getAlphaNumericString(10);
		cellIds =new ArrayList();
		cellIds.add(cellId);
		cellIds.add(RandomString.getAlphaNumericString(10));
		cellInfo.setCellIds(cellIds);
		cellInfo.setSiteId(testData.readExcel("MachineAssignment", "SiteChange_NodeId"));
		System.out.println("after setting cellInfo object");
		Gson gson = new Gson();
		List<SiteCell> cellInfos = new ArrayList<SiteCell>();
		cellInfos.add(cellInfo);
		String jsonInString = gson.toJson(cellInfos);
		request.body(jsonInString);
		System.out.println("After setting body in request");
		Response response =request.post(url);
		ResponseBody body = response.getBody();
		System.out.println("response status code is :" + response.getStatusCode());
		System.out.println("response body :" + response.getBody());
		Assert.assertEquals(response.getStatusCode(), HttpStatus.SC_CREATED);

		JsonObject jsonObject = new JsonParser().parse(body.asString()).getAsJsonObject();
		System.out.println(jsonObject);
		//get processing id from response
		processingId =jsonObject.get("ProcessingId").getAsString();
		System.out.println("ProcessingId is ::" + processingId);
	}
	// 5. To verify if status is success in config_update_status_site
	@Test(priority=12)
	public void cellInfo_status() throws IOException
	{
		System.out.println("ProcessingId is ::" + processingId);
		String sqlQuery = "Select status from config_update_status_site where processing_id='"+processingId+"'";
		String result = dbConnector.executeSQLQuery(sqlQuery);
		Assert.assertTrue(result.equalsIgnoreCase("success"));
	}

	// 6. To verify if configuration and config version is taken as backup in device_config_hist table
	@Test(priority=13)
	public void cellInfo_backup() throws IOException
	{
		System.out.println("PreConfigVersion is ::" + preConfigVersion);
		String sqlQuery = "Select count(*) from device_config_hist where "
				+ "serial_number='"+serialNumber+"' and version='"+preConfigVersion+"'";
		String result = dbConnector.executeSQLQuery(sqlQuery);
		Assert.assertEquals(Integer.parseInt(result),1);
	}

	// 7. To verify if configuration is updated with cellIds
	@Test(priority=14)
	public void cellInfo_config_cellIds() throws IOException
	{

		String sqlQuery = "Select json_config_payload from device where "
				+ "serial_number='"+serialNumber+"'";
		String result = dbConnector.executeSQLQuery(sqlQuery);
		System.out.println("inside cellInfo config::" + result);
		JsonObject jsonObject = new JsonParser().parse(result).getAsJsonObject();

		JsonArray array = jsonObject.get("cellid").getAsJsonArray();
		System.out.println("cellIds from device configuration::" + array);
		System.out.println("cellIds added to site from api request::" + cellIds);
		//Assert.assertEquals(array, cellIds);
		Iterator<JsonElement> i = array.iterator();
		while(i.hasNext())
		{
			Assert.assertTrue(cellIds.contains(i.next().getAsString()));
		}

	}

	// 8. To verify if config version is incremented.
	@Test(priority=15)
	public void cellInfo_config_version() throws IOException
	{

		String sqlQuery = "Select config_version from device where "
				+ "serial_number='"+serialNumber+"'";
		String result = dbConnector.executeSQLQuery(sqlQuery);
		int postConfigVersion = Integer.parseInt(result);

		Assert.assertEquals(postConfigVersion, preConfigVersion+1);

	}

	// 8. To verify if configuration is published to two topics.
	@Test(priority=16)
	public void cellInfo_config_publish() throws IOException
	{

		MQTTUtility mqttUtility = new MQTTUtility();
		mqttUtility.MQTTSubscriber(serialNumber,Integer.toString(postConfigVersion), true);
		mqttUtility.MQTTSubscriber(serialNumber,Integer.toString(postConfigVersion), false);

	}

	// 8. To verify if configuration is not generated when same cellIds are sent.
	@Test(priority=17)
	public void cellInfo_same_cellIds() throws IOException
	{
		//Get the config version of the device before cellInfo API

		String query = "select d.config_version from device d, machine_assignment m "
				+ "where m.device_serial_number=d.serial_number and m.delete_status='1' and "
				+ "d.delete_status='1' and m.site_id='"+testData.readExcel("MachineAssignment", "SiteChange_NodeId")
				+"' and m.device_serial_number='"+serialNumber+"'";
		String configVersion = dbConnector.executeSQLQuery(query);
		preConfigVersion = Integer.parseInt(configVersion);
		System.out.println("before cellInfo API config version::" + preConfigVersion);
		//CellInfo API
		RequestSpecification request = RestAssured.given();
		String url = endPoint.getCellInfoURL();	
		System.out.println("CellInfo URL:" + url);
		List<Header> headerList = new ArrayList<>();
		Header header1 = new Header("Content-Type", testData.readExcel("Header", "Content-Type"));
		Header header2 = new Header("Authorization", testData.readExcel("Header", "Authorization"));
		Header header3 = new Header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_POST"));

		headerList.add(header1);
		headerList.add(header2);
		headerList.add(header3);
		Headers headers = new Headers(headerList);
		request.headers(headers); 

		//set the cellInfo object for API request payload
		SiteCell cellInfo = new SiteCell();
		System.out.println("cellIds from same cellIds test::" + cellIds);
		cellInfo.setCellIds(cellIds);
		cellInfo.setSiteId(testData.readExcel("MachineAssignment", "SiteChange_NodeId"));
		System.out.println("after setting cellInfo object");
		Gson gson = new Gson();
		List<SiteCell> cellInfos = new ArrayList<SiteCell>();
		cellInfos.add(cellInfo);
		String jsonInString = gson.toJson(cellInfos);
		request.body(jsonInString);
		System.out.println("After setting body in request");
		Response response =request.post(url);
		ResponseBody body = response.getBody();
		System.out.println("response status code is :" + response.getStatusCode());
		System.out.println("response body :" + response.getBody());
		Assert.assertEquals(response.getStatusCode(), HttpStatus.SC_CREATED);
		
		query = "select d.config_version from device d, machine_assignment m "
				+ "where m.device_serial_number=d.serial_number and m.delete_status='1' and "
				+ "d.delete_status='1' and m.site_id='"+testData.readExcel("MachineAssignment", "SiteChange_NodeId")
				+"' and m.device_serial_number='"+serialNumber+"'";
		configVersion = dbConnector.executeSQLQuery(query);
		postConfigVersion = Integer.parseInt(configVersion);
		System.out.println("After getting config version from db::" + postConfigVersion);
		Assert.assertEquals(preConfigVersion, postConfigVersion);
		
		
	}	
	
	/*// 8. To verify if DM app listens to the response of the device.
		@Test(priority=18)
		public void cellInfo_deviceResponse() throws Exception
		{
			String topic = "MTR/status/"+ serialNumber +"/updatedconfigversion";
			byte[] bytes = "".getBytes() ;
			MQTTPublish mqttPublish = new MQTTPublish();
			mqttPublish.publish(topic, bytes);
		}	*/
		
	// 8. To POST a machine de-assignment request  
	@Test(priority=20)
	public void machineDeassignment() throws IOException
	{

		RequestSpecification request = RestAssured.given();
		String url = endPoint.getMachineAssignmentURL();	
		System.out.println("MachineAssignment URL in deassignment:" + url);
		List<Header> headerList = new ArrayList<>();
		Header header1 = new Header("Content-Type", testData.readExcel("Header", "Content-Type"));
		Header header2 = new Header("Authorization", testData.readExcel("Header", "Authorization"));
		Header header3 = new Header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_POST"));

		headerList.add(header1);
		headerList.add(header2);
		headerList.add(header3);
		Headers headers = new Headers(headerList);
		request.headers(headers); 
		String serialNumber = respPostDevice.getSerialNumber();

		//get the config_version from device table before machine assignment API
		String configVersionQuery = "Select config_version from device where serial_number='"+serialNumber+"'";
		String configVerion = dbConnector.executeSQLQuery(configVersionQuery);
		System.out.println("After db::" + configVerion);
		int preConfigVersion = Integer.parseInt(configVerion);

		//set the machineAssignment object for API request payload
		Machine machine = new Machine();
		machine.setDeviceNumber(serialNumber);
		Gson gson = new Gson();
		List<Machine> machines = new ArrayList<Machine>();
		machines.add(machine);
		String jsonInString = gson.toJson(machines);
		request.body(jsonInString);
		System.out.println("After setting body in request");
		Response response =request.post(url);
		ResponseBody body = response.getBody();
		System.out.println("response status code is :" + response.getStatusCode());
		System.out.println("response body :" + response.getBody());
		Assert.assertEquals(response.getStatusCode(), HttpStatus.SC_CREATED);

		JsonObject jsonObject = new JsonParser().parse(body.asString()).getAsJsonObject();
		System.out.println(jsonObject);
		//get processing id from response
		String processingId =jsonObject.get("ProcessingId").getAsString();
		System.out.println("ProcessingId is ::" + processingId);

		//Verify in database if the status is success.
		String query="Select status from config_update_status where processing_id='"+processingId+"'";
		String status = dbConnector.executeSQLQuery(query);
		Verify.verify(status.equalsIgnoreCase("success"));

		//Verify in device table if config version is incremented.
		configVerion = dbConnector.executeSQLQuery(configVersionQuery);
		int postConfigVersion = Integer.parseInt(configVerion);
		Verify.verify(postConfigVersion == preConfigVersion+1);

		//Verify if record is soft deleted in machine_assignment table
		String machineAssignmentQuery = "Select count(*) from machine_assignment where delete_status='1' and device_serial_number='"
				+ machine.getDeviceNumber() + "'";
		System.out.println(machineAssignmentQuery);
		String resultCount = dbConnector.executeSQLQuery(machineAssignmentQuery);
		Verify.verify(Integer.parseInt(resultCount) == 0);

		//Get the json configuration from device table.
		String deviceQuery = "Select json_config_payload from device where serial_number='"+serialNumber+"'";
		String result = dbConnector.executeSQLQuery(deviceQuery);
		System.out.println(result);
		jsonObject = new JsonParser().parse(result).getAsJsonObject();

		//Get json configuration from device_config_hist table.
		String deviceHistQuery = "Select json_payload from device_config_hist where serial_number='"+serialNumber+"' and version='1'";
		String resultHist = dbConnector.executeSQLQuery(deviceHistQuery);
		System.out.println(resultHist);
		JsonObject jsonObjectHist = new JsonParser().parse(resultHist).getAsJsonObject();

		//Verify if cnfiguration of version 1 is present in device table when deassigned.
		Verify.verify(jsonObject.equals(jsonObjectHist));
		//Verify if the previous configuration is taken as backup
		String configBackupQuery = "Select count(*) from device_config_hist where serial_number='"+serialNumber+"' and version ='"+preConfigVersion+"'";
		String configBackupResult = dbConnector.executeSQLQuery(configBackupQuery);
		Verify.verify(Integer.parseInt(configBackupResult)==1);

		//Connect to MQTT Broker and subscribe to the topic if configuration is published.
		MQTTUtility mqttUtility = new MQTTUtility();
		mqttUtility.MQTTSubscriber(serialNumber,Integer.toString(postConfigVersion), true);
		mqttUtility.MQTTSubscriber(serialNumber,Integer.toString(postConfigVersion), false);

	}


	@Test(priority=21)
	public void Device_Registration_delete() throws IOException
	{
		RequestSpecification request = RestAssured.given();

		String url = endPoint.getDeviceURL()+"/"+ respPostDevice.getSerialNumber()+"/user"; 

		request.header("Content-Type", testData.readExcel("Header", "Content-Type"));
		request.header("Authorization",testData.readExcel("Header", "Authorization"));
		request.header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_DELETE"));
		Response response =request.delete(url);
		Assert.assertEquals(response.getStatusCode(), 200);

		//Also delete the record in machine assignment

	}

}