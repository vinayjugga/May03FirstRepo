package com.diversey.dm.utility;


import java.util.Optional;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.MqttTopic;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


public class MQTTPublish {
	

	EnvParams envParams = new EnvParams();
	private MqttClient client;
	private MqttConnectOptions connOpts;
	
    public Optional<MqttDeliveryToken> publish(String target, byte[] bytes) throws Exception  {
    	
    	MQTTUtility mqttUtility = new MQTTUtility();
    	String mqttAddress = envParams.getMqttAddress();
		String mqttUser = envParams.getMqttUser();
		String mqttPassword = envParams.getMqttPassword();
		System.out.println("MQTT Broker IP Address:"+ mqttAddress);
		connOpts = mqttUtility.setConnectionOptions(mqttAddress);
		System.out.println("Connecting to mqtt client..");
		client.connect(connOpts);
		System.out.println("Connected to mqtt client");
		
	        MqttTopic mqttTopic = client.getTopic(target);
	       
	        MqttMessage mqttMessage = new MqttMessage(bytes);
	        mqttMessage.setRetained(true);
	        
	        
	        MqttDeliveryToken mqttDeliveryToken = mqttTopic.publish(mqttMessage);
	        return Optional.ofNullable(mqttDeliveryToken);
	    }
	 
}
