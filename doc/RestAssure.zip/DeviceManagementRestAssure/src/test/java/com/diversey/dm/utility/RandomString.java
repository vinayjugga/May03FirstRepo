package com.diversey.dm.utility;

import java.util.Random;

import sun.security.provider.SecureRandom;

	public class RandomString { 
		 // function to generate a random string of length n   
	   public static  String getAlphaNumericString(int n) 
	    { 
		   StringBuilder sb = new StringBuilder(n);
	      if(n == 12)
	      {
	    	  String AlphaNumericString = "ABCDE"
                      + "0123456789"
                      + "abcde"; 

					// create StringBuffer size of AlphaNumericString 
					 
					
					for (int i = 0; i < n; i++) { 
					
					// generate a random number between 
					// 0 to AlphaNumericString variable length 
					int index 
					  = (int)(AlphaNumericString.length() 
					          * Math.random()); 
					
					// add Character one by one in end of sb 
					sb.append(AlphaNumericString 
					            .charAt(index)); 
						      }
	      }
					else {
	        // chose a Character random from this String 
	        String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
	                                    + "0123456789"
	                                    + "abcdefghijklmnopqrstuvxyz"; 
	  
	        // create StringBuffer size of AlphaNumericString 
	  
	        for (int i = 0; i < n; i++) { 
	  
	            // generate a random number between 
	            // 0 to AlphaNumericString variable length 
	            int index 
	                = (int)(AlphaNumericString.length() 
	                        * Math.random()); 
	  
	            // add Character one by one in end of sb 
	            sb.append(AlphaNumericString 
	                          .charAt(index)); 
	        } 
					}
	  
	        return sb.toString(); 
	    } 
	  
	   /* public static void main(String[] args) 
	    { 
	  
	        // Get the size n 
	        int n = 15; 
	  
	        // Get and display the alphanumeric string 
	        System.out.println(RandomString.getAlphaNumericString(n)); 
	    } */
	   
	   public static String randomMACAddress(){
		    Random rand = new Random();
		    byte[] macAddr = new byte[6];
		    rand.nextBytes(macAddr);

		    macAddr[0] = (byte)(macAddr[0] & (byte)254);  //zeroing last 2 bytes to make it unicast and locally adminstrated

		    StringBuilder sb = new StringBuilder(18);
		    for(byte b : macAddr){

		        if(sb.length() > 0)
		            sb.append(":");

		        sb.append(String.format("%02x", b));
		    }


		    return sb.toString();
		}
	}
	