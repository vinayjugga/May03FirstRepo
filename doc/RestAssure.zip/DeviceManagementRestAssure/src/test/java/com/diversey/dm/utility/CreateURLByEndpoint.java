package com.diversey.dm.utility;



public class CreateURLByEndpoint {

	EnvParams envParams = new EnvParams();
		
	public String createBaseURL() {
		return envParams.getEnvironment();
	}
	
	public String  getDevicesURL()
	{
		return createBaseURL() + "/deviceRegistrations" ;
	}
	
	public String getDeviceURL()
	{
		return createBaseURL() + "/deviceRegistration" ;
	}
	
	public String getDeviceSearchURL()
	{
		return createBaseURL() + "/deviceRegistration/search" ;
	}
	
	public String getDevicesByIdsURL()
	{
		return createBaseURL() + "/deviceRegistrationsByIds/" ;
	}
	
	public String getDevicesByMACAddressesURL()
	{
		return createBaseURL() + "/deviceMac/" ;
	}
	
	public String getDevicesBySerialNumbersURL()
	{
		return createBaseURL() + "/deviceSerialNumber/" ;
	}
	public String getDeviceTypeURL()
	{
		return createBaseURL() + "/devicetype" ;
	}
	public String getMachineAssignmentURL()
	{
		return createBaseURL() + "/machineAssignment" ;
	}
	public String getCellInfoURL()
	{
		return createBaseURL() + "/geofencing/cellinfo" ;
	}
}
