package com.diversey.dm.api.testcases;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.diversey.dm.model.Machine;
import com.diversey.dm.model.Site;
import com.diversey.dm.model.SiteCell;
import com.diversey.dm.utility.CreateURLByEndpoint;
import com.diversey.dm.utility.DataBaseConnector;
import com.diversey.dm.utility.MQTTUtility;
import com.diversey.dm.utility.RandomString;
import com.diversey.dm.utility.TestDataExcelUtility;
import com.google.common.base.Verify;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class CellInfoTest {

	TestDataExcelUtility testData =new TestDataExcelUtility();
	CreateURLByEndpoint endPoint = new CreateURLByEndpoint();
	DataBaseConnector dbConnector = new DataBaseConnector();
	MachineAssignmentTest machine = new MachineAssignmentTest();
	String serialNumber ;
	String processingId;
	int preConfigVersion;
	int postConfigVersion;
	// 1. To POST a cell info request with incorrect authorisation
	@Test(priority=8)
	public void cellInfo_IncorrectAuthorisation() throws IOException
	{
		serialNumber = machine.respPostDevice.getSerialNumber();
		System.out.println("serial number inside cellinfo::"+serialNumber);

		RequestSpecification request = RestAssured.given();
		String url = endPoint.getCellInfoURL();	
		System.out.println("CellInfo URL:" + url);
		List<Header> headerList = new ArrayList<>();
		Header header1 = new Header("Content-Type", testData.readExcel("Header", "Content-Type"));
		Header header2 = new Header("Authorization", testData.readExcel("Header", "Authorization"));
		Header header3 = new Header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_GET"));

		headerList.add(header1);
		headerList.add(header2);
		headerList.add(header3);
		Headers headers = new Headers(headerList);
		request.headers(headers); 

		//set the cellInfo object for API request payload
		SiteCell cellInfo = new SiteCell();
		List<String> cellIds =new ArrayList();
		cellIds.add("test");
		cellInfo.setCellIds(cellIds);
		cellInfo.setSiteId("8099");
		System.out.println("after setting cellInfo object");
		Gson gson = new Gson();
		List<SiteCell> cellInfos = new ArrayList<SiteCell>();
		cellInfos.add(cellInfo);
		String jsonInString = gson.toJson(cellInfos);
		request.body(jsonInString);
		System.out.println("After setting body in request");
		Response response =request.post(url);
		ResponseBody body = response.getBody();
		System.out.println("response status code is :" + response.getStatusCode());
		System.out.println("response body :" + response.getBody());
		Assert.assertEquals(response.getStatusCode(), HttpStatus.SC_UNAUTHORIZED);


	}
	// 2. To POST a cell info request with cell Id as null
	@Test(priority=9)
	public void cellInfo_cellIdIsNull() throws IOException
	{

		RequestSpecification request = RestAssured.given();
		String url = endPoint.getCellInfoURL();	
		System.out.println("CellInfo URL:" + url);
		List<Header> headerList = new ArrayList<>();
		Header header1 = new Header("Content-Type", testData.readExcel("Header", "Content-Type"));
		Header header2 = new Header("Authorization", testData.readExcel("Header", "Authorization"));
		Header header3 = new Header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_POST"));

		headerList.add(header1);
		headerList.add(header2);
		headerList.add(header3);
		Headers headers = new Headers(headerList);
		request.headers(headers); 

		//set the cellInfo object for API request payload
		SiteCell cellInfo = new SiteCell();
		cellInfo.setSiteId("8099");
		System.out.println("after setting cellInfo object");
		Gson gson = new Gson();
		List<SiteCell> cellInfos = new ArrayList<SiteCell>();
		cellInfos.add(cellInfo);
		String jsonInString = gson.toJson(cellInfos);
		request.body(jsonInString);
		System.out.println("After setting body in request");
		Response response =request.post(url);
		ResponseBody body = response.getBody();
		System.out.println("response status code is :" + response.getStatusCode());
		System.out.println("response body :" + response.getBody());
		Assert.assertEquals(response.getStatusCode(), HttpStatus.SC_BAD_REQUEST);


	}
	// 3. To POST a cell info request with siteId as null
	@Test(priority=10)
	public void cellInfo_siteIdIsNull() throws IOException
	{

		RequestSpecification request = RestAssured.given();
		String url = endPoint.getCellInfoURL();	
		System.out.println("CellInfo URL:" + url);
		List<Header> headerList = new ArrayList<>();
		Header header1 = new Header("Content-Type", testData.readExcel("Header", "Content-Type"));
		Header header2 = new Header("Authorization", testData.readExcel("Header", "Authorization"));
		Header header3 = new Header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_POST"));

		headerList.add(header1);
		headerList.add(header2);
		headerList.add(header3);
		Headers headers = new Headers(headerList);
		request.headers(headers); 

		//set the cellInfo object for API request payload
		SiteCell cellInfo = new SiteCell();
		List<String> cellIds =new ArrayList();
		cellIds.add("test");
		cellInfo.setCellIds(cellIds);
		cellInfo.setSiteId("");
		System.out.println("after setting cellInfo object");
		Gson gson = new Gson();
		List<SiteCell> cellInfos = new ArrayList<SiteCell>();
		cellInfos.add(cellInfo);
		String jsonInString = gson.toJson(cellInfos);
		request.body(jsonInString);
		System.out.println("After setting body in request");
		Response response =request.post(url);
		ResponseBody body = response.getBody();
		System.out.println("response status code is :" + response.getStatusCode());
		System.out.println("response body :" + response.getBody());
		Assert.assertEquals(response.getStatusCode(), HttpStatus.SC_CREATED);

		//verify in config status site the error is invalid site
	}
	// 4. To POST a cell info request with proper data and also store config version of all devices before API request.
	@Test(priority=11)
	public void cellInfo_proper() throws IOException
	{

		//Get the config version of the device before cellInfo API

		String query = "select d.config_version,d.serial_number from device d, machine_assignment m "
				+ "where m.device_serial_number=d.serial_number and m.delete_status='1' and "
				+ "d.delete_status='1' and m.site_id='"+testData.readExcel("MachineAssignment", "SiteChange_NodeId")
				+"' and m.device_serial_number='"+serialNumber+"'";
		String configVersion = dbConnector.executeSQLQuery(query);
		preConfigVersion = Integer.parseInt(configVersion);

		//CellInfo API
		RequestSpecification request = RestAssured.given();
		String url = endPoint.getCellInfoURL();	
		System.out.println("CellInfo URL:" + url);
		List<Header> headerList = new ArrayList<>();
		Header header1 = new Header("Content-Type", testData.readExcel("Header", "Content-Type"));
		Header header2 = new Header("Authorization", testData.readExcel("Header", "Authorization"));
		Header header3 = new Header("x-div-dm-signature", testData.readExcel("Header", "x-div-dm-signature_POST"));

		headerList.add(header1);
		headerList.add(header2);
		headerList.add(header3);
		Headers headers = new Headers(headerList);
		request.headers(headers); 

		//set the cellInfo object for API request payload
		SiteCell cellInfo = new SiteCell();

		String cellId = RandomString.getAlphaNumericString(10);
		List<String> cellIds =new ArrayList();
		cellIds.add(cellId);
		cellIds.add(RandomString.getAlphaNumericString(10));
		cellInfo.setCellIds(cellIds);
		cellInfo.setSiteId(testData.readExcel("MachineAssignment", "SiteChange_NodeId"));
		System.out.println("after setting cellInfo object");
		Gson gson = new Gson();
		List<SiteCell> cellInfos = new ArrayList<SiteCell>();
		cellInfos.add(cellInfo);
		String jsonInString = gson.toJson(cellInfos);
		request.body(jsonInString);
		System.out.println("After setting body in request");
		Response response =request.post(url);
		ResponseBody body = response.getBody();
		System.out.println("response status code is :" + response.getStatusCode());
		System.out.println("response body :" + response.getBody());
		Assert.assertEquals(response.getStatusCode(), HttpStatus.SC_CREATED);

		JsonObject jsonObject = new JsonParser().parse(body.asString()).getAsJsonObject();
		System.out.println(jsonObject);
		//get processing id from response
		processingId =jsonObject.get("ProcessingId").getAsString();
		System.out.println("ProcessingId is ::" + processingId);
	}
	// 5. To verify if status is success in config_update_status_site
	@Test(priority=12)
	public void cellInfo_status() throws IOException
	{
		System.out.println("ProcessingId is ::" + processingId);
		String sqlQuery = "Select status from config_update_status_site where processing_id='"+processingId+"'";
		String result = dbConnector.executeSQLQuery(sqlQuery);
		Assert.assertTrue(result.equalsIgnoreCase("success"));
	}

	// 6. To verify if configuration and config version is taken as backup in device_config_hist table
	@Test(priority=13)
	public void cellInfo_backup() throws IOException
	{
		System.out.println("PreConfigVersion is ::" + preConfigVersion);
		String sqlQuery = "Select count(*) from device_config_hist where "
				+ "serial_number='"+serialNumber+"' and version='"+preConfigVersion+"'";
		String result = dbConnector.executeSQLQuery(sqlQuery);
		Assert.assertEquals(Integer.parseInt(result),1);
	}

	// 7. To verify if configuration is updated with cellIds
	@Test(priority=14)
	public void cellInfo_config_cellIds() throws IOException
	{

		String sqlQuery = "Select json_config_payload from device where "
				+ "serial_number='"+serialNumber+"'";
		String result = dbConnector.executeSQLQuery(sqlQuery);
		System.out.println("inside cellInfo config::" + result);
		JsonObject jsonObject = new JsonParser().parse(result).getAsJsonObject();

		JsonArray array = jsonObject.get("cellid").getAsJsonArray();
		System.out.println("cellIds from device configuration::" + array);
	}
}
