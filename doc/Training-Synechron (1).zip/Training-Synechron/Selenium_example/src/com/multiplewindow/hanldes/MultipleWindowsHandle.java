package com.multiplewindow.hanldes;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class MultipleWindowsHandle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		//driver.get("https://www.wellsfargo.com/");
		driver.get("http://www.seleniummaster.com");
		driver.manage().window().maximize(); 
		
		driver.findElement(By.xpath("//img[@alt='SeleniumMasterLogo']")).click();  
	     // Storing parent window reference into a String Variable  
	     String Parent_Window = driver.getWindowHandle();    
	      // Switching from parent window to child window   
	     for (String Child_Window : driver.getWindowHandles())  
	     {  
	     driver.switchTo().window(Child_Window);  
	     // Performing actions on child window  
	     driver.findElement(By.id("dropdown_txt")).click();  
	     List<WebElement>  dropdownitems=driver.findElements(By.xpath("//div[@id='DropDownitems']//div"));  
	     int dropdownitems_Size=dropdownitems.size();  
	     System.out.println("Dropdown item size is:"+dropdownitems_Size);  
	     dropdownitems.get(1).click();  
	     driver.findElement(By.xpath("//*[@id='anotherItemDiv']")).click();  
	     }  
	     //Switching back to Parent Window  
	     driver.switchTo().window(Parent_Window);  
	     //Performing some actions on Parent Window  
	     driver.findElement(By.className("btn_style")).click();
	}

}
