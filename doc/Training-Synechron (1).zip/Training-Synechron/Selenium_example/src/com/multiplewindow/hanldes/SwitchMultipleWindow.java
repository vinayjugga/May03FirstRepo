package com.multiplewindow.hanldes;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SwitchMultipleWindow {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		//driver.get("https://www.wellsfargo.com/");
		driver.get("http://toolsqa.wpengine.com/automation-practice-switch-windows/");
		driver.manage().window().maximize(); 
		
		String ParentWindowhandle= driver.getWindowHandle();
		//System.out.println("CurrentWindow:="+driver.getCurrentUrl());
        //System.out.println(handle);

        // Click on the Button "New Message Window"

        driver.findElement(By.xpath("//button[text()='New Message Window']")).click();

        // Store and Print the name of all the windows open	              

        Set<String> handles = driver.getWindowHandles();
       // System.out.println("Currentchild Window:="+driver.getCurrentUrl());

       // System.out.println(handles);        
        driver.switchTo().window("A new title is here");  
        // Pass a window handle to the other window

        for (String handle1 : driver.getWindowHandles()) {
        	Thread.sleep(5000);
        	System.out.println(handle1);
        	System.out.println("Currentchild Window:="+handle1 +":="+driver.getCurrentUrl());
        	System.out.println("Currentchild Window:="+handle1 +":="+driver.getTitle());

        	driver.switchTo().window(handle1);        	
        	if(!ParentWindowhandle.equals(handle1))
        	{
        		driver.close();
        	}
        	driver.switchTo().window(ParentWindowhandle);
        	
        	Thread.sleep(5000);
        	driver.findElement(By.xpath("//button[text()='New Message Window']")).click();
        	/*if(driver.getTitle().equals("Demo Windows for practicing Selenium Automation"))
        	{
        		driver.close();
        		System.out.println("Closed the child window");
        	}*/
        	
	}

	}
}
