package com.navigation.command;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Navigation_To {

	public static void main(String[] args) {
				
		System.setProperty("webdriver.chrome.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/chromedriver.exe");
		WebDriver driver = new ChromeDriver();		
		driver.navigate().to("http://javabeginnerstutorial.com/");
		System.out.println(driver.getCurrentUrl());
		driver.close();// TODO Auto-generated method stub

	}

}
