package com.navigation.command;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Navigation_Forward {

	public static void main(String[] args) {
	
	System.setProperty("webdriver.chrome.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.get("http://toolsqa.com/");	
	System.out.println("getCurrentUrl() 1-URL : = "+driver.getCurrentUrl());	
	driver.get("http://www.seleniumhq.org/");
	System.out.println("getCurrentUrl() 2-URL : = "+driver.getCurrentUrl());
	driver.navigate().back();
	System.out.println("getCurrentUrl() URL Previous WebPage : = "+driver.getCurrentUrl());
	driver.get("https://www.wellsfargo.com/");	
	System.out.println("getCurrentUrl() 3-URL : = "+driver.getCurrentUrl());
	driver.navigate().back();
	System.out.println("getCurrentUrl() URL Previous WebPage : = "+driver.getCurrentUrl());
	driver.navigate().forward();
	System.out.println("getCurrentUrl() URL Fowrward WebPage : = "+driver.getCurrentUrl());
	driver.quit();
	}
}
