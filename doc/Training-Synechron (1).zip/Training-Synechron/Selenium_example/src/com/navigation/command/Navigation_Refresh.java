package com.navigation.command;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Navigation_Refresh {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.wellsfargo.com/");
		driver.navigate().refresh(); 
		
		driver.get("http://www.seleniumhq.org/");
		driver.navigate().to(driver.getCurrentUrl());
		
		driver.get("https://accounts.google.com/SignUp");
		driver.findElement(By.id("FirstName")).sendKeys("vinay");
		driver.findElement(By.id("FirstName")).sendKeys(Keys.F5);
		
		driver.get("http://toolsqa.com/");	
		driver.get(driver.getCurrentUrl());		
		
		driver.get("https://accounts.google.com/SignUp");
		driver.findElement(By.id("FirstName")).sendKeys("vinay");
		driver.findElement(By.id("FirstName")).sendKeys("\uE035"); //F5 Unicode PUA (Private Use Area) code
				
		driver.get("http://www.seleniumhq.org/");
		JavascriptExecutor jse = (JavascriptExecutor) driver ;
		jse.executeScript("history.go(0)");
		
		driver.get("http://toolsqa.com/");	
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys(Keys.F5);
		
		driver.quit();

	}

}
