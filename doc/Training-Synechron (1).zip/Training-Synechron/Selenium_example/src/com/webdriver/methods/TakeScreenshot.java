package com.webdriver.methods;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;

public class TakeScreenshot {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.wellsfargo.com/");
		
		EventFiringWebDriver edriver = new EventFiringWebDriver(driver);   
		File srcFile = edriver.getScreenshotAs(OutputType.FILE);  
		FileUtils.copyFile(srcFile, new File("C://test/google.png")); 
		driver.close(); 
		
	}

}
