package com.webdriver.methods;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.asserts.SoftAssert;

public class Mouse_Actions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/chromedriver.exe");
		WebDriver driver = new ChromeDriver() ;
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		SoftAssert a1 = new SoftAssert();
		driver.get("https://www.wellsfargo.com/");
		Actions act1 = new Actions(driver);
		WebElement elemnt = driver.findElement(By.id("bankingTab"));
		act1.moveToElement(elemnt).perform();

		WebElement el1 = driver.findElement(By.linkText("Online Banking"));
		act1.moveToElement(el1).click().build().perform();
		/*act1.clickAndHold() ;
		act1.doubleClick(el1);*/
		//act1.
	
		
		Actions actionmenu = new Actions(driver);  
		actionmenu.contextClick(el1).perform() ; 
		actionmenu.sendKeys("w").perform() ;
		
		
	}

}
