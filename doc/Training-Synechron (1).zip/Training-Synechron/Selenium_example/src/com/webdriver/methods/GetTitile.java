package com.webdriver.methods;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetTitile {

	public static void main(String[] args) {
		
	System.setProperty("webdriver.chrome.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	
	driver.get("http://toolsqa.com/");	
	System.out.println("Get Title of the Page:="+driver.getTitle());
	driver.get("http://www.techbeamers.com/websites-to-practice-selenium-webdriver-online/");	
	System.out.println("Get Title of the Page:="+driver.getTitle());
	driver.close();
	
}
}
