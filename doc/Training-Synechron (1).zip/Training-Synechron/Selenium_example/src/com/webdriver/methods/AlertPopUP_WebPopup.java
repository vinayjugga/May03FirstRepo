package com.webdriver.methods;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertPopUP_WebPopup {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		//driver.get("https://www.wellsfargo.com/");
		driver.get("http://services.irctc.co.in/");  
		//driver.findElement(By.id("button")).click();  
		//driver.findElement(By.name("button")).click() ; 
		//driver.findElement(By.cssSelector("input[id ='button']")).click() ; 
		driver.findElement(By.xpath("//input[@id ='button']")).click() ;  
		try{ 
		
		   Alert alret = driver.switchTo().alert(); 
		   System.out.println("Alert is present");  
		   String msg = alret.getText() ;  
		   System.out.println(msg);  
		   alret.accept() ;    
		   } 
		catch(NoAlertPresentException e )
		{  
			System.out.println("Alret is not present");
		}   
		//driver.close();
	}

}
