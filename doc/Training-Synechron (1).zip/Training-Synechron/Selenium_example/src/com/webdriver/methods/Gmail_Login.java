package com.webdriver.methods;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class Gmail_Login {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/chromedriver.exe");
		WebDriver driver = new ChromeDriver() ;
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.get("https://mail.google.com");
		driver.findElement(By.id("Email")).sendKeys("vinay.synechron@gmail.com");
		driver.findElement(By.id("next")).click();
		driver.findElement(By.id("Passwd")).sendKeys("synechron123");
		driver.findElement(By.id("signIn")).click();		

		WebDriverWait wait = new WebDriverWait(driver,60);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[text()='COMPOSE']")));
		driver.findElement(By.xpath("//div[text()='COMPOSE']")).click();

		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//h2[div[text()='New Message']]"))));

		driver.findElement(By.xpath("//textarea[@aria-label='To']")).sendKeys("vinay.synechron@gmail.com");
		driver.findElement(By.xpath("//input[@name='subjectbox']")).sendKeys("abcd123");
		driver.findElement(By.xpath("//div[text()='Send']")).click();

		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//div[@class='vh']//span[@id='link_vsm']"))));
		driver.findElement(By.xpath("//div[@class='vh']//span[@id='link_vsm']")).click();

		String expectedSubject =driver.findElement(By.xpath("//h2[text()='abcd123']")).getText();
		System.out.println(expectedSubject);
		Assert.assertEquals(expectedSubject, "abcd123");

		driver.findElement(By.linkText("Inbox")).click();
		Assert.assertTrue(driver.findElement(By.xpath("//div[@class='Cp']//tr[1]")).isDisplayed());
		String color1 =driver.findElement(By.xpath("//a[@title='Sent Mail']")).getCssValue("color");	
		System.out.println("Beofore click:="+color1);
		driver.findElement(By.xpath("//a[@title='Sent Mail']")).click();
		String color =driver.findElement(By.xpath("//a[@title='Sent Mail']")).getCssValue("color");	
		System.out.println("After click :="+color);
		driver.findElement(By.linkText("Inbox")).click();
		driver.findElement(By.xpath("//div[@class='Cp']//td[1]")).click();

		driver.findElement(By.xpath("//div[@aria-label='Delete']")).click();
		driver.close();

	}

}
