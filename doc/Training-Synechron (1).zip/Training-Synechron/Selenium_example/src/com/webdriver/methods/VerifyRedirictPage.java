package com.webdriver.methods;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class VerifyRedirictPage {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();  
		
		driver.get("http:\\www.google.com");  
		
		String url =driver.getCurrentUrl();  
		
		System.out.println(url); 
		
		if(url.contains("google.co.in"))			
		{ 
			System.out.println("Google.com navigated to goodle.co.in successfully");
		}
		else 			
		{ 
			System.out.println("Google.com is not navigated to google.co.in ");
		}  
		
		driver.close(); 

	}

}
