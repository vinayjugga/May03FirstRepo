package com.webdriver.methods;

import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CalenderDateSelect {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		HashMap<String,Integer> month1 = new HashMap<String,Integer>();
		month1.put("December 2016", 12);
	
		String selectedMonthFrom="January 2017";
		String dateselectedFrom= "25" ;
		String selectedMonthTo="March 2017";
		String dateselectedTo= "25" ;
		
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);
		driver.get("http://spicejet.com/");
		driver.findElement(By.id("ctl00_mainContent_ddl_originStation1_CTXT")).click();
		driver.findElement(By.partialLinkText("Bengaluru")).click();
		driver.findElement(By.id("ctl00_mainContent_ddl_destinationStation1_CTXT")).click();
		driver.findElement(By.partialLinkText("Ahmedabad")).click();
		
		driver.findElement(By.name("ctl00$mainContent$txt_Fromdate")).click();
		//driver.findElement(By.linkText("Next")).click();
		String month=driver.findElement(By.xpath("//div[@class='ui-datepicker-title']")).getText() ;
		System.out.println(month);
		
		while(true){
			if(month.contains(selectedMonthFrom))
			{
				break;
				
			}
			driver.findElement(By.linkText("Next")).click();
			month=driver.findElement(By.xpath("//div[@class='ui-datepicker-title']")).getText() ;
		}		
		
		List<WebElement> dateselect = driver.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//td"));
		for(WebElement date1:dateselect)
		{
			if(date1.getText().equals(dateselectedFrom))
					{
				date1.click();
				break;
					}
		}
		
		driver.findElement(By.name("ctl00$mainContent$txt_Todate")).click();
		month=driver.findElement(By.xpath("//div[@class='ui-datepicker-title']")).getText() ;
		System.out.println(month);
		
		while(true){
			if(month.contains(selectedMonthTo))
			{
				break;
				
			}
			driver.findElement(By.linkText("Next")).click();
			month=driver.findElement(By.xpath("//div[@class='ui-datepicker-title']")).getText() ;
		}		
		
		dateselect = driver.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//td"));
		for(WebElement date1:dateselect)
		{
			if(date1.getText().equals(dateselectedTo))
					{
				date1.click();
				break;
					}
		}		
		
	}

}
