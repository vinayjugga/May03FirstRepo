package com.webdriver.methods;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;

public class Count_Links_inWebPage {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/chromedriver.exe");
		WebDriver driver = new ChromeDriver() ;
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);			
		
		driver.get("https://www.google.co.in");
		driver.findElement(By.id("lst-ib")).sendKeys("vinay");
		driver.findElement(By.id("lst-ib")).sendKeys(Keys.ENTER);

		List<WebElement> countlinks = driver.findElements(By.xpath("//h3/a"));
		System.out.println("Number of links :="+countlinks.size());
		int n =countlinks.size();
		for(int i=0; i< countlinks.size(); i++)
		{
			System.out.println("liks are:="+countlinks.get(i).getAttribute("href"));
			countlinks =driver.findElements(By.xpath("//h3/a"));
		}
	}

}
