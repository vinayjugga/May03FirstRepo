package com.webdriver.methods;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class GamilLogin_Logout_Compose_Mail {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/chromedriver.exe");
		WebDriver driver = new ChromeDriver() ;
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.get("https://mail.google.com");
		driver.findElement(By.id("Email")).sendKeys("vinay.synechron@gmail.com");
		driver.findElement(By.id("next")).click();
		driver.findElement(By.id("Passwd")).sendKeys("synechron123");
		driver.findElement(By.id("signIn")).click();		

		WebDriverWait wait = new WebDriverWait(driver,60);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[text()='COMPOSE']")));
		driver.findElement(By.xpath("//div[text()='COMPOSE']")).click();

		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//h2[div[text()='New Message']]"))));
		String subject ="abcd123"+Math.random();
		//String subject ="Farewell";
		String sub =subject.substring(8);
		driver.findElement(By.xpath("//textarea[@aria-label='To']")).sendKeys("vinay.synechron@gmail.com");
		driver.findElement(By.xpath("//input[@name='subjectbox']")).sendKeys(sub);
		driver.findElement(By.xpath(("//div[@aria-label ='Message Body']"))).sendKeys(subject);
		driver.findElement(By.xpath("//div[text()='Send']")).click();
		
		/*if(driver.switchTo().alert() !=null)
		{
			driver.switchTo().alert().accept();
		}*/
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.findElement(By.id("gbqfq")).sendKeys(subject);
		driver.findElement(By.id("gbqfq")).submit();
		
		List<WebElement> inboxrows =driver.findElements(By.xpath("//div[@class='Cp']//tr"));
		System.out.println(inboxrows.size());
		System.out.println(inboxrows.get(0).getText());
		
		inboxrows.get(0).click();
		
		String body =driver.findElement(By.xpath("//div[@role='listitem']//div[@class='adn ads']")).getText() ;
		System.out.println("Bodycontent:="+body);
			
		driver.close();
	}

}
