package com.webdriver.methods;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Count_Number_Coloumn_Tables {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/chromedriver.exe");
		WebDriver driver = new ChromeDriver() ;
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		//driver.
		driver.get("http://toolsqa.wpengine.com/automation-practice-table/");
		String structureheader="Taipei 101";
		List<WebElement> numberofRows=driver.findElements(By.xpath("//table[@class='tsc_table_s13']//tr"));
		System.out.println("Number of Row:="+numberofRows.size());
		int i=1;
		for(WebElement row:numberofRows)
		{
			List<WebElement> numberofColomnheader =row.findElements(By.xpath("//th")) ;
			for(WebElement Colomnheader:numberofColomnheader)
			{
				//System.out.println(Colomnheader.getText());
				if(Colomnheader.getText().equals(structureheader))
				{
					String build=driver.findElement(By.xpath("//th[text()=\'"+structureheader+"']/..//td[4]")).getText();
					System.out.println("Year of build "+structureheader+":="+build);
				}

				i++;
			}

		}

	}

}
