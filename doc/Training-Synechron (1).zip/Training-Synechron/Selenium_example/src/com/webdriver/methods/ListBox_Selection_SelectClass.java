package com.webdriver.methods;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class ListBox_Selection_SelectClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.get("https://www.wellsfargo.com/");
		
		WebElement listbox =driver.findElement(By.id("destination"));
		
		Select select = new Select(listbox);
		//select.selectByIndex(3);
		//select.selectByVisibleText("Messages and Alerts");
		select.deselectByValue("MessageAlerts");
		select.isMultiple() ;

	}

}
