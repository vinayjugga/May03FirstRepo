package com.webdriver.methods;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WithoutSyncehronions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://mail.google.com");
		driver.findElement(By.id("Email")).sendKeys("vinay.synechron@gmail.com");
		driver.findElement(By.id("next")).click();
		driver.findElement(By.id("Passwd")).sendKeys("synechron123");
		driver.findElement(By.id("signIn")).click();	
		
		while(true) 
		{   
			try  
			{   
				driver.findElement(By.id("logoutLink")).click(); 
				break; 
			}  
			catch(NoSuchElementException e)
			{ 
				
			}   
			}  
		driver.close();  
	}

}
