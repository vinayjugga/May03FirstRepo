package com.webdriver.methods;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetCurrentURL {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://www.seleniumhq.org/");	
		System.out.println("getCurrentUrl() URL : = "+driver.getCurrentUrl());
		driver.get("https://www.wellsfargo.com/");	
		System.out.println("getCurrentUrl() URL : = "+driver.getCurrentUrl());
		driver.get("http://beginnersbook.com/");	
		System.out.println("getCurrentUrl() URL : = "+driver.getCurrentUrl());
		driver.close();
		
	}

}
