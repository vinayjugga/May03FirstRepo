package com.webdriver.methods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Xpath_Parent_child {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("http://www.irctc.com"); 
		String xp1 ="//label[text()='Mumbai']/..//label[text() =': 02222618067']" ; 
		String text1 =driver.findElement(By.xpath(xp1)).getText(); 
		System.out.println(text1); 
		String xp2 ="//label[text()='For Internet Ticketing Complaints ']/..//label[text() =': care@irctc.co.in']" ; 
		String text2 = driver.findElement(By.xpath(xp2)).getText() ; 
		System.out.println(text2);   
		String text3 =driver.findElement(By.partialLinkText("INDIAN RAILWAY CATERING")).getAttribute("title") ;  
		System.out.println(text3);   
		
		
	}

}
