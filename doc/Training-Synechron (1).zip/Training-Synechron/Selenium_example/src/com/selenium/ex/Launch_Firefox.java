package com.selenium.ex;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Launch_Firefox {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				System.setProperty("webdriver.gecko.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/geckodriver.exe");
				FirefoxDriver driver = new FirefoxDriver() ;
				driver.get("https://www.google.co.in");
				System.out.println(driver.getCurrentUrl());		
		}

}
