package com.annotations.testng;

import org.testng.Assert;
import org.testng.annotations.Test;
//import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class SampleTest {

	String message = "Hello World";
	   MessageUtil messageUtil = new MessageUtil(message);

	   @Test
	   public void testPrintMessage() {
	      Assert.assertEquals("Hello World", messageUtil.printMessage());
	   }
	   
	   @Test
	   public void testPrintMessage1() {
		   System.out.println("in second method");
		   SoftAssert sft = new SoftAssert();
		   sft.assertEquals("Hello World123", messageUtil.printMessage());      
	      Assert.assertEquals(true, false);
	      sft.assertAll();
	   }
	   
}
