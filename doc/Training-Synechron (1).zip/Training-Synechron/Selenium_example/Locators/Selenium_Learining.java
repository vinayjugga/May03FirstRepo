import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Selenium_Learining {
	
	@Test
	public void invokeFirefoxBrowser()
	{
		//System.setProperty("webdriver.gecko.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/wires.exe");
		System.setProperty("webdriver.gecko.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/geckodriver.exe");
		WebDriver driver = new FirefoxDriver() ;
		driver.get("https://www.google.co.in");
		System.out.println(driver.getCurrentUrl());		
		//driver.close();
	}

	@Test
	public void invokeChromeBrowser()
	{
		System.setProperty("webdriver.chrome.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://javabeginnerstutorial.com/");	
		System.out.println(driver.getCurrentUrl());
		driver.close();
	}
	
	@Test
	public void invokeInternetBrowser()
	{
		System.setProperty("webdriver.ie.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/IEDriverServer.exe");
		WebDriver driver = new InternetExplorerDriver();
		driver.get("http://www.seleniumframework.com/");
		System.out.println(driver.getCurrentUrl());
		driver.close();
	}
	
	@Test
	public void getCurrentUrl()
	{
		System.setProperty("webdriver.chrome.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://www.seleniumhq.org/");	
		System.out.println("getCurrentUrl() URL : = "+driver.getCurrentUrl());
		driver.get("https://www.wellsfargo.com/");	
		System.out.println("getCurrentUrl() URL : = "+driver.getCurrentUrl());
		driver.get("http://beginnersbook.com/");	
		System.out.println("getCurrentUrl() URL : = "+driver.getCurrentUrl());
		driver.close();
	}
	
	@Test
	public void getTitle()
	{
		System.setProperty("webdriver.chrome.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://toolsqa.com/");	
		System.out.println("Get Title of the Page:="+driver.getTitle());
		driver.get("http://www.techbeamers.com/websites-to-practice-selenium-webdriver-online/");	
		System.out.println("Get Title of the Page:="+driver.getTitle());
		driver.close();
		
	}
	
	@Test
	public void getPageSource()
	{
		System.setProperty("webdriver.chrome.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://toolsqa.com/");	
		System.out.println("PageSource :="+driver.getPageSource());		
		driver.close();
	}
	
	@Test
	public void navigationCommands()
	{
		System.setProperty("webdriver.chrome.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://toolsqa.com/");	
		System.out.println("getCurrentUrl() 1-URL : = "+driver.getCurrentUrl());
		driver.navigate().refresh();
		driver.get("http://www.seleniumhq.org/");
		System.out.println("getCurrentUrl() 2-URL : = "+driver.getCurrentUrl());
		driver.navigate().back();
		System.out.println("getCurrentUrl() URL Previous WebPage : = "+driver.getCurrentUrl());
		driver.get("https://www.wellsfargo.com/");	
		System.out.println("getCurrentUrl() 3-URL : = "+driver.getCurrentUrl());
		driver.navigate().back();
		System.out.println("getCurrentUrl() URL Previous WebPage : = "+driver.getCurrentUrl());
		driver.navigate().forward();
		System.out.println("getCurrentUrl() URL Fowrward WebPage : = "+driver.getCurrentUrl());
		driver.quit();
	}
	
	@Test
	public void refresh7WaysInSelenium()
	{
		System.setProperty("webdriver.chrome.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.wellsfargo.com/");
		driver.navigate().refresh(); 
		
		driver.get("http://www.seleniumhq.org/");
		driver.navigate().to(driver.getCurrentUrl());
		
		driver.get("https://accounts.google.com/SignUp");
		driver.findElement(By.id("FirstName")).sendKeys("vinay");
		driver.findElement(By.id("FirstName")).sendKeys(Keys.F5);
		
		driver.get("http://toolsqa.com/");	
		driver.get(driver.getCurrentUrl());		
		
		driver.get("https://accounts.google.com/SignUp");
		driver.findElement(By.id("FirstName")).sendKeys("vinay");
		driver.findElement(By.id("FirstName")).sendKeys("\uE035"); //F5 Unicode PUA (Private Use Area) code
				
		driver.get("http://www.seleniumhq.org/");
		JavascriptExecutor jse = (JavascriptExecutor) driver ;
		jse.executeScript("history.go(0)");
		
		driver.get("http://toolsqa.com/");	
		new Actions(driver).keyDown(Keys.CONTROL).sendKeys(Keys.F5);
		
		driver.quit();
	}
}
