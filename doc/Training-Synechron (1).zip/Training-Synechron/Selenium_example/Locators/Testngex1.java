import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class Testngex1 {
	
	@BeforeSuite
	public void starttesting()
	{
		System.out.println("before start testing");
	}
	
	@BeforeClass
	public void testingclassleve()
	{
		System.out.println("before start class level");
	}
	
	@Test
	public void test1()
	{
		System.out.println("test1");
	}
	
	@Test
	public void test2()
	{
		System.out.println("test2");
	}
	
	@Test
	public void test3()
	{
		System.out.println("test3");
	}
	
	@AfterSuite
	public void closetesting()
	{
		System.out.println("End of testing");
	}
	
	@AfterClass
	public void testingendclassleve()
	{
		System.out.println("after class level");
	}

}
