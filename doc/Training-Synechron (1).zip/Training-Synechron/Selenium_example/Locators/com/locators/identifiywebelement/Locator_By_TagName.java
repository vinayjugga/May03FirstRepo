package com.locators.identifiywebelement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Locator_By_TagName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/chromedriver.exe");
		WebDriver driver = new ChromeDriver() ;		
		driver.get("https://www.google.co.in");
		System.out.println(driver.getCurrentUrl());		
		driver.findElement(By.tagName("lst-ib")).sendKeys("Vinay");		
		
		String linklist =driver.findElement(By.tagName("als")).getText();
		System.out.println(linklist);
		
		driver.close();
	}

}
