package com.locators.identifiywebelement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;

public class Locator_By_Id {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:/Users/vinay.l/workspace/Selenium_example/server/chromedriver.exe");
		WebDriver driver = new ChromeDriver() ;		
		driver.get("https://www.google.co.in");
		System.out.println(driver.getCurrentUrl());		
		WebElement webobj =driver.findElement(By.id("lst-ib")) ;
		webobj.sendKeys("Vinay");		
		
		String linklist =driver.findElement(By.id("als")).getText();
		System.out.println(linklist);
		
		//driver.close();
	}

}
