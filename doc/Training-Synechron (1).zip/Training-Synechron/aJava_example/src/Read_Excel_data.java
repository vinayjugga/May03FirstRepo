import java.io.FileInputStream;
import java.io.IOException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class Read_Excel_data {

	public static void main(String[] args) throws Exception, InvalidFormatException, IOException {
		
		String exclpath="C:/vinay/aJava_example/excelDataFiles/vinay_data.xlsx";
		FileInputStream filein= new FileInputStream(exclpath);
		Workbook wb = WorkbookFactory.create(filein);
		Sheet s1= wb.getSheet("Sheet1");
		String username =s1.getRow(1).getCell(0).getStringCellValue();
		System.out.println(username);
		
	}

}
