package com.syn.test;

public class Test1 {

	private int i =20;
	int j =30 ;
	public int k = 40 ;
	
	public Test1(int b){
		i =b ;
	}
	
	public void disply1()
	{
		System.out.println(i);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}	
	

}
