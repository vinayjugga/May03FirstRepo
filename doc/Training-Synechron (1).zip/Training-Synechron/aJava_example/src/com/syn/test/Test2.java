package com.syn.test;

public abstract class Test2 {

	
	public abstract void dispay();
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	}
	
	private class A2
	{
		
	}
	
	

}
