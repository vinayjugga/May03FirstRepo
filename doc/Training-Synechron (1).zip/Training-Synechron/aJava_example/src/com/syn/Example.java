package com.syn;

import com.syn.test.Test1;

public class Example {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test1 t1 = new Test1(10);
		t1.disply1();
System.out.println("vinay");
	}

}

class A {
	
}