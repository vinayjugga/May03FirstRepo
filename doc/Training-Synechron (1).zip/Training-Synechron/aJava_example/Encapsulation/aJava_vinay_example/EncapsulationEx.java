package aJava_vinay_example;

public class EncapsulationEx {

	private int ssn ;
	private String empName ;
	private int empAge ;
	
	public static void main(String[] args) {
		
		EncapsulationEx obj = new EncapsulationEx();
		obj.ssn = 12345 ;
		obj.empName ="vinay";
		obj.empAge = 35 ;		
		
		System.out.println("SSN=:"+obj.ssn);
		System.out.println("age=:"+obj.empAge);
		System.out.println("name=:"+obj.empName);
		
	}
	
}
