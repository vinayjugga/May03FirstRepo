package com.syn.uncheckedException;

public class demo_ExcpHandling {

	public static void main(String[] args) {

		int i1 = 8/0;
		
		System.out.println("Before Exception");
				
		try {
			int i = 8/0;
			//return;
		}
		catch(Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		finally {
			System.out.println("After Exception");	
		}
			
		System.out.println("Test12133...");
	}

}

