package com.syn.uncheckedException;

public class Multipletry {
	
	public void displaytrycatch()
	{
		try{
			int a = 10/0 ;
		}
		catch(Exception e)
		{
			
		}
	}
	
	public void displaytrycatch1()
	{
		try{
			int a = 10/0 ;
		}
		catch(Exception e)
		{
			try{
				int b = 100/0;
			}
			catch(Exception e1)
			{
				
			}
			
		}
	}
	
	public void displaytrycatch2() throws Exception 
	{
		int a=  10/ 0 ;
	}
	public static void displaytrycatch3() 
	{
		try{
			
		int a=  10/ 0 ;
		System.out.println("After Exception occured");
		}
		//System.out.println("After Exception occured");
		catch(Exception e)
		{
			try{
				//int b= 10/0 ;
						System.out.println("Catch block entered");
			e.printStackTrace();
			}
			finally
			{
				//System.exit(0);
				System.out.println("Inner finally block");
			}
		}
		finally
		{
			System.out.println("Finaly block exectcted");
		}
	}
	
	public static void displaytrycatch4() 
	{
		try{
		System.out.println("Finaly block not executed in this method.");
		int a=  10/ 0 ;
		System.out.println("After Exception occured");
		}
		catch(Exception e)
		{
			try{
				System.out.println("Catch block entered");
			e.printStackTrace();
			}
			finally
			{
				System.exit(0);
				System.out.println("Inner finally block");
			}
		}
		finally
		{
			System.out.println("Finaly block exectcted");
		}
	}
	

	public static void main(String[] args) {

		displaytrycatch3();
		displaytrycatch4();
		
	}

}
