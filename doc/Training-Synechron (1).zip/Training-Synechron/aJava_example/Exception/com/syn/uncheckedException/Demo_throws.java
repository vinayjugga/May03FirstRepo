package com.syn.uncheckedException;

public class Demo_throws {

	public static void main(String[] args) throws InterruptedException  {
		m2();
		System.out.println(":Main method");
	}
	
	public static void m2() throws InterruptedException  {
		 m3();
		//throw new Exception("");
		System.out.println("M2 method also thro exceptions");
	}
	
	public static void m3() throws InterruptedException {
		Thread.sleep(1000);
		System.out.println("M3 Thros exceptions");
		
	}
}
