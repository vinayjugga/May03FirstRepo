package com.syn.uncheckedException;

public class UncheckedExample1 {

	public static void main(String[] args) {
	
		int num1 = 0, num2 =50 ;

		try{
			
			num2 =  num2/ num1 ;
			
		
		}catch(Exception e) 
		{
			System.out.println("vinay");
			System.out.println("Unchecked exception throwed: Dont divide a number by zero" + num2 +"/" + num2);
			e.printStackTrace();
		}
		
		System.out.println("Example of uncheked exception");
	}
	
	

}
