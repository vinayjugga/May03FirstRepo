package com.syn.checkedException;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Example1 {
	
	public void display()
	{
		File f1 = new File("c:\tempt.txt");
		//Thread.sleep(1000);
	}

	public static void main(String[] args) {
		
		try {
			FileInputStream file1 = new FileInputStream("c:\temp.txt");
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		try {
			FileInputStream file = new FileInputStream("c:\temp.txt");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
	}

}
