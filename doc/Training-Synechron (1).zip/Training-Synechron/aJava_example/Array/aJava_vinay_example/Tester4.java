package aJava_vinay_example;

class W
{
	W()
	{
		System.out.println("Constructor executed 1");
	}
}
public class Tester4 {

	public static void main(String[] args) {
		
		W[] z1 = new W[2] ;
		z1[0] = new W();
		z1[1] =  new W() ;
		
		System.out.println(z1[0]);
	}

}
