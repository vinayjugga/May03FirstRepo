package aJava_vinay_example;

import java.util.Arrays;

public class Tester2 {
	
	static void test(int[] arr)
	{
		int temp =arr[0];
		arr[0]=arr[1];
		arr[1]=temp;
	}
	
	public String toString()
	{
		return "10 20";
	}

	public static void main(String[] args) {
		
		int[] num = new int[2];
		
		num[0]=10 ;
		num[1]=20; 
		
		char [] carr = new char[3] ;
		
		carr[0]='a';
		carr[1]='b' ;
		System.out.println(carr);
	
		for(int i: num)
			System.out.println(i);
		
		System.out.println("10 Position "+Arrays.binarySearch(num, 10));
		System.out.println("20 Position :"+Arrays.binarySearch(num, 20));
		test(num);
		
		System.out.println("Aftersawap");
		for(int i: num)
			System.out.println(i);
		System.out.println("10 Position "+Arrays.binarySearch(num, 10));
		System.out.println("20 Position :"+Arrays.binarySearch(num, 20));
		
	}

}
