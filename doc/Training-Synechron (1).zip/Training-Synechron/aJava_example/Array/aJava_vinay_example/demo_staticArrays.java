package aJava_vinay_example;

import java.util.Arrays;


public class demo_staticArrays {
	public static void main(String[] args) {
		int[] i = new int[3];
		int j[] = new int[3];
		int k[] = {12, 45, 2,4,6,8};		
		
		for(int y=0;y<k.length;y++)
			System.out.println(k[y]);
		
		System.out.println("Array Size: " + k.length);
		
		Arrays.sort(k);
		System.out.println("***************");
		for(int y=0;y<k.length;y++)
			System.out.println(k[y]);
}
}
