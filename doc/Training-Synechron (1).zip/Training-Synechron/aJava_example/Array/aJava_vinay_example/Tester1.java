package aJava_vinay_example;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Tester1 {

	public static void main(String[] args) {
		
		int[] intarr = new int[5];
		intarr[0] =15;
		intarr[1] =30;
		intarr[2] =23;
		intarr[3] = 33;
		intarr[4] =14;
		
		
		for(int i:intarr)
		System.out.println(i);
		System.out.println("Postion or index:="+Arrays.binarySearch(intarr, 23));
		
		Arrays.sort(intarr);
		System.out.println("After sorting");
		for(int i:intarr)
			System.out.println(i);
		
		/*int intarr1[] ={33,44,55,66,77,77} ;
		for(int i:intarr1)
			System.out.println(i);
		System.out.println(intarr1.length);	
		
		List<String> str1 = new ArrayList<String>() {"abc","vinay","sfdsf","amaan"} ;*/
		
	}

}
