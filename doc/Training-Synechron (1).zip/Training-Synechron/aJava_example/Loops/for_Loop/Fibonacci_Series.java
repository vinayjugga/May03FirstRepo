package for_Loop;

public class Fibonacci_Series {
	
	static int f1 =0 ;
	static int f2 =1 ;
	static int sum = 0 ;
	static int n = 10 ;
	
	public static void Fibnocci()
	{
		System.out.print(f1+"\t"+f2);
		if(n==1)
		{ 
			sum = n ;
		}
		else{ 
		for(int i=2; i<n ;i++)
		{		
			sum =f1+f2 ;
			System.out.print(sum +"\t");
			
			f1= f2 ;
			f2=sum ;
		}
		}
		
	}

	public static void main(String[] args) {
		
		Fibnocci();
		

	}

}
