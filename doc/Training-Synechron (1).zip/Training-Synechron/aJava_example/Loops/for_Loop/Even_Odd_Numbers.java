package for_Loop;

public class Even_Odd_Numbers {

	static int n = 50 ;
	public static void main(String[] args) {
		for(int i=1;i<=n ;i++)
		{
			if(i%2==0)
			{
				System.out.println("Even Numbers:=" +i);
			}
		}
		System.out.println("");
		for(int i=1;i<=n ;i++)
		{
			if(i%2!=0)
			{
				System.out.println("Odd Numbers:=" +i);
			}
		}

	}

}
