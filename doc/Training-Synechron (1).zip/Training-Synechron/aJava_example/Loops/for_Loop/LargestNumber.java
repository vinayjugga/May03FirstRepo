package for_Loop;

import java.util.Arrays;

public class LargestNumber {
	
	
	

	public static void main(String[] args) {
		int arr[] = { 3, 5, 10, 2, 4 ,15, 25, 30,100, 3,44,55} ;
		int largest = arr[0];
		Arrays.sort(arr);
		System.out.println(arr[arr.length-1]);
		
		/*for(int i=1 ;i <=arr.length-1; i++)
		{
			if(largest < arr[i])
				largest =arr[i];
			else
				continue ;
		}
		
		System.out.println(largest);*/
	}

}
