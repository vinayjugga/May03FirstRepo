package aJava_vinay_example;

public class Globalvariables {

	static int a ;
	
	public static void main(String[] args) {
		
		System.out.println(a);
		

	}

}
