package aJava_vinay_example;

public class Localvariable {

	static int a ;
	public static void main(String[] args) {
		int a ;
		System.out.println("done"+Localvariable.a);
		
 
	}

}
