package aJava_example;

public class FinalClassExample extends TestFinalClass{
	
	final public void display()
	{
		System.out.println("Venkay");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
