package aJava_example;

public abstract class FiftyEight58  {

	static String a1= "vinay" ;
	
	FiftyEight58()
	{
		
	}
	
	public void display()
	{
		System.out.println("Amman ");
	}
	
	public static void main(String[] args) {
			

	}

}
