package aJava_example;

public class Fiftyseven extends FiftyEight58{

	public void display1()
	{
		System.out.println("vinay");
	}
	
	public static void main(String[] args) {

		Fiftyseven fiftyseven = new Fiftyseven();
		fiftyseven.display();
		
			

	}

}
