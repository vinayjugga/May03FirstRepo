 package aJava_example;

/* Write a program to declare the Final value */

public class One1 {

	public final double PI =3.14 ;

	public void display(){
		System.out.println(PI);
	}
	
	public static void main(String[] args) {
		//System.out.println("Static Final value:="+PI);
		


	}




}
