package aJava_example;
/* What is the output, if the re-initialized the final variable */

public class Three3 {
	
	public static void main(String[] args) {
		final int a  ;
		//System.out.println("value of final variable a := "+ a);
		a =200 ;
		System.out.println("Rinitalze the final variable a:="+a);
	}

}
