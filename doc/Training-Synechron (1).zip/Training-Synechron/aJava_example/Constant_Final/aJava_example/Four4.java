package aJava_example;

/*what is output if the local final variable not initialized */
public class Four4 {
	

	public static void main(String[] args) {
		final int a ;
		a =90 ;
		System.out.println("Final varialbe initalized later value a:="+ a);
				
	}

	
}
