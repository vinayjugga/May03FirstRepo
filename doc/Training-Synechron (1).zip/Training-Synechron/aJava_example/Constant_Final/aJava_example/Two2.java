package aJava_example;
/* what is the output ,if the final global or class variable are not initialized */
public class Two2 {

	//static final double PI;
	
	
	public static void main(String[] args) {
		//PI=10.0;
		System.out.println("Vinay ");
		
		

	}

}
