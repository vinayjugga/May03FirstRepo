package aJava_example;

 public  class  TestFinalClass   {

	public void  display1()
	{
		System.out.println("vinay");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		FinalClassExample f1 = new FinalClassExample();
		f1.display();
		
		TestFinalClass f2 =  new FinalClassExample();
		f2.display1();
			
		Object c1 = new TestFinalClass();
		c1.getClass();
		
		
	}

}
