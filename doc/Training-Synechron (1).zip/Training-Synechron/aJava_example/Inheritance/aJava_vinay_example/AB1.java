package aJava_vinay_example;

public class AB1 extends AA1 {

	public void test2()
	{
		System.out.println("selenium");
	}
	
	public void test3()
	{
		System.out.println("java");
	}

	public void display()
	{
		super.display();
		System.out.println("akash");
	}
	
	public static void main(String[] args) {
		
		AB1 obj = new AB1();
		obj.display();
		
		AA1 a1 = new AB1() ; //Auto up casting
	 a1.display();
	 a1.test1();
		
		@SuppressWarnings("unused")
		AB1 b1 = (AB1)a1;
		
	

	}

}
