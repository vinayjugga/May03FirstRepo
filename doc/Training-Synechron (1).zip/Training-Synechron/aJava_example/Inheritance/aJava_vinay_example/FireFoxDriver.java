package aJava_vinay_example;

public class FireFoxDriver extends ParentClass1 implements WebDriver{

	public static void main(String[] args) {
		
		WebDriver driver = new FireFoxDriver();
		
	}

	public void close() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		
	}
	

	@Override
	public void getCurrentUrl() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getText() {
		// TODO Auto-generated method stub
		
	}

}
