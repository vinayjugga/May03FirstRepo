package aJava_vinay_example;

public interface WebDriver {
	
	public void close() ; // Abstract Methods
	
	public void display() ;
	
	public void getCurrentUrl() ;
	
	public void getText() ;
	
	

}
