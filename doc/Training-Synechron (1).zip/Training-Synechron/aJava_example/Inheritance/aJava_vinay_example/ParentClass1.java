package aJava_vinay_example;

public class ParentClass1 {
	
	public void display()
	{
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
