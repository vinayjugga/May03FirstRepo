package aJava_vinay_example;



public class Fifty51 extends Fifty50 {
	
	Fifty51(int b)
	{
		super(b);
		System.out.println("constuctor in 51 ");
	}
	
	
	
	public void test4() 
	{
		System.out.println("Test4 method");
	}

	
	public void test5() 
	{
		System.out.println("Test5 method");
	}

	public void test6() 
	{
		System.out.println("Test6 method");
	}


	public static void main(String[] args) {
		
		Fifty51 f1 = new Fifty51(20);
		f1.test1();
		
		
	}

}
