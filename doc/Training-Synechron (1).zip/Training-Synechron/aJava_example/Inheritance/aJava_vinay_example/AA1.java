package aJava_vinay_example;

public class AA1 /*extends Object*/ {
	
	
	int a ;	
	public void display()
	{	
		System.out.println("vinay");
	}
	
	public void test1()
	{	System.out.println("aman");
		System.out.println(a);
	}
	public static void main(String[] args) {
		//int a ;
		//System.out.println(a);
		// TODO Auto-generated method stub
		AA1 obj = new AA1();
		obj.display();
		obj.test1();
		
		
	}

}

//Data type - 
//a. Premitive - 8 types 
//b. Derived

//Variables - Declaration, initilization, utilization

//- Local variable : Declare inside the method. scope & life inside the method. Needs to be initialized
// Global variable - Static & non-Static this need not to be initialized, it takes default value. declared outside the method and inside the class
//call to this
//Class - members, variables (Static, non static)

