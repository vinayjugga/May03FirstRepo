package aJava_vinay_example;

public class AC1 extends AA1 {

	public static void main(String[] args) {
		
		AB1 b1 = new AB1() ;
		b1.display();
		b1.test1();
		b1.test2();
		b1.test3();

	}

}
