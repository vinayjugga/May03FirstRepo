package aJava_vinay_example;

import javax.jws.soap.SOAPBinding;

public class Fifty50 {
	
	/*Fifty50()
	{
		super();
	}*/
	
	Fifty50(int a)
	{
		this(10,20);
		System.out.println("Constuctor with parameter");
	}
	
	Fifty50(int a, int b)
	{
		System.out.println("Constuctor with parameter 50");
	}


	public void test1() 
	{
		System.out.println("Test1 method");
	}

	public void test2() 
	{
		System.out.println("Test3 method");
	}

	public void test3() 
	{
		System.out.println("Test3 method");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
