package com.inhertance.example;

public class Test {
	   public static void main(String args[]) {
	      Car b1 = new Car();
	      b1.color = "Blue";
	      b1.speed = 200 ;
	      b1.size = 22;
	      b1.CC = 1000;
	      b1.gears = 5;
	      b1.attributescar();
	   }
	}