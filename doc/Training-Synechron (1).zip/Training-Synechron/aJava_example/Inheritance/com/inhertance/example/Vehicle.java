package com.inhertance.example;

class Vehicle {
	
	   String color;
	   int speed;
	   int size;
	   
	   void attributes() {
	      System.out.println("Color : " + color);
	      System.out.println("Speed : " + speed);
	      System.out.println("Size : " + size);
	      
	   }
	}