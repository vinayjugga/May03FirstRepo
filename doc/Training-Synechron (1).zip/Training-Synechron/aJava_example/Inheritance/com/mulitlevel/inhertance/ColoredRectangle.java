package com.mulitlevel.inhertance;

//A subclass which extends for rectangle
class ColoredRectangle extends Rectangle {
	
	private String color;
	/* default Constructor*/
	
	ColoredRectangle() {
		super();
		color = null;
		System.out.println("Inside default constructor of coloredRectangle");
	}

	// Parameterized Constructor
	ColoredRectangle(String c, String ty, int len, int bdth) {
		super (ty, len, bdth);
		System.out.println("Inside constructor of coloredRectangle ");
		System.out.println("length : " + len);
		System.out.println("breadth : " + bdth);
		System.out.println("type : " + ty);
	}
	
	public String getColor() {
		return color;
	}
	
	public void setColor(String string) {
		color = string;
	}
}