package com.mulitlevel.inhertance;

//A subclass which extends for shape

class Rectangle extends Shape {
	private String type;

	// default Constructor
	Rectangle() {
		super();
		type = null;
		System.out.println("Inside default constructor of rectangle ");
	}

	// Parameterized Constructor
	Rectangle(String ty, int len, int bdth) {
		super (len, bdth);
		System.out.println("Inside constructor of rectangle ");
		System.out.println("length : " + len);
		System.out.println("breadth : " + bdth);
		System.out.println("type : " + type);
	}

	public String getType() {
		return type;
	}

	public void setType(String string) {
		type = string;
	}
}
