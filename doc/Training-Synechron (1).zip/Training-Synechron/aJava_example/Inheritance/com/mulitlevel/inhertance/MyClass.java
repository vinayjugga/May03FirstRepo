package com.mulitlevel.inhertance;

class A
{
  public void methodA()
  {
     System.out.println("method of Class A");
  }
}
class B extends A
{
  public void methodB()
  {
     System.out.println("method of Class B");
  }
}
class C extends B
{
 public void methodC()
 {
 System.out.println("method of Class C");
 }
}
class D extends C
{
  public void methodD()
  {
     System.out.println("method of Class D");
  }
}

class MyClass
{
  public void methodB()
  {
     System.out.println("method of Class B");
  }
  public static void main(String args[])
  {
     B obj1 = new B();
     
     obj1.methodA(); 
     obj1.methodB();
     
     System.out.println();
     C obj2 = new C();
     
     obj2.methodA(); 
     obj2.methodB();
     obj2.methodC();
     
     System.out.println();
     
     D obj3 = new D();
     obj1.methodA();
     obj2.methodA();
     obj3.methodA();
  }
}