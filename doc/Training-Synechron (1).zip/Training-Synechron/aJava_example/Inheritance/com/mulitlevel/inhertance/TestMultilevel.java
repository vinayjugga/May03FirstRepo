package com.mulitlevel.inhertance;

public class TestMultilevel {
	
	public static void main(String args[]) {
		
		ColoredRectangle CR = new ColoredRectangle();
		ColoredRectangle CR2 = new ColoredRectangle("Red","Big", 5, 2 );
		
	}
}