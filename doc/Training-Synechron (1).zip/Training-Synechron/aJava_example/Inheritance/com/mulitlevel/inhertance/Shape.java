package com.mulitlevel.inhertance;

class Shape {
	   private int length;
	   private int breadth;
	   public int getBreadth() {
	      return breadth;
	   }
	   public int getLength() {
	      return length;
	   }
	   public void setBreadth(int i) {
	      breadth = i;
	   }
	   public void setLength(int i) {
	      length = i;
	   }
	   // default Constructor
	   Shape() {
	      length = 0;
	      breadth = 0;
	      System.out.println("Inside default constructor of Shape ");
	   }

	   // Parameterized Constructor
	   Shape(int len, int bdth) {
	       length = len;
	       breadth = bdth;
	       System.out.println("Inside constructor of Shape ");
	       System.out.println("length : " + length);
	       System.out.println("breadth : " + breadth);
	    }
	}