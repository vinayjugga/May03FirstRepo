package aJava_vinay_example;

import java.util.ArrayList;
import java.util.List;

public class FindDuplicateNumber {

	
	
	public static int addSum(List<Integer> n)
	{
		int sum=0;
		for(int n1:n)
		{
			 sum += n1 ;
		}
				
		return sum ;
	}
	
	public static void duplicatenumber(List<Integer> num)
	{
		int lastnumber = num.size()-1;
		
		int total = addSum(num);
		System.out.println("total="+total);
		int duplcate = total - (lastnumber*(lastnumber+1)/2 );
		System.out.println(duplcate);
	}
	
	public static void main(String[] args) {
		
		List<Integer> listnumbers = new ArrayList<Integer>();
		
		for(int i=1 ;i<6 ;i++)
		{
			listnumbers.add(i);
		}
		System.out.println(listnumbers);
		listnumbers.add(21);
		System.out.println(listnumbers);
		duplicatenumber(listnumbers);		
		
	}

}
