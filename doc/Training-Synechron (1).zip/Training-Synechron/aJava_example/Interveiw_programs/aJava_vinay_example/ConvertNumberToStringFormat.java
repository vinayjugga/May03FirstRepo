package aJava_vinay_example;

public class ConvertNumberToStringFormat {


	public static String getnumberconvertoString(int n)
	{
		String onetoTen =null; 
		String elevenToTwenlty =null;
		String twelntyToNintynine =null;
		String result = " " ;

		while(n>0) 
		{
			if(n<=10 && n>0)
			{
				switch(n)
				{
				case 1: 
					onetoTen= "one";
					n=0;
					break;
				case 2:
					onetoTen = "Two";
					n=0;
					break;	
				case 3: 
					onetoTen= "Three";
					n=0;
					break;
				case 4:
					onetoTen = "Four";
					n=0;
					break;	
				case 5: 
					onetoTen= "Five";
					n=0;
					break;
				case 6:
					onetoTen = "Six";
					n=0;
					break;	
				case 7:
					onetoTen = "Seven";
					n=0;
					break;
				case 8:
					onetoTen = "Eight";
					n=0;
					break;
				case 9:
					onetoTen = "Nine";
					n=0;
					break;
				case 10:
					onetoTen = "Ten";
					n=0;
					break;
				default :
					break;
				}
				result=result.concat(onetoTen);				
			}
			else if(n>10 && n <20)
			{
				switch(n)		
				{
				case 11: 
					elevenToTwenlty= "Eleven";
					n=0;
					break;
				case 12: 
					elevenToTwenlty= "Tweleve";
					n=0;
					break;
				case 13: 
					elevenToTwenlty= "Thirteen";
					n=0;
					break;
				case 14: 
					elevenToTwenlty= "Fourteen";
					n=0;
					break;
				case 15: 
					elevenToTwenlty= "Fifteen";
					n=0;
					break;
				case 16: 
					elevenToTwenlty= "Sixteen";
					n=0;
					break;
				case 17: 
					elevenToTwenlty= "Seventeen";
					n=0;
					break;
				case 18: 
					elevenToTwenlty= "Eightteen";
					n=0;
					break;
				case 19: 
					elevenToTwenlty= "Nineteen";
					n=0;
					break;
				case 20: 
					elevenToTwenlty= "Twenty";
					n=0;
					break;
				default :
					break ;
				}
				result=result.concat(elevenToTwenlty);
			}
			else if(n>20 && n <=99)
			{
				int rem =n%10 ;
				n = n/10 ;	

				switch(n)		
				{
				case 2: 
					twelntyToNintynine= "Twenty";
					break;
				case 3: 
					twelntyToNintynine= "Thrity";
					break;
				case 4: 
					twelntyToNintynine= "Fourty";
					break;
				case 5: 
					twelntyToNintynine= "Fifty";
					break;
				case 6: 
					twelntyToNintynine= "Sixty";
					break;
				case 7: 
					twelntyToNintynine= "Seventy";
					break;
				case 8: 
					twelntyToNintynine= "Eighty";
					break;
				case 9: 
					twelntyToNintynine= "Ninety";
					break;
				default:
					break;

				}
				n=rem ;
				result=result.concat(twelntyToNintynine);
			}			
		
		}	
		return result ;
	}

	public static void main(String[] args) {

		String converted =getnumberconvertoString(49);
		System.out.println("Converted Number to String Format:="+converted);

	}

}
