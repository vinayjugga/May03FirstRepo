package aJava_vinay_example;

public class AA {

}
