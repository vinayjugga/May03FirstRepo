package aJava_vinay_example;

public class ReverseString {
	
	public static void reverseString(String str)
	{
		
		for(int i = str.length()-1; i >=0; i--)
		{
			System.out.print(str.charAt(i));
		}
		
		System.out.println(" Revesed String of :"+ str);
	}

	public static void main(String[] args) {
		reverseString("vinay");

	}

}
