package aJava_vinay_example;

public class RevereseWord {

	public static void reverseWord(String sentence)
	{
		System.out.println("Actual String:"+ sentence);
		String[] strlist =sentence.split(" ");
		for(String listone : strlist)
		{
			String s1 =listone;
			//System.out.print(s1);
			for(int i =s1.length()-1; i>=0;i--)
			{
				System.out.print(s1.charAt(i));
				
			}
			System.out.print(" ");
			
		}
	}
	
	public static void main(String[] args) {
		
		reverseWord("Hi Vinay How Are You");
		
	}

}
