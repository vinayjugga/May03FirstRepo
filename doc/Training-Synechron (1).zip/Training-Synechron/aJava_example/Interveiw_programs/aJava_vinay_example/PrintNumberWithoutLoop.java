package aJava_vinay_example;

public class PrintNumberWithoutLoop {
	
	public static void printTen(int n)
	{
		if(n<=100){
		System.out.println(n);
		printTen(n+1);
		}
	}

	public static void main(String[] args) {
		printTen(1);

	}

}
