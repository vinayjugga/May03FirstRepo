package aJava_vinay_example;

public class Reference {

	static int test1(int a) //int a = 10;
	{
		System.out.println(a);
		return 0;
	}
	static double test2(double a)
	{
		System.out.println(a);
		return 1;
	}
	static String test3(String str)
	{
		System.out.println(str);
		return "";
	}
	
	static AA test4(Reference s1) 
	{
		System.out.println(s1);
		return new AA();
	}
	
	static void test5(Reference s1, Reference s2) 
	{
		System.out.println(s1);
	}
	
	
	public static void main(String[] args) {
				
		test1(10);
		test2(10.2);
		test3("vinay");
		test4(new Reference());
		Reference r1 = new Reference();
		Reference r2 = new Reference();
		test5(r1, r2);
		test5(new Reference(), new Reference());
		
	}

}
