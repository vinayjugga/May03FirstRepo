package aJava_vinay_example;

public class FibonacciSeries {

	static int frist =0 ;
	static int second =1 ;
	static int sum = 0 ;
	
	
	public static void fibnoacci(int number)
	{
		if(number==1)
		System.out.print(number);
		
		System.out.print(frist +"\t"+ second +"\t");
		for(int i= 2 ; i < number ; i++)
		{
			sum = frist + second ;
			System.out.print(sum +"\t");
			frist = second ;
			second = sum ;
		}
	}
	public static void main(String[] args) {
		fibnoacci(10);

	}

}
