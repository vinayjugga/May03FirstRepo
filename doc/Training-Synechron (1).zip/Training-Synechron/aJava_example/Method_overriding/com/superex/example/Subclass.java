package com.superex.example;

class Subclass extends Parentclass
{
   int num=110;
   void printNumber(){
      //Super.variable_name
      System.out.println(super.num);
   }
   
   public static void main(String args[]){ 
      Subclass obj= new Subclass();
      obj.printNumber();	
   }
}
