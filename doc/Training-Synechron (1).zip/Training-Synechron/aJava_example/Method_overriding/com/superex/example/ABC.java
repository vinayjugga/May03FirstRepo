package com.superex.example;

class ABC{
	   public void mymethod()
	   {
	       System.out.println("Class ABC: mymethod()");
	   }	   
	}
