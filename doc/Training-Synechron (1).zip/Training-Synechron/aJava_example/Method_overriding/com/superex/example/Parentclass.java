package com.superex.example;

public class Parentclass
{
   int num=100;
}