package com.superex.example;

class Test extends ABC{
	
	   public void mymethod(){
	      //This will call the mymethod() of parent class
	      super.mymethod();
	      System.out.println("Class Test: mymethod()");
	   }
	   
	   public static void main( String args[]) {
	      Test obj = new Test();
	      obj.mymethod();
	   }
	}
