package com.inheritance.overriding;

class ABC{
	   public void disp(int a)
	   {
	      System.out.println("disp() method of parent class");
	   }
	   public void abc()
	   {
	      System.out.println("abc() method of parent class");
	   }	   
	}