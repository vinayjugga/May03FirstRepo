package com.inheritance.overriding;

class Test1 extends ABC{
	
	
	   public void disp(int a){
	      System.out.println("disp() method of Child class");
	   }
	   
	   public void xyz(){
	      System.out.println("xyz() method of Child class");
	   }
	   
	   public static void main( String args[]) {
	      //Parent class reference to child class object
		  ABC obj = new ABC() ;
		   obj.disp(22);
		   
		   Test1 obj1 = new Test1();
		   obj1.disp(10);
		   obj1.disp(30);		   
		   
	      ABC obj2 = new Test1();
	      obj2.disp(10);
	      
	      Test1 obj3 =(Test1)obj2;
	      
	      obj3.xyz();
	      obj3.disp(33);
	      obj3.disp(30);
	      
	      
	   }
	}
