package com.inheritance.overriding;

class Human{
	   public void eat()
	   {
	      System.out.println("Human is eating");
	   }
	}