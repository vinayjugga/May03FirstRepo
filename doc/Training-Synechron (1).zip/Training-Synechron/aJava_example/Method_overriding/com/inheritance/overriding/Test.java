package com.inheritance.overriding;

public class Test {
	   public static void main(String args[]) {
		   System.out.println("Oveririding Example ");
		   
	       Shape obj1 = new Shape();
	       obj1.showattributes();
		   
	       System.out.println("Created Child object");
	       System.out.println();
	       
	       Rectangle rect = new Rectangle("Blue",5,7);
	       // showattributes() in rectangle is called
	       rect.showattributes(); 
	       
	       System.out.println();
	       Shape obj = new Rectangle("Red",5,7);
	       obj.showattributes();
	   }
	}