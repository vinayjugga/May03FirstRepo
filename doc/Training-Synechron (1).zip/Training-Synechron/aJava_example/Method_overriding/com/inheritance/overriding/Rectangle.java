package com.inheritance.overriding;

//A subclass which extends for shape
class Rectangle extends Shape {
	
	private String type;
	/* default Constructor
	 */
	Rectangle() {
		type = null;
	}
	
	// Parameterized Constructor
	Rectangle(String ty, int len, int bdth) {
		super(len,bdth);
		type = ty;
	}
	
	
	void showattributes() {
		// showattributes() of class Shape is called
		//super.showattributes(); 
		System.out.println("type : " + type);
		System.out.println("Rectangle showattributes");
	}
	
}