package com.inheritance.overriding;

class Shape {

	private int length;
	private int breadth;

	// default Constructor
	Shape() {
		length = 0;
		breadth = 0;
	}

	// Parameterized Constructor
	Shape(int len, int bdth) {
		length = len;
		breadth = bdth;
	}


	void showattributes() {
		System.out.println("length : " + length);
		System.out.println("breadth : " + breadth);
		System.out.println("Shape showattributes");
	} 

}
