package aJava_vinay_example;

public class OneExample1 {
	
	public void display()
	{
		System.out.println("Vinay");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
