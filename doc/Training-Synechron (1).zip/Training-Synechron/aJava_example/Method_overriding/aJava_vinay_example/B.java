package aJava_vinay_example;

public class B extends A{

	

}
