package aJava_vinay_example;

public class A {

	public void display()
	{
		System.out.println("venky");
	}
	public static void main(String[] args) {
		

	}

}
