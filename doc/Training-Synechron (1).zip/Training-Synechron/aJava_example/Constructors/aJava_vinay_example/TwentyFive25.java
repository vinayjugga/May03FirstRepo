package aJava_vinay_example;
/* what is the output of the constructor example */
public class TwentyFive25 {

	int vinayId ;
	
	public TwentyFive25(int vinayId) {
		System.out.println("Construtor Exeucted ");
		this.vinayId = vinayId ;
	}
	public static void main(String[] args) {
		System.out.println("Example of the Constructor ");
		TwentyFive25 twentyFive25Obj = new TwentyFive25(50) ;
		//TwentyFive25 twentyFive25Obj1 = new TwentyFive25() ;
		System.out.println("Default Value of Interger vinayId:= "+twentyFive25Obj.vinayId);

	}

}
