package aJava_vinay_example;

public class Construct1 /*extends Object*/{

	int a ;
	int b ;
	Construct1()
	{
				
	}	
	Construct1(int a)
	{
		
		this.a = 10;
		b= 20 ;
		
	}	

}
