package aJava_vinay_example;
/* what is the output of Method name same as the class name */
public class TwentlyFour24 {
	public TwentlyFour24()
	{
		System.out.println("constructor");
	}
	
	void TwentlyFour24()
	{
		System.out.println("Method created as constrcutor name");
	}
	public static void main(String[] args) {
		System.out.println("Example of same name of class as the method name ");
		TwentlyFour24 twentlyFour24Obj = new TwentlyFour24();		
		twentlyFour24Obj.TwentlyFour24();
	}

}
