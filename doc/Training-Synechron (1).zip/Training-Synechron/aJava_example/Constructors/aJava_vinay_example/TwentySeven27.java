package aJava_vinay_example;
/*what is the output of the program */
public class TwentySeven27 {
	
	int vinayId ;
	
	public TwentySeven27() {
		
		System.out.println("Constuctor Exeucted 1");
		vinayId =12345;
	}

	public static void main(String[] args) {
		
		System.out.println("Example of constructor with initalizd the value: ");
		TwentySeven27 twentySeven27Obj = new TwentySeven27();
		System.out.println("Value of VinayId:= "+twentySeven27Obj.vinayId);
		twentySeven27Obj.vinayId =1000;
		System.out.println("Value of VinayId:= "+twentySeven27Obj.vinayId);
		TwentySeven27 twentySeven27Obj2 = new TwentySeven27();
		System.out.println("value of VinayId:= "+twentySeven27Obj2.vinayId);
		System.out.println("Value of VinayId:= "+twentySeven27Obj.vinayId);
	}

}
