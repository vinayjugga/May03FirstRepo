package aJava_vinay_example;
/* what is the output of the program */
public class TwentyNine29 {
	
	int vinayId ;

	TwentyNine29(int id)
	{
		vinayId =id ;
	}
	public static void main(String[] args) {
		
		System.out.println("Example of using Default constuctor ");
		/*TwentyNine29 twentyNine29Obj = new TwentyNine29();
		System.out.println("value of vinayID:=" +twentyNine29Obj.vinayId);*/
	}

}
