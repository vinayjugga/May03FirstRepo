package aJava_vinay_example;
/* write a program to initialize the global variable in the constructor */
public class TwentyEight28 {

	final int vinayId ;
	TwentyEight28(int a)
	{
		vinayId =a ;
		
	}
	public static void main(String[] args) {
		System.out.println("Example of Constructor intialzed the globle variable");
		TwentyEight28 twentyEight28Obj = new TwentyEight28(1000);
		System.out.println("Initalzed the global variable vinayId :="+twentyEight28Obj.vinayId);
		//twentyEight28Obj.vinayId=2000;
		System.out.println("Initalzed the global variable vinayId :="+twentyEight28Obj.vinayId);
		TwentyEight28 twentyEight28Obj1 = new TwentyEight28(3000);
		System.out.println("Initalzed the global variable vinayId :="+twentyEight28Obj1.vinayId);
		TwentyEight28 twentyEight28Obj3 = new TwentyEight28(5000);
		System.out.println("Initalzed the global variable vinayId :="+twentyEight28Obj3.vinayId);
	}

}
