package aJava_vinay_example;

class Human 
{
	String s1, s2 ;
	
	public Human()
	{
		s1="Super class";
		s2 ="Parent class";
	}
	
	public Human(String str)
	{
		s1 =str ;
		s2 = str;
	}
}

public class Boy extends Human {
	
	public Boy()
	{
		s2 = "Child class";
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
