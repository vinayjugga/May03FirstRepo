package aJava_vinay_example;

public class Constructor2 extends Construct1{

	Constructor2()
	{
		super(100);
	}
	
	Constructor2(int a, String s1, int b)
	{
		a = 30 ;
		
	}
	
	public static void main(String[] args) {
	
		Constructor2 c2 = new Constructor2();
		System.out.println(c2.a);

	}

}
