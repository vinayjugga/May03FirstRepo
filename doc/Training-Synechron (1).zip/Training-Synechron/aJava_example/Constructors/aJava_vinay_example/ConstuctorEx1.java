package aJava_vinay_example;

public class ConstuctorEx1 {
	

	public void displayMethod()
	{
		System.out.println("Vinay");
	}
	public static void main(String[] args) {
		System.out.println("Example of Without initialize a constructor");
		ConstuctorEx1 constuctorEx1Obj = new ConstuctorEx1();
		constuctorEx1Obj.displayMethod();

	}

}
