package aJava_vinay_example;
/* write a program to initialize the values using the constructor */
public class ThirtySeven37 {
	
	int length ;
	int breadth ;
	int hight ;

	ThirtySeven37(int l, int b, int h)
	{
		length =l ;
		breadth = b ;
		hight = h ;	
		
	}
	
	void volume()
	{
		int volume = length * breadth * hight ;
		System.out.println("Volume of the Box := "+volume);
	}	
	
	public static void main(String[] args) {
	System.out.println("Exmple of initalize the values in the constructor ");
	
	ThirtySeven37 thirtySeven37Obj = new ThirtySeven37(10, 20, 30) ;
	//thirtySeven37Obj.volume();
	
	ThirtySeven37 thirtySeven37Obj1 = new ThirtySeven37(5, 6, 7) ;
	thirtySeven37Obj1.volume();
	
	}

}
