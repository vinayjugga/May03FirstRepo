package aJava_vinay_example;

import java.awt.DisplayMode;

public class A123 {
	
	public void display()
	{
		System.out.println("selenium");
	}

	public static void main(String[] args) {
		
		A12 a12 = new A12();
		a12.display();
		
		A13 a13 = new A13();
		a13.display();
		
		A12 fourityOne41 = new A12();
		fourityOne41.display();

	}

}
class A12 {
	
	void display()
	{
		System.out.println("vinay");
	}
}

class A13 {
	
	void display()
	{
		System.out.println("Aman");
	}
}