package aJava_vinay_example;
/* what is the output of the Constructor Initialized variable  */
public class TwentySix26 {
	int vinayId;

	public TwentySix26() {
		System.out.println("Constuctor Executed");
		vinayId =20 ;
		System.out.println("This will be printed or not ?");
	}
	public static void main(String[] args) {
		System.out.println("Example of Intialzed the varable in the constructor");
		TwentySix26 twentySix26Obj = new TwentySix26();
		System.out.println("Value of VinayId after intialized : ="+twentySix26Obj.vinayId);

	}

}
