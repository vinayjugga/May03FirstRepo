package aJava_vinay_example;
/* Example of Default constructor */
public class TwentyThree23 {

	/*public TwentyThree23() {
		// TODO Auto-generated constructor stub
	}*/
	public static void main(String[] args) {
		System.out.println("Example of Default constructor ");
		TwentyThree23 twentyThree23Obj = new TwentyThree23();
		System.out.println("Compiler will create the Default constructor in compilation time ");
		
	}

}
