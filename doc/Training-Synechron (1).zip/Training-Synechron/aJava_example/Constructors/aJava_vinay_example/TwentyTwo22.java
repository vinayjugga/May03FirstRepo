package aJava_vinay_example;
/* what is output of Constructor example */
public class TwentyTwo22 {

	TwentyTwo22() 
	{
		System.out.println("Constructor 1");
	}
	
	public static void main(String[] args) {
	System.out.println("Example of Constructor without argument");
	System.out.println("Constructor 1");
	TwentyTwo22 twentyTwo22Obj = new TwentyTwo22();
	
	}

}
