package aJava_vinay_example;
/* "this" is keyword 
 * this is default reference variable in java, it will be always pointing to current object.  
 * this keyword is used to access current instance members or current object members.
 * if the local and global variable  names are same.
 * in case of non-static then we can use this to differentiated   the global variable from local variable .
 * this key word can be used in the all the non-static context .
 * this key word can not be used in the static context. 
 */
public class ThirtyEight38 {
	
	int length ;
	int breadth ;
	int hight ;
	ThirtyEight38()
	{
		
	}
	ThirtyEight38( int l1, int b1, int h1)
	{
		length = l1 ;
		breadth = b1 ;
		hight = h1 ;
	}
	
	
	void volume()
	{
		int volume = length * breadth *hight ;
		System.out.println("volume :="+volume);
	}
	
	public static void main(String[] args) {
		System.out.println("Example of using this key word ");
		ThirtyEight38 thirtyEight38Obj = new ThirtyEight38(3,4,5);
/*		thirtyEight38Obj.length=3 ;
		thirtyEight38Obj.breadth= 5;
		thirtyEight38Obj.hight=5 ;
		*/
		thirtyEight38Obj.volume();
		ThirtyEight38 thirtyEight38Obj1 = new ThirtyEight38(20, 30, 40);
		thirtyEight38Obj1.volume();
		
	}

}
