package aJava_vinay_example;

public class ConstructorEx2 {

	private int var ;
	public ConstructorEx2() {
		var =10 ;
	}
	public ConstructorEx2(int num)
	{
		var = num ;
	}
	
	public int getValue()
	{
		return var ;
	}
	
	public static void main(String[] args) {
		System.out.println("Example of Constructor: No-arg and with Arg constuctor");
		
		ConstructorEx2 constructorEx2Obj = new ConstructorEx2();
		System.out.println("Value of var :="+constructorEx2Obj.getValue());
		ConstructorEx2 constructorEx2Obj1 = new ConstructorEx2(100);
		System.out.println("Value of var :="+constructorEx2Obj1.getValue());

	}

}
