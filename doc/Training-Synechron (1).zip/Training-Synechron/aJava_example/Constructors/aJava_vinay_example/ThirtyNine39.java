package aJava_vinay_example;
/* write a program initalize the variable without using the constructor */

public class ThirtyNine39 {
	
	int vinayId;
	
	void init(int vinayId)
	{
		this.vinayId = vinayId;
	}

	public static void main(String[] args) {
		System.out.println("Example of initialze the variable without using the constructor");
		ThirtyNine39 thirtyNine39Obj = new ThirtyNine39();
		thirtyNine39Obj.init(20);
		System.out.println("value of vinayId:="+thirtyNine39Obj.vinayId);

	}

}
