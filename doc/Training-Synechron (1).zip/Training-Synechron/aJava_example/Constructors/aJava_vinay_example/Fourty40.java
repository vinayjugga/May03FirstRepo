package aJava_vinay_example;

public class Fourty40 {
	
	int modelno ;
	String modelName ;
	double costmobile ;
	
	Fourty40(int modelno, String modelName, double costmobile)
	{
		this.modelno =modelno ;
		this.costmobile=costmobile;
		this.modelName = modelName;
		display();
	}
	
	void display()
	{
		System.out.println("Modleno:="+modelno +"Modlename:="+modelName+ "MobileCost:="+costmobile);
	}

	public static void main(String[] args) {
		
		Fourty40 fourty40 = new Fourty40(920, "Nokia Lumia" , 20000);
		//fourty40.display();

	}

}
