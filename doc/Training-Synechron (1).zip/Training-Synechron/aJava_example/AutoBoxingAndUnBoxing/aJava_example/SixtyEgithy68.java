package aJava_example;

public class SixtyEgithy68 {

	public static void main(String[] args) {
		
		int a = 10 ;
		
		
		int a1 =(int)20.4 ;
		
		double d1 =100 ;
		
		

	}

	
}

	

