package aJava_example;

public class SixtySix66 {
	
	static void test(int a, double d)
	{
		System.out.println("a="+a+"d="+d);
	}
	
	static void test(double d, int a)
	{
		System.out.println("a="+a+"d="+d);
	}

	public static void main(String[] args) {
		
		test(10.0,100);

	}

}
