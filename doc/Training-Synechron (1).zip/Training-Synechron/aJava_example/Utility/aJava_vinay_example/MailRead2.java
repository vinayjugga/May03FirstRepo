package aJava_vinay_example;

import java.util.Properties;

import javax.mail.BodyPart;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Store;

public class MailRead2 {

	public static void readmailSearchSubject(String hostaddress,final String loginMail, final String loginPassword,String searchsubject)
	{

		try{

			Properties prop = new Properties();

			prop.put("mail.pop3.host", hostaddress);
			prop.put("mail.pop3.port", "995");
			prop.put("mail.pop3.starttls.enable", "true");

			Session emailsession = Session.getInstance(prop);

			Store store = emailsession.getStore("pop3s");
			store.connect(hostaddress, loginMail, loginPassword);

			Folder emailfloder = store.getFolder("INBOX");
			emailfloder.open(Folder.READ_ONLY);

			Message[] messages = emailfloder.getMessages();
			System.out.println("message lenth:="+messages.length);

			for(int i=0;i< messages.length; i++)
			{
				Message message =messages[i];

				if(message.getSubject().contains(searchsubject)){
					System.out.println("Mail inbox numbers:= "+(i+1));
					System.out.println("Subject:= "+message.getSubject());
					System.out.println("From:= "+message.getFrom()[0]);		
					Object content = message.getContent();
					String contentReturn = null;

					Multipart multipart = (Multipart) content;
					BodyPart part = multipart.getBodyPart(0);
					part.toString();
					contentReturn = part.getContent().toString();
					System.out.println(contentReturn);
				}		

			}

			emailfloder.close(false);
			store.close();

		}
		catch(Exception e){
			e.printStackTrace();
		}

	}
}
