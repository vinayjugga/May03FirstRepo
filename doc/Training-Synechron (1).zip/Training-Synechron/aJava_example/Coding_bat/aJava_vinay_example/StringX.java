package aJava_vinay_example;

/*Given a string, return a version where all the "x" have been removed. Except an "x" at the very start or end should not be removed.

stringX("xxHxix") → "xHix"
stringX("abxxxcd") → "abcd"
stringX("xabxxxcdx") → "xabcdx"*/

public class StringX {
	static String res="";
	public static String stringX(String str) {
		 
		String res="";
		  String start="";
		  String end="";
		  if(str.length()<=2 && str.length()>0)
		  {
		    if(str.length()==1 && str.charAt(0)=='x')
		     return "x";
		     
		    else if(str.charAt(0)=='x' && str.charAt(str.length()-1)=='x')
		    start="x";
		  }
		  else
		  {
		  for(int i=0;i<=str.length()-1;i++)
				  {
				    if((str.charAt(i)=='x'))
				    	continue;
				    else if(str.charAt(0)=='x' && str.charAt(str.length()-1)=='x')
				     start="x";
				  res=res+str.charAt(i);
				  }
		  }
				  return start+res+start;
		  
		  
		}
	
	public static String removex(String str)
	{
		String result = "";
		  for (int i=0; i<str.length(); i++) {
		    // Only append the char if it is not the "x" case
		    if (!(i > 0 && i < (str.length()-1) && str.substring(i, i+1).equals("x"))) {
		      result = result + str.substring(i, i+1); // Could use str.charAt(i) here
		    }
		  }
		  return result;
	}
	
	public static void main(String[] args) {
		System.out.println(stringX("xHexlxlox"));
		System.out.println(stringX("Hexlxlo"));
		System.out.println(stringX("xHexxxxxxxxxxlxlox"));

	}

}
