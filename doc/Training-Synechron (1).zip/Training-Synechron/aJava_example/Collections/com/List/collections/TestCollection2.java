package com.List.collections;

import java.util.*;  

class TestCollection2{  
	
	public static void main(String args[]){  
		
		ArrayList<String> al=new ArrayList<String>();  
		
		al.add("Ravi");  
		al.add("Vijay");  
		al.add("Ravi");  
		al.add("Ajay"); 
		
		for(int i=0;i <al.size(); i++){
			System.out.println(al.get(i));  
		}
		
		for(String obj:al)  
			System.out.println(obj);  
		
	}  
}  
