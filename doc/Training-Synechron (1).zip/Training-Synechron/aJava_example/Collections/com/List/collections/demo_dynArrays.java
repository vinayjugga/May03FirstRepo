package com.List.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class demo_dynArrays {
	
	public static void main(String[] args) {
		
		List<String> arr = new ArrayList<String>();
		arr.add("N1");
		arr.add("N2");

		System.out.println(arr.size());		
		System.out.println(arr.get(1));

		arr.add("abc");
		arr.add("xyz");

		System.out.println("********After Increase*************");
		System.out.println(arr.size());	
		System.out.println(arr.get(2));


		arr.remove(1);
		System.out.println("********After Decrease*************");
		System.out.println(arr.size());	
		System.out.println(arr.get(1));

		Collections.sort(arr);
		System.out.println("********After Sort*************");
		System.out.println(arr);

		Iterator<String> itr = arr.iterator();
		System.out.println( itr.next() );
		System.out.println( itr.next() );
		System.out.println( itr.next() );

		//ctrl + shift + o

	}

}
