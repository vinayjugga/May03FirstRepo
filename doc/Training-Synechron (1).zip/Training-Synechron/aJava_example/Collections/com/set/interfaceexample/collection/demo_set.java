package com.set.interfaceexample.collection;

import java.util.HashSet;
import java.util.Hashtable;
import java.util.Set;


public class demo_set {

	public static void main(String[] args) {
		
		Set<String> arr = new HashSet<String>();
		arr.add("N1");
		arr.add("N2");
		arr.add("N3");		
		
		System.out.println(arr.size());	
		
		
		Hashtable<String, String> ht = new Hashtable<String, String>();
		ht.put("Veg", "Potato");
		ht.put("Non-Veg", "Chick");
		ht.put("Fruit", "Mango");
		
		System.out.println(ht.get("Fruit"));
		
		

	}
}
