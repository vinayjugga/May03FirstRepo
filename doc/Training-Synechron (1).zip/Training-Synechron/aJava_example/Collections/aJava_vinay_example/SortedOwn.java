package aJava_vinay_example;

import java.util.ArrayList;
import java.util.Collections;

public class SortedOwn implements Comparable<SortedOwn>{
	
	int EmplyeID;
	String EmpName;
	int age ;
	
	SortedOwn(int EmpyeID, String EmpName, int age)
	{
		this.EmplyeID = EmpyeID;
		this.EmpName = EmpName;
		this.age = age ;
	}
	
	/*public int compareTo(SortedOwn obj)
	{
		if(age==obj.age)
			return 0 ;
		else if(age >obj.age)
			return 1;
		else
			return -1;
	}
	*/
	/*public int compareTo(SortedOwn obj)
	{
		if(EmplyeID==obj.EmplyeID)
			return 0 ;
		else if(EmplyeID >obj.EmplyeID)
			return 1;
		else
			return -1;
	}*/
	
	public int compareTo(SortedOwn obj){
		
		return EmpName.compareTo(obj.EmpName);
	}
	
	public String toString()
	{
		return age +" "+ EmpName+" " + EmplyeID;
	}
	

	public static void main(String[] args) {
		
		ArrayList<SortedOwn> arrayobj= new ArrayList<SortedOwn> ();
		arrayobj.add(new SortedOwn(100,"vinay",500));
		arrayobj.add(new SortedOwn(111,"venky",300));
		arrayobj.add(new SortedOwn(113,"Akash",400));

		Collections.sort(arrayobj);
		
		for(SortedOwn oneobj: arrayobj)
		{
			System.out.println(oneobj);
			/*System.out.println(oneobj.age +" "+ oneobj.EmpName+" " + oneobj.EmplyeID);*/
		}
	}

	

}
