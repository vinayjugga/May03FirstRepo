package aJava_vinay_example;

import java.util.Comparator;

public class ComparatorSorting implements Comparator<Student> {

	@Override
	public int compare(Student arg0, Student arg1) {
		// TODO Auto-generated method stub
		return (arg0.name.compareTo(arg1.name));
	}
	/*
	@Override
	public int compare(Student arg0, Student arg1) {
		// TODO Auto-generated method stub
		if(arg0.age == arg1.age)
		 return 0;
		else if(arg0.age >arg1.age)
			return 1 ;
		return -1;
	}*/
	
}
