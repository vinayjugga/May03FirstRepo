package aJava_vinay_example;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Student implements Comparable<Student> {
	
	int age ;
	String name ;

	Student(int age,String name)
	{
		this.age = age;
		this.name =name ;
	}
	
	/*@Override
	public int compareTo(Student o)
	{
		return this.name.compareTo(o.name);
	}*/
	
	@Override 
	public int compareTo(Student o)
	{
		if(this.age == o.age)
			return 0 ;
		else if(this.age >o.age)
			return 1 ;
		return -1;
	}
	@Override
	public String toString()
	{
		return age +" " +name;
	}
	
	
	
	public static void main(String[] args) {
		
		List<Student> list =new ArrayList<Student>() ;	
		
		
		list.add(new Student(36, "vinay"));
		list.add(new Student(360, "venky"));
		list.add(new Student(30,"Akash"));
		list.add(new Student(25,"zkash"));
		
	
		Collections.sort(list, new ComparatorSorting());
		
		for(Student s1:list)
		{
			System.out.println(s1);
		}
	}

}
