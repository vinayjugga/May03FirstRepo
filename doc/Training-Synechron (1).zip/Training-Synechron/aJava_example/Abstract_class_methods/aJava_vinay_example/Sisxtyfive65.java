package aJava_vinay_example;

public class Sisxtyfive65 {

	public static void main(String[] args) {

		SixtyFour64 sixtyFour64 = new SixtyFour64();
		sixtyFour64.test1();
		SixtyThree63.test3();

	}

}
