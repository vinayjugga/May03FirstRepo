package aJava_vinay_example;

public abstract class SixtyThree63 extends SixtyTwo62 {

	static void test3() {
		System.out.println("test2 implemented");
		
	}
	
	void test2()
	{
		System.out.println("Sandeep");
	}

}
