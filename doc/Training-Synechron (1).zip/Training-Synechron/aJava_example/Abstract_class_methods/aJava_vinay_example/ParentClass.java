package aJava_vinay_example;

public abstract class ParentClass {
	
	public abstract  void display() ;
	
	
	public void test1()
	{
		System.out.println("vinay");
	}

}
