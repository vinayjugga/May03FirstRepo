package aJava_vinay_example;

public class SistyOne61 extends Sixty60 {

	public static void main(String[] args) {
		
		System.out.println("Done");

	}

}
