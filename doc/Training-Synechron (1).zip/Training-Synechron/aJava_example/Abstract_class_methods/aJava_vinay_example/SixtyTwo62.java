package aJava_vinay_example;

public abstract class SixtyTwo62 {

	abstract void test1() ;
	abstract void test2() ;
}
