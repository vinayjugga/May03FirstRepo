package aJava_vinay_example;

public class SixtyFour64  {

	void test1()
	{
		System.out.println("test2");
	}
}
