package aJava_vinay_example;

public abstract class FiftyNine59 {
	
	public abstract void test1() ;
	public abstract void test2() ;

}
