package aJava_vinay_example;

public class Childclass extends ParentClass1 {

	@Override
	public void display() {
		System.out.println("Child class implemented");
		
	}	
	
	public void test2()
	{
		System.out.println("Akash");
	}
	
	public void test1()
	{
		System.out.println("vekatesth");
	}
	
	public static void main(String args[])
	{
		ParentClass1 p1 = new Childclass();
			
		p1.display();
		
		Childclass c1 = (Childclass)p1;
		c1.test2();
		
		
		
		
	}

}
