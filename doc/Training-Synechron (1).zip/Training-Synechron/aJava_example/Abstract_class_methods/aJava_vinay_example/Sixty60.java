package aJava_vinay_example;

public class Sixty60 extends FiftyNine59{
	
	@Override
	public void test2() {
		// TODO Auto-generated method stub
		
	}

	//if we comments this what is the output
	@Override
	public void test1() {
		// TODO Auto-generated method stub
		
	}

}
