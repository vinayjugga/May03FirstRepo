package aJava_vinay_example;

public class Access2 {

	public static void main(String[] args) {
		AccessA1 ob2 = new AccessA1();
		ob2.setA(150);
		System.out.println(ob2.getA());
	}

}
