package aJava_vinay_example;

public class AccessA1 {

	private int a =99 ;
	
	private int b ;
	
	public int getA()	
	{
		return a ;
	}
	
	/**
	 * 
	 * @param a
	 */
	public void setA(int a)
	{if(a<100){
		this.a = a ;
	}
	}
	
	public static void main(String[] args) {
		AccessA1 obj1=  new AccessA1();
		System.out.println(obj1.a);
		
		
		
	}

}
