package com.access.specifiers.examples;

public class AA {

	private int a =10 ;
	public int b = 20 ;
	
	private void display()
	{
		System.out.println("private method access only within the class" +a);
	}
	
	protected void test1()
	{
		System.out.println("Procted method access only within the pacackage aand in the subclass");
	}
	
	 void test2()
	 {
		 System.out.println("Default Access specifier within the package only access");
	 }
	
	public void test3()
	{
		System.out.println("Public access from anywhere");
	}
	
	 
	public static void main(String[] args) {


		AA aobj= new AA() ;
		
		System.out.println(aobj.a);
		System.out.println(aobj.b);
		aobj.display();
		aobj.test1(); 
		aobj.test2();
		aobj.test3();

	}

}
