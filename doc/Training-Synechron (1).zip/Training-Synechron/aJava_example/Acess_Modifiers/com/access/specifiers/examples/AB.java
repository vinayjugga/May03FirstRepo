package com.access.specifiers.examples;

public class AB {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AA aobj= new AA() ;
		
		//System.out.println(aobj.a);
		System.out.println(aobj.b);
		//aobj.display();
		aobj.test1(); 
		aobj.test2();
		aobj.test3();

	}

}
