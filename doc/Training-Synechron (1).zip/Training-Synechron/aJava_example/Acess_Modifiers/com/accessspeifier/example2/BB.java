package com.accessspeifier.example2;

import com.access.specifiers.examples.AA;

public class BB extends AA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AA aobj= new AA() ;
		
		//System.out.println(aobj.a);
		System.out.println(aobj.b);
		//aobj.display();
		//aobj.test1(); 
		//aobj.test2();
		aobj.test3();
		
		BB bobj= new BB() ;
		
		//System.out.println(bobj.a);
		System.out.println(bobj.b);
		//bobj.display();
		bobj.test1(); 
		//bobj.test2();
		bobj.test3();
	}

}
