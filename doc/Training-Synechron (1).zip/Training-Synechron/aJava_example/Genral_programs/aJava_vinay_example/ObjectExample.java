package aJava_vinay_example;

public class ObjectExample {

	public void display()
	{
		System.out.println("vinay");
	}
	public static void main(String[] args) {
		
		ObjectExample obj1 = new ObjectExample();
		obj1.hashCode();

	}

}
