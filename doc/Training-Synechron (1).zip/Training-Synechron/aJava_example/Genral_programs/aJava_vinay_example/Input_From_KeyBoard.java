package aJava_vinay_example;

import java.util.Scanner;

public class Input_From_KeyBoard {

	public static void main(String[] args) {
		
		Scanner scn = new Scanner(System.in);
		int n = scn.nextInt();
		int total = 0;
		for(int i=0; i<n; i++)
		{
			int a = scn.nextInt();
			int b = scn.nextInt();
			int c = scn.nextInt();
			total = a + b + c;
		}
	scn.close();
		System.out.println("Entered inoput are a+b+c"+total);
	}

}
