package aJava_vinay_example;
/* Write a program to implement the Bank site*/
public class Fourteen14 {

	int balance ;
	void balance()
	{
		System.out.println("Balance in your save account: ="+balance);
	}
	
	void deposit(int depositAmount)
	{
		balance = balance + depositAmount ;
		System.out.println("DepositAmount:= "+depositAmount);
		System.out.println("Current Balance:= " + balance);
	}
	
	void withDraw(int withdrawAmount)
	{
		if(withdrawAmount<=balance && withdrawAmount >0){
		balance =balance-withdrawAmount;
		System.out.println("Withdraw Amount:= " +withdrawAmount);
		System.out.println("Current Balce after wihdraw:="+balance);
		}
		else
		{
			System.out.println("Your Account has insuffeient Balace");
			
		}
	}
	public static void main(String[] args) {
		
		System.out.println("Welcome to WellsFargo Bank");
		Fourteen14 fourteen14Obj = new Fourteen14();
		
		System.out.println("Deposit the amount to your Account");
		fourteen14Obj.deposit(500000);
		System.out.println("Withdraw the amount ");
		fourteen14Obj.withDraw(1034);
		fourteen14Obj.withDraw(100001);
			

	}

}
