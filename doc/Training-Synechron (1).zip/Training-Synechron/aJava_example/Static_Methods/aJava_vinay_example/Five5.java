package aJava_vinay_example;
/* write the program to access the static method without using the class reference */
public class Five5 {
	
	static void testMethod1()
	{
		System.out.println("Static method From Testmethod1()");
	}

	public static void main(String[] args) {
		
		System.out.println("Example of static method Access");
		testMethod1();
		System.out.println("Static method can assess Driect From Static blocks");
		
		Six6.testMethod1();
		Six6.testMEthod2();
	}

}
