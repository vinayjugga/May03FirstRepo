package aJava_vinay_example;
/* what is output , if the static variable value re initialized */
public class Eleven11 {

	static int vinayID= 200 ;
	
	public static void main(String[] args) {
		
		System.out.println("Example of Static variable re-initalize value");
		System.out.println("Value of vinayId:= "+vinayID);
		vinayID=30 ;
		System.out.println("After Reintialize static variable value viayID:= "+vinayID);

	}

}
