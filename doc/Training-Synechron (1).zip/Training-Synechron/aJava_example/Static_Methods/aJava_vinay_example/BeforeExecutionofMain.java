package aJava_vinay_example;

public class BeforeExecutionofMain {
	
	static
	{
		System.out.println("Before execution of main method static block will be executed");
	}

	public static void main(String[] args) {
		System.out.println("vinay");

	}

}
