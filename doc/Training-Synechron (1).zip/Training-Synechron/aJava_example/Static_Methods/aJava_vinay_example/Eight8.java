package aJava_vinay_example;

import aJava_example.One1;

/* write the program to access the static variable inside the static method and static block*/
public class Eight8 {

	static int vinayID =30 ;
	static void testmethod1()
	{
		System.out.println("Static variable access in the Static method or Block "+ vinayID);
	}
	public static void main(String[] args) {
		
		System.out.println("Example of Access the static variable in the static Block");
		testmethod1();
		System.out.println("Value of VinayID:="+vinayID);
		System.out.println("Value of VinayID:="+Eight8.vinayID);
		One1 obj = new One1();
		System.out.println(obj.PI) ;
		
	}

}
