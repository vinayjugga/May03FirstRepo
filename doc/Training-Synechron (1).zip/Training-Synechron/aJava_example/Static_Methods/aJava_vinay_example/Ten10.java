package aJava_vinay_example;
/* what is the output ,  if the static variable and local variable with same name */
public class Ten10 {

	static int vinayID= 20 ;
	
	public static void main(String[] args) {
		
		System.out.println("Example of Access Static variable same in global and Local variable");
		System.out.println("Value of VinayID Belfore Delcare local variable:="+vinayID);
		int vinayID= 30;
		System.out.println("Value of VinayID:="+vinayID);		

	}
	

}
