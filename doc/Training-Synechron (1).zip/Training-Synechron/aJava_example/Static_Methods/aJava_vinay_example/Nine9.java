package aJava_vinay_example;
/* write the program to access the static variable inside the non-static block */
public class Nine9 {
	static int vinayID =20 ;
	
	void testmethod1()
	{
		System.out.println("Static Varible direct access in non-static test1method :"+vinayID);
	}
	
	public static void main(String[] args) {
		System.out.println("Example of static variable access in Non-static methods");
		Nine9 nine9Obj = new Nine9();
		nine9Obj.testmethod1();
		System.out.println("Static variable value:="+vinayID);		

	}

}
