package aJava_vinay_example;
/* Write a program to access the static methods with/without using the class reference */
public class Six6 {

	static void testMethod1()
	{
		System.out.println("Static block testMethod1()");
	}
	static void testMEthod2()
	{
		System.out.println("static block testMethod2()");
	}
	
	public static void main(String[] args) {
		System.out.println("Example of static method acess with Class reference");
		Six6.testMethod1();
		Six6.testMEthod2();
		System.out.println("Static block can acces using with Class refrence also and without Reference also");
		testMethod1();
		testMEthod2();
		System.out.println("Driectly acess Static block/method without class reference ");
	}

}
