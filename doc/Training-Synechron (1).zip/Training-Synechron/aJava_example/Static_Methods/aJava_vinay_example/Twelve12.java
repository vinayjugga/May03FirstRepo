package aJava_vinay_example;
/* what is the output , if re-initialized the local and static variable values */
public class Twelve12 {

	static int vinayId =500 ;
	int a1= 500;
	public static void main(String[] args) {
		
		Twelve12 onj1 = new Twelve12();
		Twelve12 onj2 = new Twelve12();
		onj1.a1= 400;
		System.out.println("Example of Static global variable and local variable ");
		System.out.println("Value of VinayID:= "+vinayId);
		vinayId=400 ;
	
		System.out.println("Value of VinayID:= "+vinayId);
		int vinayId =300 ;
		System.out.println("Value of VinayID:= "+vinayId);
		vinayId=200 ;
		System.out.println("Value of VinayID:= "+vinayId);
		vinayId=100 ;
		System.out.println("Value of VinayID:= "+Twelve12.vinayId);
		
		System.out.println("a1:="+onj1.a1);
		System.out.println("a1:="+onj2.a1);
		
	}

}
