package aJava_vinay_example;
/* write the program to access the non-static variable */
public class Thirteen13 {

	int a =10 ;
	int b= 20 ;
	static int c = 30 ;
	
	void testmethod()
	{
		System.out.println("Non- static method access a: ="+a +"b := "+ (b +c));
	}
	public static void main(String[] args) {
		
		Thirteen13 thirteen13Obj = new Thirteen13();
		thirteen13Obj.testmethod();
		System.out.println(thirteen13Obj.a);
		Thirteen13 thirteen13Obj1 = new Thirteen13();
		thirteen13Obj1.a =20 ;
		System.out.println(thirteen13Obj.a);
		System.out.println(thirteen13Obj1.a);
		
		System.out.println("Example of access non static variable in static block");
		System.out.println("Access variable a :="+thirteen13Obj.a);

	}

}
