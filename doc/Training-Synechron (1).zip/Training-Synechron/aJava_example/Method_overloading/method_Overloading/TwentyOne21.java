package method_Overloading;
/* what is the output of Method overloading */

public class TwentyOne21 {

	public static void display()
	{
		System.out.println("Vinay ");
	}
	
	/*public void display()
	{
		System.out.println("M L");
	}
	public int display()
	{
		System.out.println("Return interger");
		return 0 ;
	}
	*/
	
	public static void main(String[] args) {
		System.out.println("Example of same method name but return type different");
		display();
		System.out.println("Successfuly printed");
		TwentyOne21 twentyOne21Obj = new TwentyOne21();
		//twentyOne21Obj.display();
		
		

	}

}
