package method_Overloading;
/* write a program to overloading static and non-static methods */
public class Twenty20 {
	
	static void display()
	{
		System.out.println("Vinay");
	}
	public void display(int a)
	{
		System.out.println("Jugga");
	}

	public static void main(String[] args) {
	
		System.out.println("Example of method overloading static and non static methods ");
		display();
		  

	}

}
