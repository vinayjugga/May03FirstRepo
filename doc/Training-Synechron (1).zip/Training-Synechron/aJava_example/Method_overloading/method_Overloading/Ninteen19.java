package method_Overloading;
/* Write a program of non static method overloading */
public class Ninteen19 {
	
	void testMethod(int a) 
	{
		System.out.println("Testmethod(int a):=" +a);
	}

	void testMethod(int b, int c)
	{
		System.out.println("testmehtod of 2 argments(a,b):="+b+" "+c);
	}
	public static void main(String[] args) {

		System.out.println("Example of Method overloading non-static methods");
		Ninteen19 ninteen19Obj = new Ninteen19();
		ninteen19Obj.testMethod(30);
		ninteen19Obj.testMethod(30, 40);

	}

}
