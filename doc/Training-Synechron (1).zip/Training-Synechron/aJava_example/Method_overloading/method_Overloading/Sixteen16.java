package method_Overloading;
/* write the program to add the sum of integer using overloading method*/
public class Sixteen16 {

	static void add(int a , int b)
	{
		int total = a + b ;
		System.out.println("Total of 2 numbers : a+ b:="+total);
	}
	
	static void add(int c, int d, int e) 
	{
		int sum = c + d + e ;
		System.out.println("Sum of 3 numbers a+b+c:="+sum);
	}
	public static void main(String[] args) {
		
		System.out.println("Example of Method overloading same method name with different arguments");
		add(10,20);
		add(30,40,50);
		

	}

}
