package method_Overloading;
/* write a program to utilize the two constructor; what is output */
public class Thirty30 {

	int vinayId ;
	
	Thirty30()
	{
		System.out.println("Default constuctor Executed ");
	}
	
	Thirty30(int id)
	{
		vinayId=id ;
	}
	public static void main(String[] args) {
		
		System.out.println("Example of 2 constuctor used to create the object");		
		Thirty30 thirty30Obj = new Thirty30();
		System.out.println("Value of Default vinayID:="+thirty30Obj.vinayId);
		
		Thirty30 thirty30Obj1 = new Thirty30(100);
		System.out.println("Value of Default vinayID:="+thirty30Obj.vinayId);
		thirty30Obj.vinayId = 200 ;
		System.out.println("Value of Default vinayID:="+thirty30Obj1.vinayId);

	}

}
