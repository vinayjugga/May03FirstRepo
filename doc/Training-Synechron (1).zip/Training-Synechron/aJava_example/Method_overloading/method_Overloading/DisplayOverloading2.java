package method_Overloading;

public class DisplayOverloading2 {

	public static void main(String[] args) {
		
		Sample2 sample2Obj = new Sample2();
		System.out.println("Overloading -Difference in data type of Arguments:");
		sample2Obj.display('a');
		sample2Obj.display(100);
		
	}

}

class Sample2
{
	public void display(char c)
	{
		System.err.println(c);
	}
	public void display(int a)
	{
		System.out.println(a);
	}
	
}
