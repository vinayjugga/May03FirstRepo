package method_Overloading;
/* write a program to overloading constructor */
public class Fifteen15 {

	static void testMethod()
	{
		System.out.println("No Argument in this testMethod() ");
	}
	
	static void testMethod(int a)
	{
		System.out.println("Method have the 1 arument testMethod(int a)");
	}
	
	static void testMethod(int a ,double d)
	{
		System.out.println("Method have the 2 arguments testMethod(int a double d");
	}
	
	static void testMethod(double c, int b)
	{
		System.out.println("method have the 2 argumeths testMEthod(double c, int b)");
	}
	static void testMethod(int c, int b)
	{
		System.out.println("method have the 2 argumeths testMEthod(double c, int b)");
	}
	
	public static void main(String[] args) {
		
		System.out.println("Example of Overlaoding method");
		int a = 10 ;		
		testMethod();
		testMethod(10);
		testMethod(20.0, 30);
		testMethod(20, 40.3);
		testMethod(10,10);
		
		
	}

}
