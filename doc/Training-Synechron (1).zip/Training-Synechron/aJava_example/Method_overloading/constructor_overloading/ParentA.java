package constructor_overloading;

public class ParentA {

	ParentA()
	{
		//System.out.println("Default Construct ParentA");
	}
	
	ParentA(int a)
	{
		//System.out.println("Parametised constuctor ParentA");
	}
	
	public void m1()
	{
		System.out.println("123");
	}
	public void m2(int b)
	{
		System.out.println("456");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
