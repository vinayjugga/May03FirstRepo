package constructor_overloading;

public class SuperExample1 extends SuperExample {

	int a = 20 ;
	int b  ;
	
	SuperExample1(int b)
	{
		super(b);
		System.out.println("Java");
	}
	
	public void display()
	{
		
		System.out.println("a:="+a);
		super.display();
	
	}
	public static void main(String[] args) {
		
		SuperExample1 s1 = new SuperExample1(40);
		
		s1.display();

	}

}
