package constructor_overloading;

public class ChildB extends ParentA {

	
	ChildB()
	{
		System.out.println("Child default constuctor ChildB");
	}
	
	ChildB(int a)
	{
		this();
		System.out.println("child paramentzed constuctor Child B");
	}
	
	public void m3()
	{
		super.m1();
		System.out.println("AbC");
	}
	
	public void m4(int b)
	{
		System.out.println("def");
	}
	public static void main(String[] args) {
		
		//ParentA a1 = new ChildB();
		//a1.m1(); 
		//ChildB b1 =(ChildB) a1 ;
		
		
		ParentA a2 = new ChildB(10);
		//a2.m2(10);
		

	}

}
