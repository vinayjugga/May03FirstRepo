package constructor_overloading;
/* what is output of recursive constructor overloading */
public class ThirtyFour34 {

	ThirtyFour34()
	{
		//this(10);
		System.out.println("Executed constuctor 1");
	}
	ThirtyFour34(int aa)
	{
		this();
		System.out.println("Executed constructor 2");
	}
	
	
	public static void main(String[] args) {
		System.out.println("Example of Recursive constructor invoking ");
		ThirtyFour34 thirtyFour34 = new ThirtyFour34(20);		

	}

}
