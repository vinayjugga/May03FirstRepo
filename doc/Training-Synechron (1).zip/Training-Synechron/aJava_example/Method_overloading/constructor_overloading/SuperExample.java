package constructor_overloading;

public class SuperExample {
		
	int a =10 ;
	
	SuperExample(int b)
	{
		a =b;
	}
	public void display()
	{
		System.out.println("a:="+a);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
