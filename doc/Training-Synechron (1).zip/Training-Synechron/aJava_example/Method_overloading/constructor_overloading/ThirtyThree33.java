package constructor_overloading;
/* what is output of the constructor overloading */

public class ThirtyThree33 {

	ThirtyThree33()
	{
		System.out.println("Exected constructor 1");
	}
	ThirtyThree33(int a)
	{
		this();
		System.out.println("Executed constructor 2");
	}
	ThirtyThree33(int aa, double dd)
	{
		this(10);
		System.out.println("Executed constucotr 3 ");
	}
	
	ThirtyThree33(double cc, int bb)
	{
		this(10,10.5);
		System.out.println("Executed constuctor 4");
	}
	public static void main(String[] args) {
		System.out.println("Example of Constuctor overloading and invoke using this() stament");
		ThirtyThree33 thirtyThree33Obj = new ThirtyThree33(10.5, 20);		

	}

}
