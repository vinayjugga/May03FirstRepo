package constructor_overloading;
/* what is the output, if the this() statement used twice in the constructor */
public class ThirtySix36 {

	ThirtySix36()
	{
		System.out.println("Executed cosntuctor 1");
	}
	ThirtySix36(int a)
	{
		System.out.println("Executed constuctor 2");
	}
	ThirtySix36(int a , double dd)
	{
		this(a);
		//this();
		System.out.println("Executed constuctor 3");
	}
	public static void main(String[] args) {
		System.out.println("Example of constuctor overloading , while using this() statment twice in the constuctor");

		ThirtySix36 thirtySix36Obj = new ThirtySix36(10,22.22);
	}

}
