package constructor_overloading;
/* what is the output of the program when using the this() method as in second statement in the constructor */
public class ThirtyFive35 {

	ThirtyFive35()
	{
		System.out.println("Executed constuctor 1 ");
	}
	
	ThirtyFive35(int a)
	{
		System.out.println("Executed constructor 2 ");
		//this();
	}
	ThirtyFive35(int a , int b)
	{
		this(10);
		System.out.println("Executed constructor 3");
	}
	public static void main(String[] args) {
		System.out.println("Example of Constuctor overloaind while using this() statement as second stmnt");
		ThirtyFive35 thirtyFive35Obj = new ThirtyFive35(20,30);
				
	}

}
