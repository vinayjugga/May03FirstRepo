package constructor_overloading;
/* write a program to invoke the Constructor from another constructor using this() statment */
public class ThirtyTwo32 {

	ThirtyTwo32()
	{
		System.out.println("Executed constuctor without argment:ThirtyTwo32() ");
	}
	
	ThirtyTwo32(int id)
	{
		this();
		System.out.println("Executed Constructor with arugment: ThirtyTwo32(int id)");
	}
	
	public static void main(String[] args) {
		System.out.println("Example of Invoking the one constuctor from another using this() method");
		ThirtyTwo32 thirtyTwo32Obj = new ThirtyTwo32(30) ;
		//System.out.println("Value of Id:="+thirtyTwo32Obj);
	}

}
