package constructor_overloading;
/* what is the output , Constructor overloading program */
public class ThirtyOne31 {

	int id ;
	int id2 ;
	ThirtyOne31()
	{
		this(10);
		System.out.println("Executed Constructor without arguments: ThirtyOne31()");
	}
	ThirtyOne31(int id )
	{
		this(10.4);
		/*this.id = id ;
		this.id2 = id2*/
		System.out.println("Exceuted Constructor with aruments: ThirtyOne31(int id) ");
	}
	ThirtyOne31(double d)
	{
		this(10,20.3);
		System.out.println("Executed Constructor with double data type argument:ThirtyOne31(double d)");
	}
	ThirtyOne31(int aa, double dd)
	{
		this(22.2,40);
		System.out.println("Executed Constructor with 2 arguments:ThirtyOne31(int aa, double dd) ");
	}
	ThirtyOne31(double cc, int bb)
	{
		System.out.println("Exceuted Constructor with 2 aruments: ThirtyOne31(double cc, int bb)");
	}
	
	
	public static void main(String[] args) {
		System.out.println("Example of Constuctor overloading ");
		ThirtyOne31 thirtyOne31Obj = new ThirtyOne31();
		/*ThirtyOne31 thirtyOne31Obj1 = new ThirtyOne31(10);
		ThirtyOne31 thirtyOne31Obj2 = new ThirtyOne31(20.10);
		ThirtyOne31 thirtyOne31Obj3 = new ThirtyOne31(30, 40.11);
		ThirtyOne31 thirtyOne31Obj4 = new ThirtyOne31(50.55, 60);*/
		//ThirtyOne31 thirtyOne31Obj5 = new ThirtyOne31(70, 80) ;
		System.out.println("Pritned 7 lines");
		

	}

}
