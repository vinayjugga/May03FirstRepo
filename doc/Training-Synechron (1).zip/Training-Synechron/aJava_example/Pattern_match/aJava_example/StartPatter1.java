package aJava_example;

/*       *
 *      * *
 *     * * *
 *    * * * *
 * 
 * 
 * 
 * 
 * 
 */
public class StartPatter1 {
	public static void main(String args[])
	{
		int n =5 ;
		int i=1 ;
		int j=1;
		for(;i<=n;i++)
		{
			
		}
	}

}
