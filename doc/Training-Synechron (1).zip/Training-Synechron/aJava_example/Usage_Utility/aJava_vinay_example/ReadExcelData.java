package aJava_vinay_example;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ReadExcelData {

	public static void main(String[] args) throws Exception, InvalidFormatException {
		String exclpath="C:/vinay/aJava_example/Usage_Utility/aJava_vinay_example/vinay_data.xlsx";
		FileInputStream filein= new FileInputStream(exclpath);
		Workbook wb = WorkbookFactory.create(filein);
		Sheet s1= wb.getSheet("Sheet1");
		String username =s1.getRow(0).getCell(0).getStringCellValue();
		System.out.println(username);
		

	}

}
