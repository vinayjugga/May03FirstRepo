package aJava_vinay_example;

public class ExampleEmailRead {

	public static void main(String[] args) {
		
		String host = "pop.gmail.com";
		String mailStore ="pop3";
		String username ="vinay.synechron@gmail.com" ;
		String loginPassword ="synechron123";
		String searchsubject =".5755699314878108";
		
		//MailRead.readmail(host, mailStore, username, loginPassword);
		MailRead2.readmailSearchSubject(host, username, loginPassword,searchsubject);
	}

}
