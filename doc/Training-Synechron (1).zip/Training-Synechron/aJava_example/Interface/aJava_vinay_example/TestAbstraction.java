package aJava_vinay_example;

public class TestAbstraction {
	
	 public static void main(String args[]) {
		 
		 System.out.println("Abstraction : Implementation hiding");

		 TV tvobj =User.getproperties("sony") ;
		 tvobj.audio();
		 tvobj.video();
		 
		 TV tvobj1 =User.getproperties("onida") ;
		 tvobj1.audio();
		 tvobj1.video();
	 }
}
