package aJava_vinay_example;

public interface G {

	void test1();
}
