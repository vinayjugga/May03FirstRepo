package aJava_vinay_example;

public class Sony implements TV {

	@Override
	public void video() {
		System.out.println("Sony video implemented");
		
	}

	@Override
	public void audio() {
		System.out.println("Sony Audio implemented");
		
		
	}
	

}
