package aJava_vinay_example;

public abstract class FiftyFour54 implements Fifity53 {

	@Override
	public void display() {
		System.out.println("FiftyFour54 display method overriden");
		
	}

	@Override
	public void test1() {
		System.out.println("FiftyFour54 test1 method overriden");
		
	}
	
	public void test2()
	{
		System.out.println("FiftyFour54 test2 method overriden");
		
	}
	
	public abstract void test3();

}
