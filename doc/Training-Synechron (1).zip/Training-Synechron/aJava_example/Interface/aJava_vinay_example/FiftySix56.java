package aJava_vinay_example;

public class FiftySix56 implements Fifity53{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public void display() {
		System.out.println("FiftySix56 display method");
		
	}

	@Override
	public void test1() {
		System.out.println("FiftySix56 test1 method");
		
	}

}
