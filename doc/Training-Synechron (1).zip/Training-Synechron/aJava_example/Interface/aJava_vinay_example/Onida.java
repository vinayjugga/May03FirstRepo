package aJava_vinay_example;

public class Onida implements TV {

	@Override
	public void video() {
		System.out.println("Onida video implemented");
		
	}

	@Override
	public void audio() {
		System.out.println("Onida audio implemented");
		
	}

	

}
