package aJava_vinay_example;

public class Fiftyfive55 extends FiftyFour54 {

	
	public void test3() {
		System.out.println("test3 mehtod ");
	}
	
	public static void main(String[] args) {
		
		Fifity53 f5 = new Fiftyfive55();
		f5.display();
		f5.test1();
		
		Fifity53 f6 = new FiftySix56();
		f6.display();
		f6.test1();
		
		

	}

	

}
