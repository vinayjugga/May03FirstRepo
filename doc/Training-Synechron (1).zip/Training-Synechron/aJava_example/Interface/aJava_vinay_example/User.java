package aJava_vinay_example;

public class User {
	
	static TV getproperties(String str)
	{
		if(str.equals("sony")){
		 
			return new Sony();
		}
		else
		{
			return new Onida();
		}
		
	
	}

}
