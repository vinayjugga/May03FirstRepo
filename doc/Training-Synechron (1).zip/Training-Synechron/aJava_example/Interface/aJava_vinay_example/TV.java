package aJava_vinay_example;

public interface TV  {
	
	public void video();
	public void audio();
	

}
