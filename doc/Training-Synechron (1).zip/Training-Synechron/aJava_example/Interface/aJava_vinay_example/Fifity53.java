package aJava_vinay_example;

public interface Fifity53 {
	
	public int a =10 ;
	public abstract void display();
	public void test1();
	
}
