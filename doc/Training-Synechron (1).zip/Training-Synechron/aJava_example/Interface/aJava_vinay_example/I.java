package aJava_vinay_example;

public interface I extends G,H {

	void test3() ;
}
