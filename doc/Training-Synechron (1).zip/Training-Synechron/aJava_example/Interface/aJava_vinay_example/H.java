package aJava_vinay_example;

public interface H {

	void test2() ;
}
