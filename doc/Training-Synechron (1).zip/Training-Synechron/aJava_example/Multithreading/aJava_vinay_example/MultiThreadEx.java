package aJava_vinay_example;

public class MultiThreadEx extends Thread {

	public void run()
	{
		System.out.println("thread is running");
	}
	public static void main(String[] args) {
		
		MultiThreadEx mul = new MultiThreadEx();
		mul.start();

	}

}
