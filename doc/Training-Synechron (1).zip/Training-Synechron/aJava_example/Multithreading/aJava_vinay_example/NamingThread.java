package aJava_vinay_example;

public class NamingThread extends Thread {

	
	public void run()
	{
		for(int i=0;i<5;i++){
			System.out.println("Thread running :="+i);
			System.out.println(Thread.currentThread().getName());
		}
		
	}
	public static void main(String[] args) {
		
		NamingThread t1 = new NamingThread();
		NamingThread t2 = new NamingThread();
		NamingThread t3 = new NamingThread();
		
		t1.start();
		System.out.println("Thread name t1:="+t1.getName());
		
		t1.setName("thead vinay");

		System.out.println("Thread name t1:="+t1.getName());
		t2.start();
		

	}

}
