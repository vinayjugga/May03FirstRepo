package aJava_vinay_example;

public class MultiThreadPriority extends Thread {

	public void run()
	{
		for(int i=0;i<=5;i++){
			try {
				Thread.sleep(100);
				System.out.println("thread running:= "+i);
				System.out.println(Thread.currentThread().getName());
				System.out.println(Thread.currentThread().getPriority());;
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}
	public static void main(String[] args) {
		
		MultiThreadPriority t1 = new MultiThreadPriority();
		MultiThreadPriority t2 = new MultiThreadPriority();
		t1.run();
		t2.run();
		
		
		t1.start();
		t2.start();
		t1.setPriority(Thread.MIN_PRIORITY);
		t2.setPriority(Thread.MAX_PRIORITY);
	}

}
