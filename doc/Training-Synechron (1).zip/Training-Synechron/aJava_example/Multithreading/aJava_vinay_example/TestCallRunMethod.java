package aJava_vinay_example;

public class TestCallRunMethod extends Thread {
	
	public void run()
	{
		for(int i=0;i <=5;i++){
			try {
				Thread.sleep(100);
				System.out.println("Thread running := "+ i);
				System.out.println(Thread.currentThread().getName());
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
	}

	public static void main(String[] args) {
		
		TestCallRunMethod t1 = new TestCallRunMethod();
		TestCallRunMethod t2 = new TestCallRunMethod();
		TestCallRunMethod t3 = new TestCallRunMethod();
		t1.run();
		t2.run();
		t1.start();
		try {
			t1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		t2.start();
		t3.start();

	}

}
