package com.syne.components;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.syn.core.pages.BaseTestCases;

public class BasePageComponent extends BaseTestCases{
	
	
	 public BasePageComponent(WebDriver driver)
	{
		PageFactory.initElements(super.getDriver(), this);
	}
}
