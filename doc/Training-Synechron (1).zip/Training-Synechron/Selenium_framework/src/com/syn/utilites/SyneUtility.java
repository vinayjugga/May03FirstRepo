package com.syn.utilites;


import java.util.Set;

import org.openqa.selenium.WebDriver;

import com.syn.core.pages.BasePage;
import com.syn.core.pages.ExtendBasePage;


public class SyneUtility extends ExtendBasePage{

	public static String Path ="C://Program Files (x86)/Microsoft Lync/communicator.exe" ;
	public static String getMainwindow()
	{
		try{
		String mainwindow =getDriver().getWindowHandle() ;
		return mainwindow;
		}
		catch(Exception error){
			error.printStackTrace();
		}
		
		return null;
	}
	
	public static void switchtoNewWindow(WebDriver driver,String title)
	{
		try{
			Set<String> childwindows = driver.getWindowHandles() ;
			for(String nextwindow:childwindows)
			{
				if(nextwindow.contains(title))
				{
					driver.switchTo().window(title);
					break;
				}
			}
		}
		catch(Exception error)
		{
			error.printStackTrace();
		}
	}
	
	public static void switchtoMainwindow(WebDriver driver, String mainwindow)
	{
		try{
			driver.switchTo().window(mainwindow);
		}
		catch(Exception error)
		{
			error.printStackTrace();
		}
	}
	
	public static void executeexe()
	{
		try{
		Runtime.getRuntime().exec(Path);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	
}
