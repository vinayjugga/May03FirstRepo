package com.syn.pages.homepage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.syn.core.pages.BasePage;

public class ExpressSendRemittanceCostEstimatorPage extends BasePage{

	@FindBy(linkText="How much can I send?")
	public WebElement linkHowMuchCanISend;
	
	@FindBy(xpath="//h1[normalize-space(.)='ExpressSend Remittance Cost Estimator']")
	public WebElement headerExpressSendRemittanceCostEstimator;
	
	
	@Override
	public void waitForPageLoad() {
		waitForVisible(linkHowMuchCanISend);
		waitForVisible(headerExpressSendRemittanceCostEstimator);
		
	}

	@Override
	public void verifyHeaderText(String expectText) {
		verifyText(headerExpressSendRemittanceCostEstimator, expectText);
		
	}

	@Override
	public void verifyErrorMsg(String error) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void invoke() {
		getDriver().get(getBaseurl());
		
	}
	public void invoke(String extendUrl)
	{
		getDriver().get(getBaseurl()+extendUrl);
	}

}
