package com.syn.pages.homepage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.syn.core.pages.BasePage;

public class ExpressSendInternationalRemittanceTransfersQuestionsPage extends BasePage {

	
	@FindBy(xpath="//h1[normalize-space(.)='ExpressSend International Remittance Transfers Questions']")
	public WebElement headerExpressSendInternational;
	
	@Override
	public void waitForPageLoad() {
		waitForVisible(headerExpressSendInternational);
		
	}

	@Override
	public void verifyHeaderText(String expectText) {
		verifyText(headerExpressSendInternational, expectText);
		
	}

	@Override
	public void verifyErrorMsg(String error) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void invoke() {
		getDriver().get(getBaseurl());
		
	}
	public void invoke(String extendUrl)
	{
		getDriver().get(getBaseurl()+extendUrl);
	}
}
