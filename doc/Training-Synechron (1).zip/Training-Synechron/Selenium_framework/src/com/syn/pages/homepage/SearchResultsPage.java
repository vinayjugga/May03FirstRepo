package com.syn.pages.homepage;



import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.syn.core.pages.BasePage;

public class SearchResultsPage extends BasePage {
	
	String actualText ;
	
	@FindBy(id="inputTopSearchField")
	public WebElement textBoxSearchField;
	
	@FindBy(xpath="//h1[text()='Search Results']")
	public WebElement headerSearchResults;
	
	@FindBy(id="btnTopSearchResults")
	public WebElement buttonSearchResults;
	
	@FindBy(id="searchmiss")
	public WebElement textWeFoundNoSearchResults;
		
	@Override
	public void waitForPageLoad() {
		waitForVisible(headerSearchResults);
		waitForVisible(buttonSearchResults);
	}

	@Override
	public void verifyHeaderText(String expectText)
	{
		
		verifyText(headerSearchResults, expectText);
		
	}
	
	@Override
	public void verifyErrorMsg(String errormsg)
	{
		verifyError(textWeFoundNoSearchResults, errormsg);
	}

	@Override
	public void invoke() {
		// TODO Auto-generated method stub
		
	}
	
	
}
