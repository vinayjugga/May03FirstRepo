package com.syn.pages.homepage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.syn.core.pages.BasePage;

public class OnlineBankingWithWellsFargoOnlinePage extends BasePage {

	
	@FindBy(xpath="//h1[normalize-space(.)=\"Online Banking with Wells Fargo Online�\"]")
	public WebElement headerOnlineBankingWithWellsFargoOnline;
	
	@FindBy(css =".c45badge")
	public WebElement textTakeTheTour;
	
	
	public void invoke()
	{
		
		getDriver().get(getBaseurl());
	}
	
	public void invoke(String extendUrl)
	{
		getDriver().get(getBaseurl()+extendUrl);
	}
		
	@Override
	public void waitForPageLoad() {
		waitForVisible(headerOnlineBankingWithWellsFargoOnline);
		waitForVisible(textTakeTheTour);
		
	}

	@Override
	public void verifyHeaderText(String expectText) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void verifyErrorMsg(String error) {
		// TODO Auto-generated method stub
		
	}

}
