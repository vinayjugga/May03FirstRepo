package com.syn.pages.homepage;



import java.io.FileInputStream;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

import com.syn.core.pages.BasePage;
import com.syne.components.BasePageComponent;

public class HomePage extends BasePage {
	

	@FindBy(id="inputTopSearchField")
	public WebElement searchField ;
//	WebElement searchField = driver.findElement(By.id("inputTopSearchField"));
	
	@FindBy(id="btnTopSearch")
	public WebElement buttonSearch;
		
	@FindBy(id="userid")
	public WebElement textBoxUsername;
	
	@FindBy(name="j_password")
	public WebElement textBoxPassword;
	
	@FindBy(name="btnSignon")
	public WebElement buttonSingon;
	
	@FindBy(id="topSearch")
	public HeaderComponet header;
		
	/*HomePage()
	{
		super();
		
	}*/
	
	public void invoke()
	{
		
		getDriver().get(getBaseurl());
	}
	
	public void invoke(String extendUrl)
	{
		getDriver().get(getBaseurl()+extendUrl);
	}
		
	public void enterSearchText(String searchtext)
	{
		searchField.sendKeys(searchtext);
		buttonSearch.click();	
	}
	
	@Override
	public void waitForPageLoad()
	{
		try{
		waitForVisible(searchField);
		waitForVisible(buttonSearch);
		Reporter.log(getClass().getName()+": Page Load Successfully.");
		}
		catch(Exception error)
		{
			Reporter.log(getClass().getName()+": Page not Loaded.");
			error.getStackTrace();
			
			
		}
	}

	@Override
	public void verifyHeaderText(String expectText) {
		
		
	}

	@Override
	public void verifyErrorMsg(String error) {
		// TODO Auto-generated method stub
		
	}

	public void loginHome(String name, String pass)
	{
		textBoxUsername.sendKeys(name);
		textBoxPassword.sendKeys(pass);
		buttonSingon.click();
	}

	public WebElement clickonLink(String text1)
	{
		return  getDriver().findElement(By.xpath("//a[text()='"+text1+"']")) ;
	}
	
	public class HeaderComponet {
		
		@FindBy(xpath=".//a[text()='Enroll']")
		public WebElement linkEnroll;
		
		@FindBy(xpath=".//a[text()='Customer Service']")
		public WebElement linkCustomerService;
		
		@FindBy(xpath=".//a[text()='ATMs/Locations']")
		public WebElement linkATMsOrLocations;
		
		@FindBy(xpath=".//a[text()='Espa�ol']")
		public WebElement linkEspanol;
	}
}
