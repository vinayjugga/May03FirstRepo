package com.syn.core.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.asserts.SoftAssert;


public abstract class BasePage extends ExtendBasePage {

	public String url = null;
	WebDriverWait wait ;
	String actualText=null;
	SoftAssert softAssert =new SoftAssert();
	public static Boolean status =true ;
	
	public abstract void invoke() ;
	public abstract void waitForPageLoad();

	public abstract void verifyHeaderText(String expectText);

	public abstract void verifyErrorMsg(String error) ;

	public BasePage()
	{
		PageFactory.initElements(getDriver(), this);
		wait=new WebDriverWait(getDriver(),60);
	}
	

	public void waitForVisible(WebElement locator)
	{
		actualText=locator.toString();
		wait.until(ExpectedConditions.visibilityOf(locator));
		Reporter.log(actualText.substring(65) +": Object Loaded successfully. ");
		Reporter.log("\n");
		System.out.println(actualText.substring(65) +": Object Loaded successfully. ");
	}
	
	public void verifyText(WebElement locator,String expectText)
	{

		try{
			actualText=locator.getText() ;
			if(actualText.equals(expectText)){
				Reporter.log("Passed : Actual Text:= ["+actualText+"] Expected Text:= ["+expectText+"]");
				System.out.println("Passed : Actual Text:= ["+actualText+"] Expected Text:= ["+expectText+"]");
				softAssert.assertEquals(actualText, expectText);
				
				
			}
			else
			{
				Reporter.log("Failed : Actual Text:= ["+actualText+"] Expected Text:= ["+expectText+"]");
				System.out.println("Failed : Actual Text:= ["+actualText+"] Expected Text:= ["+expectText+"]");
				softAssert.assertEquals(actualText, expectText);
				status =false ;
				
			}
		}
		catch(Exception error)
		{
			error.printStackTrace();
			Reporter.log(error.getMessage());
			
		}
		
	}


	public void verifyError(WebElement locator,String errorText)
	{

		try{
			actualText=locator.getText();
			if(actualText.contains(errorText)){
				softAssert.assertTrue(actualText.equals(errorText));
				Reporter.log("Passed : Actual Error:= ["+actualText+"] Expected Error:= ["+errorText+"]");
			
			}
			else
			{
				softAssert.assertTrue(actualText.equals(errorText));
				Reporter.log("Failed : Actual Error:= ["+actualText+"] Expected Error:= ["+errorText+"]");
				status= false;
			}
		}
		catch(Exception error)
		{
			error.printStackTrace();
			Reporter.log(error.getMessage());
		}
	}

	public void verifyExpectedPageURL(String exptedURL)
	{
		getDriver().getCurrentUrl();
		try{
			actualText=getDriver().getCurrentUrl();
			if(actualText.equals(exptedURL)){
				softAssert.assertTrue(actualText.equals(exptedURL));
				Reporter.log("Passed : Actual URL:= ["+actualText+"] Expected URL:= ["+exptedURL+"]");
				System.out.println("Passed : Actual URL:= ["+actualText+"] Expected URL:= ["+exptedURL+"]");
				
			}
			else
			{
				softAssert.assertTrue(actualText.equals(exptedURL));
				Reporter.log("Failed : Actual URL:= ["+actualText+"] Expected URL:= ["+exptedURL+"]");
				System.out.println("Failed : Actual URL:= ["+actualText+"] Expected URL:= ["+exptedURL+"]");
				status= false;
			}
		}
		catch(Exception error)
		{
			error.printStackTrace();
			Reporter.log(error.getMessage());
		}
	}

	public void EndofTestcase()
	{
		
		softAssert.assertAll();
		Assert.assertTrue(status);
	}






}
