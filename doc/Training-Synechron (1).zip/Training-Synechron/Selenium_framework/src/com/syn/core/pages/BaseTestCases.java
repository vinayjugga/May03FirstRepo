package com.syn.core.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

public class BaseTestCases  {

	private static WebDriver driver ;		
	String currnetpath =System.getProperty("user.dir");
	
	@BeforeSuite
	public void startTesting()
	{
		Reporter.log("[Vinay] :******* Automation Started testing.********" );
		System.out.println("[Vinay] :******* Automation Started testing.*********");
	}
	
	//String URL =();
	//@Parameters({ "BrowserSelect","appURL" })
	@BeforeMethod	
	//public void invokeBrowser(String BrowserSelect,String appURL)
	public void invokeBrowser()
	{		
		
		System.setProperty("webdriver.chrome.driver",currnetpath+"/server/chromedriver.exe");
		driver = new ChromeDriver();	
		
//		if(BrowserSelect.equals("CE")) {
//		System.setProperty("webdriver.chrome.driver",currnetpath+appURL);
//		driver = new ChromeDriver();
//		}
//		else
//		{
//		System.setProperty("webdriver.internet.driver",currnetpath+"/server/IEDriverServer.exe");
//		driver =new InternetExplorerDriver();
//		}
		//driver.get(URL);
		
	}
	
	@AfterMethod
	public void closeBrowser()
	{
		driver.quit();
	}
	
	@AfterSuite()
	public void finishedtesting()
	{
		Reporter.log("********************Fineshed Testing One Round Completely***************");
		System.out.println("********************Finished Testing One Round Completely***************");
	}
	
	@DataProvider(name="testData")
	public Object[][] testData()
	{
		Object[][] tcdata = new Object[2][2];
		tcdata[0][0]="vinay" ;
		tcdata[0][1] ="abcd" ;
		tcdata[1][0]="aksh" ;
		tcdata[1][1] ="efsg" ;
		return tcdata;
		
	}
	
	public static WebDriver getDriver()
	{
		return driver;
	}
	

}
