package com.syn.core.pages;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ExtendBasePage extends BaseTestCases{
	
	Properties prop = new Properties();
	InputStream input = null;
	String testurl= null;

	
	public ExtendBasePage()
	{
		try{
			String currnetlocation =System.getProperty("user.dir");
			input = new FileInputStream(currnetlocation+"/propertiesfile/application.properties");
			
			prop.load(input);
			testurl = prop.getProperty("syne.URL");	
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public String  getBaseurl()
	{
		return testurl;
	}

}
