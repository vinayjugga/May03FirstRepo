package com.syn.testsuite.testcases;

import org.testng.Reporter;
import org.testng.annotations.Test;

import com.syn.core.pages.BaseTestCases;
import com.syn.pages.homepage.ExpressSendRemittanceCostEstimatorPage;
import com.syn.pages.homepage.HomePage;
import com.syn.pages.homepage.OnlineBankingWithWellsFargoOnlinePage;
import com.syn.pages.homepage.SearchResultsPage;
import com.syn.utilites.SyneUtility;

public class TestHomepageTestCases extends BaseTestCases {
	
	@Test(priority=1)
	public void Homepagetest1()
	{
		HomePage homepage = new  HomePage();
		homepage.invoke();		
		homepage.clickonLink("Banking").click();;
		homepage.clickonLink("Insurance").click();
	
		System.out.println(getDriver().getCurrentUrl()) ;
		homepage.enterSearchText("loan");	
		
		
		SearchResultsPage searchResultsPage = new SearchResultsPage();
		searchResultsPage.waitForPageLoad();
		
		searchResultsPage.verifyHeaderText("Search Results1");
		searchResultsPage.EndofTestcase();
		
	}
	
	@Test(priority=2)
	public void Syne_HomePageTest2()
	{
		HomePage homepage = new  HomePage();
		homepage.invoke();
		homepage.enterSearchText("Auto Loan");		
		
		SearchResultsPage searchResultsPage = new SearchResultsPage();
		searchResultsPage.waitForPageLoad();
		searchResultsPage.verifyHeaderText("Search Results");
		
		
	}
	
	@Test
	public void Syne_HomePageTest3()
	{
		HomePage homepage = new  HomePage();
		homepage.invoke();
		homepage.enterSearchText("2342343sdsads");		
		
		SearchResultsPage searchResultsPage = new SearchResultsPage();
		searchResultsPage.waitForPageLoad();
		searchResultsPage.verifyHeaderText("Search Results");
		searchResultsPage.verifyErrorMsg("We found no search results for");
	}
	
	@Test
	public void syne_homepageTest4()
	{
		OnlineBankingWithWellsFargoOnlinePage onlineBankingWithWellsFargoOnlinePage = new OnlineBankingWithWellsFargoOnlinePage();
		onlineBankingWithWellsFargoOnlinePage.invoke("/online-banking/");
		onlineBankingWithWellsFargoOnlinePage.verifyExpectedPageURL(onlineBankingWithWellsFargoOnlinePage.getBaseurl()+"/online-banking/");
		onlineBankingWithWellsFargoOnlinePage.EndofTestcase();
	}
	
	@Test(dataProvider="testData")
	public void syne_DataproviderExample(String name,String pass)
	{
		HomePage homepage = new  HomePage();
		homepage.invoke();
		Reporter.log("Name "+name);
		System.out.println(name +pass);
		homepage.loginHome(name, pass);		
		
	}
	
	@Test(dataProvider="testData")
	public void syne_switchwindowexample()
	{
		ExpressSendRemittanceCostEstimatorPage expressSendRemittanceCostEstimatorPage = new ExpressSendRemittanceCostEstimatorPage();
		expressSendRemittanceCostEstimatorPage.invoke("international-remittances/cost-estimator");
		
		String mainwindow =SyneUtility.getMainwindow();
		expressSendRemittanceCostEstimatorPage.verifyHeaderText("ExpressSend Remittance Cost Estimator");
		expressSendRemittanceCostEstimatorPage.linkHowMuchCanISend.click();
		
		SyneUtility.switchtoNewWindow(getDriver(), "ExpressSend International Remittance Transfers FAQ-Send Money.");
		expressSendRemittanceCostEstimatorPage.verifyHeaderText("ExpressSend International Remittance Transfers Questions");
		
		SyneUtility.switchtoMainwindow(getDriver(), mainwindow);
		ExpressSendRemittanceCostEstimatorPage expressSendRemittanceCostEstimatorPage1 = new ExpressSendRemittanceCostEstimatorPage();
		expressSendRemittanceCostEstimatorPage1.waitForPageLoad();
		expressSendRemittanceCostEstimatorPage.verifyHeaderText("ExpressSend Remittance Cost Estimator");
		expressSendRemittanceCostEstimatorPage.EndofTestcase();
		
	}

	@Test
	public void syne_iframeexample()
	{
		ExpressSendRemittanceCostEstimatorPage expressSendRemittanceCostEstimatorPage = new ExpressSendRemittanceCostEstimatorPage();
		expressSendRemittanceCostEstimatorPage.invoke("international-remittances/cost-estimator");
	}	
	
	@Test(invocationCount=2)
	public void Syne_HomePageTest6()
	{
		HomePage homepage = new  HomePage();
		homepage.invoke();		
		homepage.clickonLink("Banking").click();;
		homepage.clickonLink("Insurance").click();
		System.out.println(getDriver().getCurrentUrl()) ;
		SyneUtility.executeexe();
		System.out.println(getDriver().getCurrentUrl());
		System.out.println(getDriver().getTitle());
		homepage.enterSearchText("loan");			
		
		SearchResultsPage searchResultsPage = new SearchResultsPage();
		searchResultsPage.waitForPageLoad();
		
		searchResultsPage.verifyHeaderText("Search Results");
		searchResultsPage.EndofTestcase();
		
	}
	
	@Test(invocationCount=1)
	public void syne_headerTest1()
	{
		HomePage homePage = new HomePage();
		homePage.invoke();
		
		homePage.header.linkEspanol.click(); 
		System.out.println(getDriver().getCurrentUrl());
		getDriver().navigate().back();
		
		homePage.waitForPageLoad();
		homePage.header.linkCustomerService.click();
		System.out.println(getDriver().getCurrentUrl());
		getDriver().navigate().back();
		
		homePage.waitForPageLoad();
		homePage.header.linkATMsOrLocations.click();
		System.out.println(getDriver().getCurrentUrl());
		getDriver().navigate().back();
		
		homePage.waitForPageLoad();
		homePage.header.linkEspanol.click();
		System.out.println(getDriver().getCurrentUrl());
		getDriver().navigate().back();
				
		
	}
}
