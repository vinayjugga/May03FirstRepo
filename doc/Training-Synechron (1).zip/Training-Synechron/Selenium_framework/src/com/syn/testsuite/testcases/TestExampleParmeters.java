package com.syn.testsuite.testcases;

import org.testng.Reporter;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.syn.pages.homepage.HomePage;

public class TestExampleParmeters {

	@Parameters({"username","password"})
	@Test
	public void syne_parameterExample(String username,String password)
	{
		HomePage homepage = new  HomePage();
		homepage.invoke();
		Reporter.log("Name :"+username);
		System.out.println("UN:"+username +"PW:"+ password);
		homepage.loginHome(username, password);		
		
	}
}
