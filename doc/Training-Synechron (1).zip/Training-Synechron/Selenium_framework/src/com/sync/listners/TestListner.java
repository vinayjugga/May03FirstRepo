package com.sync.listners;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.syn.core.pages.BaseTestCases;

public class TestListner implements ITestListener {

	WebDriver driver =null;
	String currnetpath =System.getProperty("user.dir");
	@Override
	public void onFinish(ITestContext arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStart(ITestContext arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onTestFailure(ITestResult arg0) {
		// TODO Auto-generated method stub
		String methodname = arg0.getName().toString().trim();
		takescreenshot(methodname);
		
		System.out.println("Screen shot captured====="+arg0.getName().toString().trim());
		
	}
	
	public void takescreenshot(String methodname)
	{
		driver =BaseTestCases.getDriver();
		File src =((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		
		try{
			FileUtils.copyFile(src, new File(currnetpath+"/ScreenshotFailure/"+methodname+".png"));
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
	}

	
	
	@Override
	public void onTestSkipped(ITestResult arg0) {
		// TODO Auto-generated method stub
		System.out.println("Testcase skipped check once again ===="+ arg0.getName().toString().trim());
	}

	@Override
	public void onTestStart(ITestResult arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onTestSuccess(ITestResult arg0) {
		// TODO Auto-generated method stub
		System.out.println("Congrates Testcase has been passed===="+ arg0.getName().toString().trim());
	}

}
